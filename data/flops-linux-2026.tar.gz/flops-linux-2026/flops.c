/*
 * flops.c - floating point operations per second benchmark for linux
 * Copyright (C) 1992 Al Aburto <aburto@nosc.mil>
 * Copyright (C) 2000 Marc Gloor <mgloor@fhzh.ch>
 * Copyright (C) 2026 Marc Gloor <marc.gloor@u.nus.edu>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * * --------------------------------------------------------------------------- 
 *
 * This benchmark measures the raw computational throughput of a processor by
 * executing a high-intensity floating-point loop across all available CPU cores.
 * By utilizing Fused Multiply-Add (FMA) style operations, it estimates the
 * theoretical Peak GFLOPS of the system. Code modernized in 2026 (Multicore).
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <omp.h> 
#include <time.h>

// Adjust iterations to ensure the test runs long enough to be stable
#define ITERATIONS 1000000000ULL
#define VEC_SIZE 8 // Simulating a typical AVX-256 float vector width

int main() {
    double start_time, end_time;
    double total_flops, gflops, mflops; 
    
    // We use a small array to keep data in L1 cache
    float a = 1.1f, b = 1.2f, c = 1.3f; 

    printf("Starting Multicore Peak FLOPs Benchmark...\n");
    printf("Cores: %d\n", omp_get_max_threads());

    start_time = omp_get_wtime();

    #pragma omp parallel firstprivate(a, b, c)
    {
        // Each thread runs its own loop
        for (unsigned long long i = 0; i < ITERATIONS; i++) {
            // Fused Multiply-Add: a = a * b + c 
            // This represents 2 Floating Point Operations per iteration
            a = a * b + c;
            b = b * c + a;
            c = c * a + b;
            a = a * b + c;
            b = b * c + a;
            c = c * a + b;
            a = a * b + c;
            b = b * c + a;
            c = c * a + b;
            a = a * b + c; // 10 operations per loop to reduce overhead
        }
        // Dummy print to prevent the compiler from optimizing the loop away
        if (a < 0) printf("%f", a);
    }

    end_time = omp_get_wtime();
    double duration = end_time - start_time;

    // Calculation: Threads * Iterations * 10 operations
    total_flops = (double)omp_get_max_threads() * ITERATIONS * 10.0;
    gflops = (total_flops / duration) / 1e9;
    mflops = (total_flops / duration) / 1e6;

    printf("--------------------------------------\n");
    printf("Execution Time: %.4f seconds\n", duration);
    printf("Peak Performance: %.2f MFLOPS\n", mflops);
    printf("Peak Performance: %.2f GFLOPS\n", gflops);
    printf("--------------------------------------\n");

    return 0;
}
           
