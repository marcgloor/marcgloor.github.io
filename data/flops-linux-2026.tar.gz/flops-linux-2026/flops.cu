/*
 * flops.cu - FLOPS benchmark (GPU version)
 * Copyright (C) 2026 Marc Gloor <marc.gloor@u.nus.edu>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * * ---------------------------------------------------------------------------
 *
 * This benchmark measures the raw computational throughput of a nvidia comp gpu by
 * executing a high-intensity floating-point loop across all available CPU cores.
 * By utilizing Fused Multiply-Add (FMA) style operations, it estimates the
 * theoretical Peak GFLOPS of the system. Code modernized in 2026 (Multicore).
 *
 */

#include <stdio.h>
#include <cuda_runtime.h>

// Macro for GPU error checking
#define gpuErrchk(ans) { gpuAssert((ans), __FILE__, __LINE__); }
inline void gpuAssert(cudaError_t code, const char *f, int l, bool abort=true) {
   if (code != cudaSuccess) {
      fprintf(stderr,"GPUassert: %s %s %d\n", cudaGetErrorString(code), f, l);
      if (abort) exit(code);
   }
}

// Increased iterations per thread to ensure the GPU stays busy
#define ITERATIONS 10000000
// Large number of blocks and threads to saturate the GPU
#define BLOCKS 256
#define THREADS_PER_BLOCK 256

__global__ void flops_kernel(float *d_out) {
    // Unique thread ID
    int tid = blockIdx.x * blockDim.x + threadIdx.y;
    
    // Using registers to keep data in the fastest possible memory
    float a = 1.1f + (float)tid; 
    float b = 1.2f; 
    float c = 1.3f;

    // The loop body: 10 Fused Multiply-Add operations per iteration
    for (unsigned long long i = 0; i < ITERATIONS; i++) {
        a = a * b + c;
        b = b * c + a;
        c = c * a + b;
        a = a * b + c;
        b = b * c + a;
        c = c * a + b;
        a = a * b + c;
        b = b * c + a;
        c = c * a + b;
        a = a * b + c; 
    }

    // Write to global memory so the compiler doesn't optimize the loop away
    if (a < 0.0f) d_out[tid] = a; 
}

int main() {
    int deviceCount;
    cudaGetDeviceCount(&deviceCount);
    if (deviceCount == 0) {
        printf("No CUDA-capable GPU found!\n");
        return 1;
    }

    float *d_out;
    gpuErrchk(cudaMalloc(&d_out, BLOCKS * THREADS_PER_BLOCK * sizeof(float)));

    printf("Starting CUDA Peak FLOPs Benchmark...\n");
    printf("Configuration: %d Blocks, %d Threads/Block\n", BLOCKS, THREADS_PER_BLOCK);

    // Create CUDA events for precise timing
    cudaEvent_t start, stop;
    cudaEventCreate(&start);
    cudaEventCreate(&stop);

    cudaEventRecord(start);
    
    // Launch the kernel
    flops_kernel<<<BLOCKS, THREADS_PER_BLOCK>>>(d_out);
    
    cudaEventRecord(stop);
    cudaEventSynchronize(stop);

    float milliseconds = 0;
    cudaEventElapsedTime(&milliseconds, start, stop);
    double seconds = milliseconds / 1000.0;

    // Calculation: Total Threads * Iterations * 10 operations
    double total_flops = (double)BLOCKS * THREADS_PER_BLOCK * ITERATIONS * 10.0;
    double gflops = (total_flops / seconds) / 1e9;
    double tflops = gflops / 1000.0;

    printf("--------------------------------------\n");
    printf("Execution Time: %.4f seconds\n", seconds);
    printf("Peak Performance: %.2f GFLOPS\n", gflops);
    printf("Peak Performance: %.4f TFLOPS\n", tflops);
    printf("--------------------------------------\n");

    cudaFree(d_out);
    cudaEventDestroy(start);
    cudaEventDestroy(stop);

    return 0;
}
