#!/bin/sh

# hour-meter (hm) installation script for Linux
# written 2000 by Marc O. Gloor <mgloor@fhzh.ch>
#
# $Id: install.sh,v 1.5 2005/09/11 11:13:57 gloor Exp $
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

CTB=/etc/crontab
RTF=/etc/hm

echo ""
echo "HOURMETER(1) INSTALLATION"
echo ""
echo -n "continue installation of hour-meter (hm) now? [y/n] "
read answer

if [ `echo $answer | cut -b 1-1 | tr A-Z a-z` != "y" ]
 then
  echo "installation aborted..."
  echo " "
  exit
fi

if [ `whoami` != "root" ]
 then
  echo "error: root permission required."
  echo "please become root or contact your administrator."
  echo "installation aborted..."
  echo " "
  exit
fi

echo -n "would you see now a complete installation preview? [y/n] "
read answer

if [ `echo $answer | cut -b 1-1 | tr A-Z a-z` != "n" ]
 then
  echo ""
  echo " - copying the 'hm' script to /usr/bin"
  echo " - create flatfile '/etc/hm'"
  echo " - copy manpage to '/usr/share/man/man1'"
  echo " - setting up the counter"
  echo " - set correct file permissions (755 & 644)"
  echo " - adding a crontab job"
  echo ""
fi

echo -n "how long is your system up since implementing? [hours] "
read value
echo -n "setting up the counter..........."
touch $RTF
echo "`echo $value`" > $RTF
echo "done."

echo -n "installing hour-meter............"
cp hm /usr/bin/
echo "done."
echo -n "installing manpage..............."
cp hm.1 /usr/share/man/man1/
echo "done."
echo -n "setting up file permissions......"
chmod 755 /usr/bin/hm
chmod 644 $RTF
echo "done."

echo -n "installing crontab job..........."
echo " " >> $CTB
echo "# hour-meter cronjob below (added by hm installation)" >> $CTB
echo "0-59/15 * * * * root /usr/bin/hm -c" >> $CTB
echo "done."
echo " "
echo "installation successfully finished."
echo " "
