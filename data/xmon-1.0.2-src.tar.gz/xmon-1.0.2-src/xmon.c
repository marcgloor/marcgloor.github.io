/*
 * xmon.c (1.0.2, performance monitor for linux (load, mem, cpu)
 * Copyright (C) 1998-2026 by Marc Gloor <marc.gloor@u.nus.edu>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <assert.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h> 

#define MAX_HIST 1000  
#define MWM_HINTS_DECORATIONS (1L << 1)

/* Motif for borderless mode */
struct MotifWmHints {
    unsigned long flags;
    unsigned long functions;
    unsigned long decorations;
    long input_mode;
    unsigned long status;
};

/* Prototypes */
long mem_used(void);
long mem_avl(void);
long cpu_usage(void);
int loadavg(void);
int draw_graphics(int win_x, int win_y, int win_w, int win_h, long speed_ms, int destruct, int borderless, char* mesh_color);

/* Globals for CPU calculation */
unsigned long cpu_jiffie_tot_old = 0;
unsigned long cpu_jiffie_usrnice_old = 0;

int main(int argc, char *argv[]) {
    int opt;
    int win_x = 100, win_y = 100, win_w = 300, win_h = 107;
    long speed_ms = 50;
    int destruct_sec = 0, borderless = 0;
    char mesh_color[64] = "DarkGreen";

    while ((opt = getopt(argc, argv, "s:p:w:d:bc:h")) != -1) {
        switch (opt) {
            case 's': speed_ms = atol(optarg); break;
            case 'p': sscanf(optarg, "%d,%d", &win_x, &win_y); break;
            case 'w': sscanf(optarg, "%dx%d", &win_w, &win_h); break;
            case 'd': destruct_sec = atoi(optarg); break;
            case 'b': borderless = 1; break;
            case 'c': strncpy(mesh_color, optarg, 63); break;
            case 'h': 
                printf("XMON 1.0.2 - Lightweight System Performance Monitor\n");
                printf("Copyright (C) 1998-2026 by Marc Gloor <marc.gloor@u.nus.edu>\n\n");
                printf("   Usage: %s [Options]\n\n", argv[0]);
                printf("   Options:\n");
                printf("   -b            Set borderless mode (default: win manager)\n");
                printf("   -c <color>    Set mesh 'color name' or \"#HEX\" (default: DarkGreen)\n");
                printf("   -d <sec>      Set self-destruct timer (default: not set)\n");
                printf("   -p <x,y>      Set initial window Position (default: 100,100)\n");
                printf("   -s <ms>       Set refresh speed (default: 50ms)\n");
                printf("   -w <WxH>      Set initial window size (default: 300x107)\n");
                printf("   -h            Show this help message\n\n");                
                exit(EXIT_SUCCESS);
            default: exit(EXIT_FAILURE);
        }
    }
    draw_graphics(win_x, win_y, win_w, win_h, speed_ms, destruct_sec, borderless, mesh_color);
    return 0;
}

int draw_graphics(int win_x, int win_y, int win_w, int win_h, long speed_ms, int destruct, int borderless, char* mesh_color) {
    Window w;
    XGCValues gr_values; 
    XSizeHints *hints;
    char WindowName[100], hostname[30], softname[] = "xmon@";
    GC kc, gc, ec, hc, bc, wc;     
    int blackColor, whiteColor, i, h, k, z, y, stackInit;

    int current_win_w = win_w, current_win_h = win_h;
    int cpu[MAX_HIST], mem[MAX_HIST], stack[MAX_HIST];
    long init_mem_avl;
    Pixmap pix;  
    Colormap screen_colormap;
    XColor red, cyan, yellow, MeshCol, fade_color;

    long delay = speed_ms * 1000; 
    float curr_lx = 265, curr_ly = 50, curr_mx = 265, curr_my = 50, curr_cx = 265, curr_cy = 50;
    float ease = 0.15, text_alpha = 0.0; 
    double fade_trigger_time = 0; 
    char cycle_msg1[64] = "", cycle_msg2[64] = "", cycle_msg3[64] = ""; 
    
    time_t start_time = time(NULL);
    static int l_docked = 1, m_docked = 1, c_docked = 1;

    Display *dpy = XOpenDisplay(NULL);
    if (dpy == NULL) exit(1);

    blackColor = BlackPixel(dpy, DefaultScreen(dpy));
    whiteColor = WhitePixel(dpy, DefaultScreen(dpy));
    w = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), win_x, win_y, current_win_w, current_win_h, 0, blackColor, blackColor);

    if (borderless) {
        Atom mwmHintsProperty = XInternAtom(dpy, "_MOTIF_WM_HINTS", False);
        struct MotifWmHints mwmhints;
        mwmhints.flags = MWM_HINTS_DECORATIONS;
        mwmhints.decorations = 0; 
        XChangeProperty(dpy, w, mwmHintsProperty, mwmHintsProperty, 32, PropModeReplace, (unsigned char *)&mwmhints, 5);
    }

    hints = XAllocSizeHints();
    if (hints) {
        hints->flags = PMinSize | PPosition;
        hints->x = win_x; hints->y = win_y;
        hints->min_width = 150; hints->min_height = 80;
        XSetWMNormalHints(dpy, w, hints);
        XFree(hints);
    }

    pix = XCreatePixmap(dpy, w, current_win_w, current_win_h, DefaultDepth(dpy, DefaultScreen(dpy))); 
    screen_colormap = DefaultColormap(dpy, DefaultScreen(dpy));

    if (gethostname(hostname, 30) != 0) strcpy(hostname, "unknown");
    snprintf(WindowName, sizeof(WindowName), "%s%s", softname, hostname);
    XStoreName(dpy, w, WindowName);

    XAllocNamedColor(dpy, screen_colormap, "red", &red, &red);
    XAllocNamedColor(dpy, screen_colormap, "cyan", &cyan, &cyan);
    XAllocNamedColor(dpy, screen_colormap, "yellow", &yellow, &yellow);

    XColor exact_def;
    if (XParseColor(dpy, screen_colormap, mesh_color, &exact_def)) {
        XAllocColor(dpy, screen_colormap, &exact_def);
        MeshCol = exact_def;
    } else {
        XAllocNamedColor(dpy, screen_colormap, "DarkGreen", &MeshCol, &MeshCol);
    }

    XFontStruct *font = XLoadQueryFont(dpy, "6x10");
    if (!font) font = XLoadQueryFont(dpy, "fixed");
    gr_values.font = font->fid;

    kc = XCreateGC(dpy, w, GCFont, &gr_values); 
    gc = XCreateGC(dpy, w, GCFont, &gr_values);
    ec = XCreateGC(dpy, w, GCFont, &gr_values);
    hc = XCreateGC(dpy, w, GCFont, &gr_values);
    bc = XCreateGC(dpy, w, GCFont, &gr_values);
    wc = XCreateGC(dpy, w, GCFont, &gr_values);

    XSetForeground(dpy, kc, yellow.pixel);
    XSetForeground(dpy, gc, MeshCol.pixel);
    XSetForeground(dpy, ec, cyan.pixel);   
    XSetForeground(dpy, hc, red.pixel);
    XSetForeground(dpy, bc, blackColor);

    XSelectInput(dpy, w, StructureNotifyMask | ExposureMask | KeyPressMask);   
    XMapWindow(dpy, w);

    for(;;) { XEvent e; XNextEvent(dpy, &e); if (e.type == MapNotify) break; }

    init_mem_avl = mem_avl();
    if (init_mem_avl <= 0) init_mem_avl = 1; 
    z = 0; 

    for (;;) {
        if (destruct > 0 && (time(NULL) - start_time) >= destruct) exit(0);
        if (z < MAX_HIST) z += 1;

        while (XPending(dpy)) {
            XEvent ev; XNextEvent(dpy, &ev);
            if (ev.type == ConfigureNotify || ev.type == KeyPress) {
                if (ev.type == ConfigureNotify) {
                    current_win_w = ev.xconfigure.width; current_win_h = ev.xconfigure.height;
                    XFreePixmap(dpy, pix);
                    pix = XCreatePixmap(dpy, w, current_win_w, current_win_h, DefaultDepth(dpy, DefaultScreen(dpy)));
                } else {
                    KeySym sym = XLookupKeysym(&ev.xkey, 0);
                    if (sym == XK_plus || sym == XK_equal || sym == XK_KP_Add) { if (delay > 10000) delay -= 10000; } 
                    else if (sym == XK_minus || sym == XK_underscore || sym == XK_KP_Subtract) { if (delay < 500000) delay += 10000; }
                }
                
                /* Calculations for diagnostics overlay */
                int gs_c = current_win_h / 7; if (gs_c < 5) gs_c = 5;
                double cyc = ((double)current_win_w / (double)gs_c) * ((double)delay / 1000000.0);
                double total_render = ((double)current_win_w * (double)delay) / 1000000.0;

                sprintf(cycle_msg1, "Rendering : %.1f sec", total_render);
                sprintf(cycle_msg2, "Cycle time: %d sec", (int)cyc + 1);
                sprintf(cycle_msg3, "Speed     : %ld ms", delay / 1000);
                
                struct timeval tv; gettimeofday(&tv, NULL);
                fade_trigger_time = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.0;
                text_alpha = 1.0; 
            }
        }

        for (stackInit = MAX_HIST-1; stackInit >= 1; stackInit--) {
            cpu[stackInit] = cpu[stackInit-1]; mem[stackInit] = mem[stackInit-1]; stack[stackInit] = stack[stackInit-1];
        }

        int graph_h = current_win_h - 2;
        cpu[0] = (graph_h - ((graph_h * cpu_usage()) / 100));
        mem[0] = graph_h - ((mem_used() * graph_h) / init_mem_avl);
        stack[0] = graph_h - ((loadavg() * graph_h) / 1000); 

        int grid_step = current_win_h / 7; if (grid_step < 5) grid_step = 5;

        for (i = 0; i < grid_step; i++) { 
            XFillRectangle(dpy, pix, bc, 0, 0, current_win_w, current_win_h);
            int blink = ((i / (grid_step/3 + 1)) % 2 == 0);

            for (h = 0; h < (current_win_w / grid_step) + 2; h++) 
                XDrawLine(dpy, pix, gc, ((current_win_w - (h * grid_step)) - i), 0, ((current_win_w - (h * grid_step)) - i), current_win_h);
            for (k = 0; k <= (current_win_h / grid_step); k++) 
                XDrawLine(dpy, pix, gc, 0, k * grid_step, current_win_w, k * grid_step);

            for (y = 0; y < z - 1 && y < (current_win_w / grid_step) + 20; y++) { 
                int x1 = current_win_w - (y * grid_step) - i;
                int x2 = current_win_w - ((y + 1) * grid_step) - i;
                if (y == 0) x1 = current_win_w;
                if (x1 >= 0 || x2 >= 0) {
                    XDrawLine(dpy, pix, ec, x1, stack[y], x2, stack[y+1]);
                    XDrawLine(dpy, pix, hc, x1, mem[y],   x2, mem[y+1]);
                    XDrawLine(dpy, pix, kc, x1, cpu[y],   x2, cpu[y+1]);
                }
            }

            int target_lx, target_ly, target_mx, target_my, target_cx, target_cy, next_top_x = 5; 
            int right_base = current_win_w - 45, high_l = 12;

            int leave_dock_threshold = (int)(current_win_h * 0.88); 
            int enter_dock_threshold = (int)(current_win_h * 0.94);            
     
            if (l_docked && stack[0] < leave_dock_threshold) l_docked = 0;
            else if (!l_docked && stack[0] > enter_dock_threshold) l_docked = 1;
            if (m_docked && mem[0] < leave_dock_threshold) m_docked = 0;
            else if (!m_docked && mem[0] > enter_dock_threshold) m_docked = 1;
            if (c_docked && cpu[0] < leave_dock_threshold) c_docked = 0;
            else if (!c_docked && cpu[0] > enter_dock_threshold) c_docked = 1;

            target_ly = l_docked ? high_l : ((stack[0] < high_l) ? high_l : stack[0] - 4);
            target_my = m_docked ? high_l : ((mem[0] < high_l)   ? high_l : mem[0] - 4);
            target_cy = c_docked ? high_l : ((cpu[0] < high_l)   ? high_l : cpu[0] - 4);

            target_lx = l_docked ? next_top_x : right_base;
            if (l_docked) next_top_x += 55;
            if (m_docked) { target_mx = next_top_x; next_top_x += 55; }
            else { target_mx = (abs(target_my - target_ly) < 10 && target_lx == right_base) ? right_base - 30 : right_base; }
            if (c_docked) { target_cx = next_top_x; }
            else {
                target_cx = right_base;
                if (abs(target_cy - target_ly) < 10 && target_lx == right_base) target_cx -= 30;
                if (abs(target_cy - target_my) < 10 && target_mx >= (target_cx - 10)) target_cx = target_mx - 30;
            }

            curr_lx += (target_lx - curr_lx) * ease; curr_ly += (target_ly - curr_ly) * ease;
            curr_mx += (target_mx - curr_mx) * ease; curr_my += (target_my - curr_my) * ease;
            curr_cx += (target_cx - curr_cx) * ease; curr_cy += (target_cy - curr_cy) * ease;

            /* "DOCKING BAY" visibility logic matching original */
            int any_docking = (curr_lx < 60 || curr_mx < 60 || curr_cx < 60);
            if (!any_docking) { 
                XDrawString(dpy, pix, gc, 5, high_l, "DOCKING BAY", 11); 
            }

            char l_s[15], m_s[15], c_s[15];
            if (l_docked) strcpy(l_s, "LOAD LOW"); else if (stack[0] < high_l && blink) strcpy(l_s, "^LOAD^"); else strcpy(l_s, " LOAD ");
            XDrawString(dpy, pix, ec, (int)curr_lx, (int)curr_ly, l_s, strlen(l_s));
            if (m_docked) strcpy(m_s, "MEM LOW"); else if (mem[0] < high_l && blink) strcpy(m_s, "^MEM^"); else strcpy(m_s, " MEM ");
            XDrawString(dpy, pix, hc, (int)curr_mx, (int)curr_my, m_s, strlen(m_s));
            if (c_docked) strcpy(c_s, "CPU LOW"); else if (cpu[0] < high_l && blink) strcpy(c_s, "^CPU^"); else strcpy(c_s, " CPU ");
            XDrawString(dpy, pix, kc, (int)curr_cx, (int)curr_cy, c_s, strlen(c_s));

            if (text_alpha > 0.0) {
                struct timeval tv_now; gettimeofday(&tv_now, NULL);
                double now = (double)tv_now.tv_sec + (double)tv_now.tv_usec / 1000000.0;
                double elapsed = now - fade_trigger_time;
                if (elapsed <= 5.0) text_alpha = 1.0; else text_alpha = 1.0 - ((elapsed - 5.0) / 3.0);
                if (text_alpha > 0.0) {
                    fade_color.red = fade_color.green = fade_color.blue = (unsigned short)(text_alpha * 65535);
                    XAllocColor(dpy, screen_colormap, &fade_color);
                    XSetForeground(dpy, wc, fade_color.pixel);
                    XDrawString(dpy, pix, wc, 5, current_win_h - 34, cycle_msg1, strlen(cycle_msg1));
                    XDrawString(dpy, pix, wc, 5, current_win_h - 22, cycle_msg2, strlen(cycle_msg2));
                    XDrawString(dpy, pix, wc, 5, current_win_h - 10, cycle_msg3, strlen(cycle_msg3));
                }
            }
            XCopyArea(dpy, pix, w, kc, 0, 0, current_win_w, current_win_h, 0, 0);
            XFlush(dpy); usleep(delay); 
        }
    } 
    return 0;
}

/* Data collection functions */
long cpu_usage(void) {
    FILE *fp = fopen("/proc/stat", "r");
    if (!fp) return 0;
    unsigned long u, n, s, id, iow, irq, soft;
    if (fscanf(fp, "cpu %lu %lu %lu %lu %lu %lu %lu", &u, &n, &s, &id, &iow, &irq, &soft) < 4) { fclose(fp); return 0; }
    fclose(fp);
    unsigned long tot = u + n + s + id + iow + irq + soft, work = u + n + s;
    long load = 0;
    if (cpu_jiffie_tot_old > 0 && tot > cpu_jiffie_tot_old) { load = ((work - cpu_jiffie_usrnice_old) * 100) / (tot - cpu_jiffie_tot_old); }
    cpu_jiffie_tot_old = tot; cpu_jiffie_usrnice_old = work;
    return (load > 100) ? 100 : (load < 0 ? 0 : load);
}

int loadavg(void) {
    double l; FILE *fp = fopen("/proc/loadavg", "r");
    if (!fp) return 0; if (fscanf(fp, "%lf", &l) < 1) l = 0; fclose(fp);
    return (int)(l * 100);
}

long mem_avl(void) {
    long val = 0; char label[64]; FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) return 1; while (fscanf(fp, "%63s %ld", label, &val) != EOF) { if (strcmp(label, "MemTotal:") == 0) break; }
    fclose(fp); return val;
}

long mem_used(void) {
    long total = 0, available = 0; char label[64]; long val; FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) return 0;
    while (fscanf(fp, "%63s %ld", label, &val) != EOF) {
        if (strcmp(label, "MemTotal:") == 0) total = val;
        if (strcmp(label, "MemAvailable:") == 0) available = val;
    }
    fclose(fp); return (total - available > 0) ? (total - available) : 0;
}
