/*
 * xmon (beta), performance monitor for linux (load, mem, cpu)
 * Copyright (C) 2000 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * $Id: xmon.c,v 1.5 2002/09/22 12:42:16 gloor Exp gloor $
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <assert.h>
#include <X11/Xlib.h>
#include <X11/cursorfont.h> 

#define NIL (0)

long mem_used(void);	/* function ptype */
long mem_avl(void);     /* function ptype */
long cpu_usage(void);   /* function ptype */
unsigned long cpu_jiffie_tot_old;      /* global stack used in cpu_usage() */
unsigned long cpu_jiffie_usrnice_old;  /* global stack used in cpu_usage() */

main() {

        printf("\n");
        printf("  xmon 0.0.1b, written by Marc O. Gloor <mgloor@fhzh.ch>\n\n");
	draw_graphics();

}

draw_graphics()
{
      Window w;
      XGCValues gr_values; 
      char hostname[30];
      char softname[] = "xmon@";
      char WindowName[40];
      GC kc, gc, ec, fc, hc, bc;      
      int blackColor, whiteColor, d, q, r, rc, dc, i, h, k, z, x, y, f, XTimeCoord;

      int cpu[22], mem[22], stack[22], stackInit;

      long test;
      long init_mem_avl;
      Pixmap pix;  
      Colormap screen_colormap;     /* color map to use for allocating colors.   */
      XColor red, green, blue, yellow, cyan, DarkGreen;
      Status gcc;	

      Display *dpy = XOpenDisplay(NIL);

      /* Stack Reset Init */
      for (stackInit=0; stackInit<23; stackInit++) {
		cpu[stackInit] = mem[stackInit] = stack[stackInit] = 0;
                }


      if (dpy==NULL) {
        printf("error: can't connect to server!\n");
        exit(0);
      }


      assert(dpy);

      blackColor = BlackPixel(dpy, DefaultScreen(dpy));
      whiteColor = WhitePixel(dpy, DefaultScreen(dpy));
      w = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), 0, 0, 
				     300, 107, 0, blackColor, blackColor);

      pix = XCreatePixmap (dpy, w, 300, 107, DefaultDepth (dpy, 0)); 

      screen_colormap = DefaultColormap(dpy, 0);


      gethostname(hostname, 30);
      strcpy(WindowName, strcat(softname, hostname));
      XStoreName(dpy,w, WindowName);
      XSetIconName(dpy,w, WindowName);

      gcc = XAllocNamedColor(dpy, screen_colormap, "red", &red, &red);
      gcc = XAllocNamedColor(dpy, screen_colormap, "green", &green, &green);
      gcc = XAllocNamedColor(dpy, screen_colormap, "cyan", &cyan, &cyan);
      gcc = XAllocNamedColor(dpy, screen_colormap, "blue", &blue, &blue);
      gcc = XAllocNamedColor(dpy, screen_colormap, "yellow", &yellow, &yellow);
      gcc = XAllocNamedColor(dpy, screen_colormap, "DarkGreen", &DarkGreen, &DarkGreen);

/*
      if (gcc == 0) {
        printf("failed to allocate color, color is used by another client.\n");
        }
*/

      gr_values.font = XLoadQueryFont(dpy,"6x10")->fid; 
      kc = XCreateGC(dpy,w, GCFont, &gr_values); 
      gc = XCreateGC(dpy,w, GCFont, &gr_values);
      ec = XCreateGC(dpy,w, GCFont, &gr_values);
      fc = XCreateGC(dpy,w, GCFont, &gr_values);
      hc = XCreateGC(dpy,w, GCFont, &gr_values);
      /* bc = XCreateGC(dpy,w, 0, NIL); */
      bc = XCreateGC(dpy,w, GCFont, &gr_values);

      XSetForeground(dpy, kc, yellow.pixel);
      XSetForeground(dpy, gc, DarkGreen.pixel);
      XSetForeground(dpy, ec, cyan.pixel);   
      XSetForeground(dpy, fc, cyan.pixel);   
      XSetForeground(dpy, hc, red.pixel);
      XSetForeground(dpy, bc, blackColor);

      /* initialize application's event mask */
      XSelectInput(dpy, w, StructureNotifyMask);  

      XMapWindow(dpy, w);

      for(;;) {
	    XEvent e;
	    XNextEvent(dpy, &e);
	    if (e.type == MapNotify)
		  break;
      }

      XCopyArea (dpy, w, pix, kc, 0, 0, 300, 107, 0, 0);

      init_mem_avl = mem_avl();
      z = -1;

for (;;) {

    if (z > 1000) z = -1;

    z += 1;


    /* cpu/memory/load stack rotation */

    for (stackInit=21; stackInit>=1; stackInit--) {

		cpu[stackInit] = cpu[stackInit-1];
		mem[stackInit] = mem[stackInit-1];
		stack[stackInit] = stack[stackInit-1];

    }

    cpu[0] = (105-((105 * cpu_usage())/100));
    mem[0] = 105-((mem_used()/1024^2)*105) / (init_mem_avl/1024^2);
    stack[0] = 105-loadavg();


    /* printf("cpuu: %d\n", cpu_usage()); */
    /* printf("cused: %d\n", test); */

    for (i=0;i<15;i++){ 

    	/* XClearWindow(dpy, w); */
    	/* XClearArea(dpy, w, 0, 0, 300, 105, 1); */

	XCopyArea (dpy, pix, w, kc, 0, 0, 300, 107, 0, 0);


        /* display background grid */
        for (h=0;h<22;h++){ 

            XDrawLine(dpy, pix, bc, ((300-(h*15))-i)+1, 0, ((300-(h*15))-i)+1, 105);
            XDrawLine(dpy, pix, gc, ((300-(h*15))-i), 0, ((300-(h*15))-i), 105);

        }

        for (k=0;k<8;k++){ 
                
                XDrawLine(dpy, pix, gc, 0, k*15, 300, k*15);

                }


        for (y=0;y<22;y++){ 

      	
            if (z > y-1) {

                if(y==0) {

                    XDrawLine(dpy, pix, bc, 300-i-((y-1)*15)+1, stack[y], 315-i-((y-1)*15)+1, stack[y]);
                    XDrawLine(dpy, pix, bc, 300-i-((y-1)*15)+1, mem[y], 315-i-((y-1)*15)+1, mem[0]);
                    XDrawLine(dpy, pix, bc, 300-i-((y-1)*15)+1, cpu[y], 315-i-((y-1)*15)+1, cpu[0]);

                }

                else {

                    XDrawLine(dpy, pix, bc, 300-i-((y-1)*15)+1, stack[y], 315-i-((y-1)*15)+1, stack[y-1]);
                    XDrawLine(dpy, pix, bc, 300-i-((y-1)*15)+1, mem[y], 315-i-((y-1)*15)+1, mem[y-1]);
                    XDrawLine(dpy, pix, bc, 300-i-((y-1)*15)+1, cpu[y], 315-i-((y-1)*15)+1, cpu[y-1]);

                }

            }

        }


        for (y=0;y<22;y++){ 

            /* display load/memory/cpu status */		
            if (z > y-1) {

                if(y==0) {

                    XDrawLine(dpy, pix, ec, 300-i-((y-1)*15), stack[y], 315-i-((y-1)*15), stack[y]);
                    XDrawLine(dpy, pix, hc, 300-i-((y-1)*15), mem[y], 315-i-((y-1)*15), mem[0]);
                    XDrawLine(dpy, pix, kc, 300-i-((y-1)*15), cpu[y], 315-i-((y-1)*15), cpu[0]);

                }

                else {

                    XDrawLine(dpy, pix, ec, 300-i-((y-1)*15), stack[y], 315-i-((y-1)*15), stack[y-1]);
                    XDrawLine(dpy, pix, hc, 300-i-((y-1)*15), mem[y], 315-i-((y-1)*15), mem[y-1]);
                    XDrawLine(dpy, pix, kc, 300-i-((y-1)*15), cpu[y], 315-i-((y-1)*15), cpu[y-1]);

                }

            }

        }


        if(i==0) {

	    if (105-stack[1] > 105) 
		    XDrawString(dpy, pix, bc, 264, 12, "^LOAD^", 6);

	    else if (105-stack[1] > 90 && 105-stack[1] <= 105)
	    	    XDrawString(dpy, pix, bc, 270, stack[1]+15, "LOAD", 4);

	    else XDrawString(dpy, pix, bc, 270, stack[1]-4, "LOAD", 4);


	    /* display "umem" */
	    if (105-mem[1] > 90 && 105-mem[1] <= 105)
		    XDrawString(dpy, pix, bc, 270, mem[1]+12, "UMEM", 4);

	    else XDrawString(dpy, pix, bc, 270, mem[1]-4, "UMEM", 4);


	   /* display "cpuu" */
	    if (105-cpu[1] > 90 && 105-cpu[1] <= 105)
		    XDrawString(dpy, pix, bc, 270, cpu[1]+12, "CPUU", 4);

	    else XDrawString(dpy, pix, bc, 270, cpu[1]-4, "CPUU", 4);

        }


	if (105-stack[0] > 105) 
		XDrawString(dpy, pix, fc, 264, 12, "^LOAD^", 6);

	else if (105-stack[0] > 90 && 105-stack[0] <= 105)
		XDrawString(dpy, pix, fc, 270, stack[0]+15, "LOAD", 4);

	else XDrawString(dpy, pix, fc, 270, stack[0]-4, "LOAD", 4);


	/* display "umem" */
	if (105-mem[0] > 90 && 105-mem[0] <= 105)
		XDrawString(dpy, pix, hc, 270, mem[0]+12, "UMEM", 4);

	else XDrawString(dpy, pix, hc, 270, mem[0]-4, "UMEM", 4);


	/* display "cpuu" */
	if (105-cpu[0] > 90 && 105-cpu[0] <= 105)
		XDrawString(dpy, pix, kc, 270, cpu[0]+12, "CPUU", 4);

	else XDrawString(dpy, pix, kc, 270, cpu[0]-4, "CPUU", 4);


        XFlush(dpy); 

        /* update jede Sekunde=66666, Laufzeit 30Sekunden=95238 */
        usleep(80000);


    } 

};      

       
      XFreePixmap(dpy, pix);
      XCloseDisplay(dpy);
      exit(0);

}

/*
XDestroyWindow(mydisplay,mywindow);
     XCloseDisplay(mydisplay);
     exit(0);
*/

long cpu_usage(void) {

	char ParseLine[100];
	char SepRtrs[] = " \t\n,";
	char *ParseToken;
	int cnt;
	char cpu_user[24],cpu_nice[24], cpu_syst[24], cpu_idle[24];
	unsigned long cpu_user_l;
	unsigned long cpu_nice_l;
	unsigned long cpu_syst_l;
	unsigned long cpu_idle_l;
	unsigned long cpu_load;
	unsigned long cpu_jiffie_tot_new;
	unsigned long cpu_jiffie_usrnice_new;

	FILE *instream;
	instream = fopen("/proc/stat", "r");
	
	while(!feof(instream)) {
		
		fgets(ParseLine, 170, instream);
			
		if ( strncmp("cpu", ParseLine, 3) == 0  ) {
						
			cnt = 0;
				
			ParseToken = strtok( ParseLine, SepRtrs );
				
			while( ParseToken != NULL ) {
			
				++cnt;
				
				if(cnt == 2) strcpy(cpu_user, ParseToken);
				if(cnt == 3) strcpy(cpu_nice, ParseToken);
				if(cnt == 4) strcpy(cpu_syst, ParseToken);
				if(cnt == 5) strcpy(cpu_idle, ParseToken);
				
				ParseToken = strtok( NULL, SepRtrs );
				
			}		
				
			/* printf("/proc/stat:  user: %s, nice: %s, syst: %s, idle: %s\n", cpu_user, cpu_nice, cpu_syst, cpu_idle); */
			fclose(instream);
			break;
					
		}	
			
	}
	
	cpu_user_l = (atol(cpu_user));
	cpu_nice_l = (atol(cpu_nice));
	cpu_syst_l = (atol(cpu_syst));
	cpu_idle_l = (atol(cpu_idle));

	cpu_jiffie_tot_new = (cpu_user_l + cpu_nice_l + cpu_syst_l + cpu_idle_l );
	cpu_jiffie_usrnice_new = ((cpu_user_l+cpu_nice_l));

	if(cpu_jiffie_tot_old > 0) cpu_load = (((cpu_jiffie_usrnice_new-cpu_jiffie_usrnice_old)*100)/(cpu_jiffie_tot_new-cpu_jiffie_tot_old));

	/* printf("CPU: %d\n", cpu_load)*/	
	
	cpu_jiffie_usrnice_old = ((cpu_user_l+cpu_nice_l));
	cpu_jiffie_tot_old = (cpu_user_l + cpu_nice_l + cpu_syst_l + cpu_idle_l );


	return cpu_load;
	
}

int loadavg(void) {

	char get_loadavg[100];
	char seps[] = " \t\n";
	int str_conv;

	char *p;
        double load;

	FILE *instream;
	instream = fopen("/proc/loadavg", "r");

	fgets(get_loadavg, 150, instream);

	fclose(instream);
   
        p = strtok( get_loadavg, seps );
        /* printf( "string load is: %s\n", p ); */
      
	load = (atof(p) * 100);
	/* printf( "double load is: %lf\n", e ); */

	str_conv = (int)load;  /* float to int cast */
	/* printf( "load: %d\n", str_conv ); */

	return load;
}

long mem_avl(void) {

	char ParseLine[100];
	char SepRtrs[] = " \t\n,";
	char *ParseToken;
	int cnt;
	char mem_tot[24];
	long mem_tot_l;

	FILE *instream;
	instream = fopen("/proc/meminfo", "r");
	
        while(!feof(instream)) {
	
		fgets(ParseLine, 170, instream);
		
		if ( strncmp("Mem:", ParseLine, 4) == 0  ) {
					
        		cnt = 0;
			
        		ParseToken = strtok( ParseLine, SepRtrs );
			
        		while( ParseToken != NULL ) {
		
				++cnt;
			
				if(cnt == 2) strcpy(mem_tot, ParseToken);
		
				ParseToken = strtok( NULL, SepRtrs );
			
			}		
			
			/* printf("tot: %s used: %s\n", mem_tot, mem_used); */
			fclose(instream);
			break;
				
		}	
		
	}

	mem_tot_l = (atol(mem_tot));

	return mem_tot_l;
	
}

long mem_used(void) {

	char ParseLine[100];
	char SepRtrs[] = " \t\n,";
	char *ParseToken;
	int cnt;
	char mem_used[24];
	long mem_used_l;

	FILE *instream;
	instream = fopen("/proc/meminfo", "r");
	
        while(!feof(instream)) {
	
		fgets(ParseLine, 170, instream);
		
		if ( strncmp("Mem:", ParseLine, 4) == 0  ) {
					
        		cnt = 0;
			
        		ParseToken = strtok( ParseLine, SepRtrs );
			
        		while( ParseToken != NULL ) {
		
				++cnt;
			
				if(cnt == 3) strcpy(mem_used, ParseToken);
			
				ParseToken = strtok( NULL, SepRtrs );
			
			}		
			
			/* printf("tot: %s used: %s\n", mem_tot, mem_used); */
			fclose(instream);
			break;
				
		}	
		
	}

	mem_used_l = (atol(mem_used));

	return mem_used_l;
	
}
