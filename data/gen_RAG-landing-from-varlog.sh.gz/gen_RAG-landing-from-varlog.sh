#!/bin/bash
# @(#) Generates a RAG Ingestion ready staging area from /var/log/
# 2026/02/26 - written by Marc Gloor <marc.gloor@u.nus.edu>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

# Create staging area dir 
TIMESTAMP=$(date +%Y%m%d_%H%M)
DIR="${TIMESTAMP}_varlog-security-audit"

mkdir -p "$DIR" && cd "$DIR" || exit 1
echo "Created directory: $DIR"
pwd

# Clone logs into staging (using -p to preserve timestamps/permissions where possible)
cp -rp /var/log/* . 2>/dev/null

# Move files to root dir
find . -mindepth 2 -type f -exec mv --backup=numbered {} . \;

# Remove dotfiles
find . -mindepth 1 -name ".*" -exec rm -rf {} + >/dev/null 2>&1

# Remove empty dirs
find . -mindepth 1 -type d -empty -delete >/dev/null 2>&1

# Remove zero byte files
find . -type f -size 0 -delete >/dev/null 2>&1

# Remove tmp files
find . -type f -name "*~*" -delete >/dev/null 2>&1

# Remove redundant files
find . -name "*([0-9]*" -exec rm -f {} \; >/dev/null 2>&1

# Remove job control files
find . -name "nohup.out" -exec rm -f {} \; >/dev/null 2>&1

# Unzip all .gz files
# Using -q for quiet and || true to prevent script exit if no .gz files exist
gunzip -fq *.gz >/dev/null 2>&1 || true

# rm broken links
find . -xtype l -delete >/dev/null 2>&1

# Generate ASCII journal
journalctl > alljournal.log 2>/dev/null

# Remove binary data (More robust bash approach)
# Identify non-text files and remove them
find . -type f -exec sh -c 'file -b "$1" | grep -qv "text"' _ {} \; -delete >/dev/null 2>&1

# Remove binary journal files
rm -f *.journal >/dev/null 2>&1

echo "----------------------------------------------------------------"
echo "Staging area $DIR has been generated."
echo "You can now import the generated staging area data into your local LLM."
echo "CAUTION: DO NOT UPLOAD STAGING AREA DATA TO A PUBLIC LLM"
echo "----------------------------------------------------------------"
