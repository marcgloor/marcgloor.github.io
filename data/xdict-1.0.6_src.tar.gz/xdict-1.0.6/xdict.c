/*
 * xdict 1.0 patchlevel 6 
 * Copyright (C) 2001 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "xdict.h"
#define MaxParLen 10000 /* max. length of line */

/* function prototyping */
void unload_about_window();
void maximize_main();
void start_search();
void clear_func();
void show_wrk_dlg();

/* extern global declarations below */
GtkWidget *AboutWindow;
GtkWidget *MainWindow;
GtkWidget *WrkWindow;
GtkWidget *entry8;
GtkWidget *entry9;
GtkWidget *spinbutton1;
GtkObject *spinbutton1_adj;
GtkWidget *text3;
char *DictFile;
int icFlag = 0;
long OutPutLength  = 1;  

void func_cmd_version() {
	
	printf("\n xdict version 1.0 patchlevel 6 \n");
	printf(" written by Marc O. Gloor <mgloor@freesurf.ch>\n");
	printf(" visit: http://pubwww.fhzh.ch/~mgloor\n\n");
	
}

void func_cmd_hlp() {

	printf("\n syntax:  xdict [arg1] [arg2]\n");
	printf(" usage :  xdict --h --v --d dictfile\n\n");
	printf(" arguments are:\n");
	printf("  --h       show help\n");
	printf("  --v       show version\n");
	printf("  --d file  location of database (xdict.dat)\n\n");
	printf(" example: xdict --d /home/johnson/xdict.dat\n\n");
}

int
main (int argc, char *argv[])
{
  GtkWidget *MainWindow;

  /* gtk_set_locale (); */
  gtk_init (&argc, &argv);
    
  if (argc==2 && (strcmp(argv[1], "--v") == 0)) {
  
	func_cmd_version();
	exit(0);
	
   	}
	
  else if (argc==2 && (strcmp(argv[1], "--h") == 0)) {
  
	func_cmd_hlp();
	exit(0);
	
	}
	
  else if (argc > 2 && (strcmp(argv[1], "--d") == 0)) {

	DictFile = argv[2];  /* set runtime cmdline database */

	}
	
  else if (argc==1 ) {
  
	DictFile = "xdict.dat";  /* default database in same dir*/
	
	}	
		
  MainWindow = create_MainWindow ();
  gtk_widget_show (MainWindow);
  
  AboutWindow = create_AboutWindow ();
  WrkWindow = create_WrkWindow ();	
  	
  gtk_main ();
  return 0;
}

void
on_Quit2_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    	gtk_main_quit();
}

void
on_item17_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
	clear_func();
}

void
on_Info2_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
     	gtk_widget_show (AboutWindow);			   
}

void unload_about_window( GtkWidget *widget, GdkEvent *event, gpointer *data )
{ 
     	gtk_widget_hide (AboutWindow);
}

/* About Pixmap below */
static char * xdict_xpm[] = {
"32 32 5 1",
" 	s None	c None",
".	c black",
"X	c gray",
"o	c white",
"O	c blue",
"        .........               ",
"      .............             ",
"     ....       ....            ",
"    ...   ...........           ",
"   ...   ..XXXXXXXX...          ",
"  ...   .o.XXXXXXXXX...         ",
" ...   .oo.XXXXXXXXXX...        ",
" ...  .ooo.XXXXXXXXXX...        ",
"...  .oooo.XXXXXXXXXXX...       ",
"... .......XXXXXXXXXXX...       ",
"... .XXOOOXXOXXOXOXXXX...       ",
"... .XXOXXOXOXXOXOXXXX..........",
"... .XXOXXOXOXXOXOXXXX...XXXXXXX",
"... .XXOXXOXOXXOXOXXXX...XXXXXXX",
" ....XXOXXOXOXXOXOXXX...XXXXXXXX",
" ....XXOXXOXOXXOXOXXX...XXXXXXXX",
"  ...XXOXXOXOXXOXOXX...XXXXXXXXX",
"   ...XOOOXXXOOXXOX....XXXXXXXXX",
"    ...XXXXXXXXXXX......XXXXXXXX",
"     ....XXXXXXX.....X..XXXXXXXX",
"      ................X..XXXXXXX",
"        ...............X..XXXXXX",
"         ...X.X.X.X........XXXXX",
"          .X.X.X.X.X....o...XXXX",
"          ..X.X.X.X.X..ooo...XXX",
"          .XXXXXXXXX.X..ooo...XX",
"          .XXXXXXXXXX.X..ooo...X",
"          .XXXXXXXXXXX.X..ooo...",
"          .XXXXXXXXXXXX.X..ooo..",
"          .XXXXXXXXXXXXX.X..ooo.",
"          .XXXXXXXXXXXXXX.X..ooo",
"          .XXXXXXXXXXXXXXX.X..oo"};

GtkWidget*
get_widget                             (GtkWidget       *widget,
                                        gchar           *widget_name)
{
  GtkWidget *parent, *found_widget;

  for (;;)
    {
      if (GTK_IS_MENU (widget))
        parent = gtk_menu_get_attach_widget (GTK_MENU (widget));
      else
        parent = widget->parent;
      if (parent == NULL)
        break;
      widget = parent;
    }

  found_widget = (GtkWidget*) gtk_object_get_data (GTK_OBJECT (widget),
                                                   widget_name);
  if (!found_widget)
    g_warning ("Widget not found: %s", widget_name);
  return found_widget;
}

void clear_func() {
	
	gtk_window_set_policy (GTK_WINDOW (MainWindow), TRUE, TRUE, TRUE);
        gtk_widget_set_usize (MainWindow, 431, 225);
	gtk_widget_realize(MainWindow);
	gtk_window_set_policy (GTK_WINDOW (MainWindow), FALSE, FALSE, TRUE);
	
	gtk_text_backward_delete( GTK_TEXT (text3), OutPutLength);
	gtk_entry_set_text( GTK_ENTRY(entry8), "" );
	gtk_entry_set_text( GTK_ENTRY(entry9), "" );

	gtk_widget_show(MainWindow);
}

void show_wrk_dlg() {

	gtk_widget_show (WrkWindow);
}

void start_search() {

	gchar *XdictEntryGer;
	gchar *XdictEntryEng;
	gint SpinVal;

	gtk_window_set_policy (GTK_WINDOW (MainWindow), TRUE, TRUE, TRUE);
	gtk_widget_set_usize (MainWindow, 431, 448);
	gtk_widget_realize(MainWindow);
	gtk_window_set_policy (GTK_WINDOW (MainWindow), FALSE, FALSE, TRUE);
				
	XdictEntryGer = gtk_entry_get_text(GTK_ENTRY(entry8));
	XdictEntryEng = gtk_entry_get_text(GTK_ENTRY(entry9));
	SpinVal = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
	
	gtk_text_backward_delete( GTK_TEXT (text3), OutPutLength);
	
	gtk_text_freeze(GTK_TEXT (text3));
			
	if ((strlen(XdictEntryGer) > 0) && (strlen(XdictEntryEng) > 0)) {
		icFlag = 0;
		fuzzy_main(XdictEntryGer, SpinVal);
		}
		
	else if	((strlen(XdictEntryGer) > 0) && (strlen(XdictEntryEng) == 0)) {
		icFlag = 0;
		fuzzy_main(XdictEntryGer, SpinVal);
		}
		
	else if	((strlen(XdictEntryGer) == 0) && (strlen(XdictEntryEng) > 0)) {	
		icFlag = 1;
		fuzzy_main(XdictEntryEng, SpinVal);
		}

	else	{
		icFlag = 0;
		fuzzy_main(XdictEntryGer, SpinVal);	
		}		
		
	gtk_text_thaw(GTK_TEXT (text3));
	
	gtk_widget_hide (WrkWindow);
	gtk_widget_show(MainWindow);
	
}

long PrepareTheString(char* ConvStr, char* OriginStr)
{
	char* TmpPtr;

	for(TmpPtr = ConvStr; *OriginStr; TmpPtr++, OriginStr++)
		{
			*TmpPtr = tolower(*OriginStr);
			if(*OriginStr < '0')
				*TmpPtr = ' ';
			else
				switch((unsigned char)*TmpPtr)
					{
						case 196: *TmpPtr = 228; break;
						case 214: *TmpPtr = 246; break;
						case 220: *TmpPtr = 252; break;
						case 142: *TmpPtr = 132; break;
						case 153: *TmpPtr = 148; break;
						case 154: *TmpPtr = 129; break;
						case ':': *TmpPtr = ' '; break;
						case ';': *TmpPtr = ' '; break;
						case '<': *TmpPtr = ' '; break;
						case '>': *TmpPtr = ' '; break;
						case '=': *TmpPtr = ' '; break;
						case '?': *TmpPtr = ' '; break;
						case '[': *TmpPtr = ' '; break;
						case ']': *TmpPtr = ' '; break;
					}
		}
		
	*TmpPtr = '\0';
	return ( TmpPtr - ConvStr);
}

int NGramMatch(char* TextPara, char* SearchStr,
			int SearchStrLen, int NGramLen, int* MaxMatch)

{
	char NGram[8];
	int NGramCount, i, Count;

	NGram[NGramLen] = '\0';
	NGramCount = SearchStrLen - NGramLen + 1;

	for(i=0, Count = 0, *MaxMatch = 0; i < NGramCount; i++)
		{
			memcpy(NGram, &SearchStr[i], NGramLen);

			if (NGram[NGramLen -2] == ' ' && NGram[0] != ' ')
				i += NGramLen - 3;
			else
			{
				*MaxMatch += NGramLen;
				if(strstr(TextPara, NGram)) Count ++;
			}
		}
	return Count * NGramLen;
}

int FuzzyMatching(FILE *InFile, char* SearchStr, int Threshold)
{
	char TextPara[MaxParLen] = " ";
	char TextBuffer[MaxParLen];
	char ErrOutString[200];
	int TextLen, SearchStrLen;
	int NGram1Len, NGram2Len;
	int MatchCount1, MatchCount2;	
	int MaxMatch1, MaxMatch2;
	int cntA, cntB;
	float Similarity, BestSim = 0.0;
	char GString[200];
	char EString[200];
	char ParserOutString[200];
 
	GdkFont *fixed_font;
	fixed_font = gdk_font_load("-misc-fixed-small-r-*-*-*-120-*-*-*-*-*-*");
	
	SearchStrLen = PrepareTheString(SearchStr,SearchStr);
	NGram1Len = 3;
	NGram2Len = (SearchStrLen < 7) ? 2 : 5;

	fseek (InFile, 0L, SEEK_SET);
	while(fgets(TextBuffer, MaxParLen - 1, InFile))
	
	{
		TextLen = PrepareTheString(&TextPara[1], TextBuffer);
		if(TextLen < MaxParLen - 2)
			{
				MatchCount1 = NGramMatch(TextPara, SearchStr,
					SearchStrLen, NGram1Len, &MaxMatch1);
				MatchCount2 = NGramMatch(TextPara, SearchStr,
					SearchStrLen, NGram2Len, &MaxMatch2);

				Similarity = 100.0
					* (float)(MatchCount1 + MatchCount2)
					/ (float)(MaxMatch1 + MaxMatch2);
			
				if(Similarity > BestSim)
					BestSim = Similarity;
			
				if(Similarity >= Threshold) {

	for(cntA=0; cntA<=strlen(TextBuffer); cntA++) {
	
		if(TextBuffer[cntA] == '#') {
		
			/* String Init and Reset */
			for(cntB=0; cntB <= 200; cntB++) {
		 		GString[cntB] = '\0';
				ParserOutString[cntB] = '\0';
				EString[cntB] = '\0';
			}
		
			strncpy(GString, TextBuffer, cntA );
			
			/* Delete Return of TextBuffer */
			for(cntB=0; cntB <= strlen(TextBuffer); cntB++)
				if (TextBuffer[cntB] == '\n')
					TextBuffer[cntB] = '\0';
			
			strcpy(EString, strchr(TextBuffer, '#')+1 );
			
			/* And put it all to the ParserOutString String */
			
			if (icFlag == 0)
				sprintf(ParserOutString, "%s = %s\n", GString, EString);
			else if (icFlag == 1)
				sprintf(ParserOutString, "%s = %s\n", EString, GString);
			
			break;
		
		}

	}
	
	gtk_text_insert (GTK_TEXT (text3), fixed_font, NULL, NULL, ParserOutString, -1);
	OutPutLength = gtk_text_get_length( GTK_TEXT (text3));

				}
	}
		
		else
			{
				return 1;
			}
	}

	if(BestSim < Threshold) {
	
	  /* printf("Kein Treffer; h�chster Treffer war %.1f\n", BestSim); */
	
	  sprintf(ErrOutString, "--> No hits; best result was %.1f%%, try again...\n", BestSim);
	  gtk_text_insert (GTK_TEXT (text3), fixed_font, NULL, NULL, ErrOutString, -1);
	  OutPutLength = gtk_text_get_length( GTK_TEXT (text3));
	}
	
	return 0;
}

extern fuzzy_main(char SearchStr[256], int SpinVal) {

	FILE *InFile;
	int Threshold;

	InFile = fopen(DictFile, "r");
			
	if(InFile == NULL) {
			printf("\n Error: xdict database not available, use\n");
			printf(" --d option to specify location of xdict.dat.\n");
			printf(" (Use --h for help or read documentation...)\n\n");
			exit(0);
			}
								
		while(!feof(InFile)) {
			
			if(strcmp(SearchStr, " ")) {
			Threshold = SpinVal;
			
			FuzzyMatching(InFile, SearchStr, Threshold);
			
			}

		}

	fclose(InFile);
	return 0;
	
}

GtkWidget*
create_MainWindow ()
{
  GtkWidget *fixed4;
  GtkWidget *menubar2;
  GtkWidget *File2;
  GtkWidget *File2_menu;
  GtkWidget *Quit2;
  GtkWidget *Edit2;
  GtkWidget *Edit2_menu;
  GtkWidget *translate;
  GtkWidget *item17;
  GtkWidget *About2;
  GtkWidget *About2_menu;
  GtkWidget *Info2;
  GtkWidget *frame4;
  GtkWidget *fixed10;
  GtkWidget *label13;
  GtkWidget *label12;
  GtkWidget *frame5;
  GtkWidget *fixed11;
  GtkWidget *button7;
  GtkWidget *button9;
  GtkWidget *vseparator1;
  GtkWidget *label14;
  GtkWidget *frame6;
  GtkWidget *fixed12;
  GtkWidget *vscrollbar1;
  GtkTooltips *tooltips;

  tooltips = gtk_tooltips_new ();

  MainWindow = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (MainWindow), "MainWindow", MainWindow);
  gtk_widget_set_usize (MainWindow, 431, 225);
  gtk_window_set_title (GTK_WINDOW (MainWindow), "xdict 1.0.6");
  gtk_window_position (GTK_WINDOW (MainWindow), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (MainWindow), FALSE, FALSE, TRUE);
  
  gtk_signal_connect (GTK_OBJECT (MainWindow), "destroy",
                      GTK_SIGNAL_FUNC (gtk_main_quit),
                      NULL);

  fixed4 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "fixed4", fixed4);
  gtk_widget_show (fixed4);
  gtk_container_add (GTK_CONTAINER (MainWindow), fixed4);

  menubar2 = gtk_menu_bar_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "menubar2", menubar2);
  gtk_widget_show (menubar2);
  gtk_fixed_put (GTK_FIXED (fixed4), menubar2, -1, -1);
  gtk_widget_set_uposition (menubar2, 0, 0);
  gtk_widget_set_usize (menubar2, 432, 24);

  File2 = gtk_menu_item_new_with_label ("File");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "File2", File2);
  gtk_widget_show (File2);
  gtk_container_add (GTK_CONTAINER (menubar2), File2);

  File2_menu = gtk_menu_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "File2_menu", File2_menu);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (File2), File2_menu);

  Quit2 = gtk_menu_item_new_with_label ("Quit");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "Quit2", Quit2);
  gtk_widget_show (Quit2);
  gtk_container_add (GTK_CONTAINER (File2_menu), Quit2);
  gtk_signal_connect (GTK_OBJECT (Quit2), "activate",
                      GTK_SIGNAL_FUNC (on_Quit2_activate),
                      NULL);

  Edit2 = gtk_menu_item_new_with_label ("Edit");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "Edit2", Edit2);
  gtk_widget_show (Edit2);
  gtk_container_add (GTK_CONTAINER (menubar2), Edit2);

  Edit2_menu = gtk_menu_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "Edit2_menu", Edit2_menu);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (Edit2), Edit2_menu);
   
  item17 = gtk_menu_item_new_with_label ("clear");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "item17", item17);
  gtk_widget_show (item17);
  gtk_container_add (GTK_CONTAINER (Edit2_menu), item17);
  gtk_signal_connect (GTK_OBJECT (item17), "activate",
                      GTK_SIGNAL_FUNC (on_item17_activate),
                      NULL);

  About2 = gtk_menu_item_new_with_label ("About");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "About2", About2);
  gtk_widget_show (About2);
  gtk_container_add (GTK_CONTAINER (menubar2), About2);
  gtk_menu_item_right_justify (GTK_MENU_ITEM (About2));

  About2_menu = gtk_menu_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "About2_menu", About2_menu);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (About2), About2_menu);

  Info2 = gtk_menu_item_new_with_label ("Info");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "Info2", Info2);
  gtk_widget_show (Info2);
  gtk_container_add (GTK_CONTAINER (About2_menu), Info2);
  
  gtk_signal_connect (GTK_OBJECT (Info2), "activate",
                      GTK_SIGNAL_FUNC (on_Info2_activate),
                      NULL);

  frame4 = gtk_frame_new ("Translate");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "frame4", frame4);
  gtk_widget_show (frame4);
  gtk_fixed_put (GTK_FIXED (fixed4), frame4, 8, 32);
  gtk_widget_set_uposition (frame4, 8, 32);
  gtk_widget_set_usize (frame4, 416, 104);

  fixed10 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "fixed10", fixed10);
  gtk_widget_show (fixed10);
  gtk_container_add (GTK_CONTAINER (frame4), fixed10);

  entry8 = gtk_entry_new_with_max_length(50);
  gtk_object_set_data (GTK_OBJECT (MainWindow), "entry8", entry8);
  gtk_widget_show (entry8);
  gtk_fixed_put (GTK_FIXED (fixed10), entry8, 64, 16);
  gtk_widget_set_uposition (entry8, 64, 16);
  gtk_widget_set_usize (entry8, 336, 22);
  
  entry9 = gtk_entry_new_with_max_length(50);
  gtk_object_set_data (GTK_OBJECT (MainWindow), "entry9", entry9);
  gtk_widget_show (entry9);
  gtk_fixed_put (GTK_FIXED (fixed10), entry9, 64, 48);
  gtk_widget_set_uposition (entry9, 64, 48);
  gtk_widget_set_usize (entry9, 336, 22);

  label13 = gtk_label_new ("German");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "label13", label13);
  gtk_widget_show (label13);
  gtk_fixed_put (GTK_FIXED (fixed10), label13, 8, 16);
  gtk_widget_set_uposition (label13, 8, 16);
  gtk_widget_set_usize (label13, 56, 24);
  gtk_misc_set_alignment (GTK_MISC (label13), 0, 0.5);

  label12 = gtk_label_new ("English");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "label12", label12);
  gtk_widget_show (label12);
  gtk_fixed_put (GTK_FIXED (fixed10), label12, 8, 48);
  gtk_widget_set_uposition (label12, 8, 48);
  gtk_widget_set_usize (label12, 56, 24);
  gtk_misc_set_alignment (GTK_MISC (label12), 0, 0.5);

  frame5 = gtk_frame_new ("Settings");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "frame5", frame5);
  gtk_widget_show (frame5);
  gtk_fixed_put (GTK_FIXED (fixed4), frame5, 8, 144);
  gtk_widget_set_uposition (frame5, 8, 144);
  gtk_widget_set_usize (frame5, 416, 72);

  fixed11 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "fixed11", fixed11);
  gtk_widget_show (fixed11);
  gtk_container_add (GTK_CONTAINER (frame5), fixed11);

  spinbutton1_adj = gtk_adjustment_new (90, 0, 100, 5, 10, 10);
  spinbutton1 = gtk_spin_button_new (GTK_ADJUSTMENT (spinbutton1_adj), 1, 0);
  gtk_object_set_data (GTK_OBJECT (MainWindow), "spinbutton1", spinbutton1);
  gtk_widget_show (spinbutton1);
  gtk_fixed_put (GTK_FIXED (fixed11), spinbutton1, 96, 16);
  gtk_widget_set_uposition (spinbutton1, 96, 16);
  gtk_widget_set_usize (spinbutton1, 56, 24);

  button7 = gtk_button_new_with_label ("translate");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "button7", button7);
  gtk_widget_show (button7);
  gtk_fixed_put (GTK_FIXED (fixed11), button7, 312, 16);
  gtk_widget_set_uposition (button7, 312, 16);
  gtk_widget_set_usize (button7, 78, 24);
  gtk_tooltips_set_tip (tooltips, button7, "start translation", NULL);
      
  gtk_signal_connect (GTK_OBJECT(button7), "pressed", 
	              GTK_SIGNAL_FUNC (show_wrk_dlg), NULL);		      
		      
  gtk_signal_connect (GTK_OBJECT(button7), "released", 
	              GTK_SIGNAL_FUNC (start_search), NULL);
		      
  button9 = gtk_button_new_with_label ("clear");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "button9", button9);
  gtk_widget_show (button9);
  gtk_fixed_put (GTK_FIXED (fixed11), button9, 208, 16);
  gtk_widget_set_uposition (button9, 208, 16);
  gtk_widget_set_usize (button9, 78, 24);
  gtk_tooltips_set_tip (tooltips, button9, "clear textfields", NULL);
  
  gtk_signal_connect (GTK_OBJECT(button9), "clicked", 
	              GTK_SIGNAL_FUNC (clear_func), NULL);

  vseparator1 = gtk_vseparator_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "vseparator1", vseparator1);
  gtk_widget_show (vseparator1);
  gtk_fixed_put (GTK_FIXED (fixed11), vseparator1, 168, 0);
  gtk_widget_set_uposition (vseparator1, 168, 0);
  gtk_widget_set_usize (vseparator1, 16, 48);

  label14 = gtk_label_new ("Match [%]");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "label14", label14);
  gtk_widget_show (label14);
  gtk_fixed_put (GTK_FIXED (fixed11), label14, 16, 16);
  gtk_widget_set_uposition (label14, 16, 16);
  gtk_widget_set_usize (label14, 72, 24);
  gtk_misc_set_alignment (GTK_MISC (label14), 0, 0.5);

  frame6 = gtk_frame_new ("Results");
  gtk_object_set_data (GTK_OBJECT (MainWindow), "frame6", frame6);
  gtk_widget_show (frame6);
  gtk_fixed_put (GTK_FIXED (fixed4), frame6, 8, 232);
  gtk_widget_set_uposition (frame6, 8, 232);
  gtk_widget_set_usize (frame6, 416, 208);

  fixed12 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (MainWindow), "fixed12", fixed12);
  gtk_widget_show (fixed12);
  gtk_container_add (GTK_CONTAINER (frame6), fixed12);

  text3 = gtk_text_new (NULL, NULL);
  gtk_object_set_data (GTK_OBJECT (MainWindow), "text3", text3);
  gtk_widget_show (text3);
  gtk_fixed_put (GTK_FIXED (fixed12), text3, 8, 8);
  gtk_widget_set_uposition (text3, 8, 8);
  gtk_widget_set_usize (text3, 376, 176);

  vscrollbar1 = gtk_vscrollbar_new (GTK_TEXT (text3)->vadj);
  gtk_object_set_data (GTK_OBJECT (MainWindow), "vscrollbar1", vscrollbar1);
  gtk_widget_show (vscrollbar1);
  gtk_fixed_put (GTK_FIXED (fixed12), vscrollbar1, 392, 8);
  gtk_widget_set_uposition (vscrollbar1, 392, 8);
  gtk_widget_set_usize (vscrollbar1, 16, 176);

  vscrollbar1 = gtk_vscrollbar_new (GTK_TEXT (text3)->vadj);
  gtk_object_set_data (GTK_OBJECT (MainWindow), "tooltips", tooltips);

  return MainWindow;
}

GtkWidget*
create_AboutWindow ()
{
  GtkWidget *AboutWindow, *pixmapwid;
  GtkWidget *fixed5;
  GtkWidget *frame1;
  GtkWidget *fixed6;
  GtkWidget *button6;
  GtkWidget *label11;
  GtkWidget *hseparator1;
  GtkWidget *label8;
  GtkWidget *label9;
  GtkWidget *label7;
  GtkStyle *style;
  GdkBitmap *mask;
  GdkPixmap *gdkpixmap;   
  
  AboutWindow = gtk_window_new (GTK_WINDOW_DIALOG);
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "AboutWindow", AboutWindow);
  gtk_widget_set_usize (AboutWindow, 347, 168);
  gtk_window_set_title (GTK_WINDOW (AboutWindow), "About");
  gtk_window_position (GTK_WINDOW (AboutWindow), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (AboutWindow), FALSE, FALSE, FALSE);

  fixed5 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "fixed5", fixed5);
  gtk_widget_show (fixed5);
  gtk_container_add (GTK_CONTAINER (AboutWindow), fixed5);

  frame1 = gtk_frame_new (NULL);
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "frame1", frame1);
  gtk_widget_show (frame1);
  gtk_fixed_put (GTK_FIXED (fixed5), frame1, 6, 6);
  gtk_widget_set_uposition (frame1, 6, 6);
  gtk_widget_set_usize (frame1, 336, 156);

  fixed6 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "fixed6", fixed6);
  gtk_widget_show (fixed6);
  gtk_container_add (GTK_CONTAINER (frame1), fixed6);

  button6 = gtk_button_new_with_label ("OK");
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "button6", button6);
  gtk_widget_show (button6);
  gtk_fixed_put (GTK_FIXED (fixed6), button6, 244, 120);
  gtk_widget_set_uposition (button6, 244, 120);
  gtk_widget_set_usize (button6, 78, 24);
  
  gtk_signal_connect (GTK_OBJECT(button6), "button_press_event",  /* unload about */
	              GTK_SIGNAL_FUNC (unload_about_window), NULL);
		      
  /* statically import pixmap start */
    
  gtk_widget_realize(AboutWindow);
  
  style = gtk_widget_get_style( AboutWindow );
  gdkpixmap = gdk_pixmap_create_from_xpm_d( AboutWindow->window,  &mask,
                                           &style->bg[GTK_STATE_NORMAL],
                                           (gchar **)xdict_xpm );
					   
  pixmapwid = gtk_pixmap_new( gdkpixmap, mask ); 
  
  gtk_fixed_put (GTK_FIXED (fixed6), pixmapwid, 6, 6);
  gtk_widget_set_uposition (pixmapwid, 6, 6);
  gtk_widget_set_usize (pixmapwid, 48, 36);
  gtk_widget_show (pixmapwid);
  
  /* statically import pixmap manually end */

  label11 = gtk_label_new ("http://pubwww.fhzh.ch/~mgloor");
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "label11", label11);
  gtk_widget_show (label11);
  gtk_fixed_put (GTK_FIXED (fixed6), label11, 12, 126);
  gtk_widget_set_uposition (label11, 12, 126);
  gtk_widget_set_usize (label11, 186, 18);
  gtk_label_set_justify (GTK_LABEL (label11), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label11), 0, 0.5);

  hseparator1 = gtk_hseparator_new ();
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "hseparator1", hseparator1);
  gtk_widget_show (hseparator1);
  gtk_fixed_put (GTK_FIXED (fixed6), hseparator1, 12, 42);
  gtk_widget_set_uposition (hseparator1, 12, 42);
  gtk_widget_set_usize (hseparator1, 306, 16);
  
  label8 = gtk_label_new ("scientific fuzzylogic algorithm implementation");
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "label8", label8);
  gtk_widget_show (label8);
  gtk_fixed_put (GTK_FIXED (fixed6), label8, 60, 24);
  gtk_widget_set_uposition (label8, 60, 24);
  gtk_widget_set_usize (label8, 258, 18);
  gtk_misc_set_alignment (GTK_MISC (label8), 0, 0.5);

  label9 = gtk_label_new ("xdict 1.0.6 for Linux X11 (rel. mai 2003)");
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "label9", label9);
  gtk_widget_show (label9);
  gtk_fixed_put (GTK_FIXED (fixed6), label9, 60, 6);
  gtk_widget_set_uposition (label9, 60, 6);
  gtk_widget_set_usize (label9, 244, 18);
  gtk_misc_set_alignment (GTK_MISC (label9), 0, 0.5);

  label7 = gtk_label_new ("Eng/Ger dictionary (about 130'000 conversions)\nwritten by Marc O. Gloor <mgloor@fhzh.ch>\nSoftware is licensed under the GPL");
  gtk_object_set_data (GTK_OBJECT (AboutWindow), "label7", label7);
  gtk_widget_show (label7);
  gtk_fixed_put (GTK_FIXED (fixed6), label7, 12, 66);
  gtk_widget_set_uposition (label7, 12, 66);
  gtk_widget_set_usize (label7, 308, 46);
  gtk_label_set_justify (GTK_LABEL (label7), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label7), 0, 0.5);

  return AboutWindow;
}

GtkWidget*
create_WrkWindow ()
{
  GtkWidget *fixed13;
  GtkWidget *frame7;
  GtkWidget *fixed14;
  GtkWidget *label15;

  WrkWindow = gtk_window_new (GTK_WINDOW_DIALOG);
  gtk_object_set_data (GTK_OBJECT (WrkWindow), "WrkWindow", WrkWindow);
  gtk_widget_set_usize (WrkWindow, 311, 74);
  gtk_window_set_title (GTK_WINDOW (WrkWindow), "working...");
  gtk_window_position (GTK_WINDOW (WrkWindow), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (WrkWindow), FALSE, FALSE, FALSE);

  fixed13 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (WrkWindow), "fixed13", fixed13);
  gtk_widget_show (fixed13);
  gtk_container_add (GTK_CONTAINER (WrkWindow), fixed13);

  frame7 = gtk_frame_new (NULL);
  gtk_object_set_data (GTK_OBJECT (WrkWindow), "frame7", frame7);
  gtk_widget_show (frame7);
  gtk_fixed_put (GTK_FIXED (fixed13), frame7, 8, 8);
  gtk_widget_set_uposition (frame7, 8, 8);
  gtk_widget_set_usize (frame7, 296, 58);
  
  fixed14 = gtk_fixed_new ();
  gtk_object_set_data (GTK_OBJECT (WrkWindow), "fixed14", fixed14);
  gtk_widget_show (fixed14);
  gtk_container_add (GTK_CONTAINER (frame7), fixed14);

  label15 = gtk_label_new ("Scanning database, please wait...");
  gtk_object_set_data (GTK_OBJECT (WrkWindow), "label15", label15);
  gtk_widget_show (label15);
  gtk_fixed_put (GTK_FIXED (fixed14), label15, 8, 16);
  gtk_widget_set_uposition (label15, 8, 16);
  gtk_widget_set_usize (label15, 280, 24);

  return WrkWindow;
}
