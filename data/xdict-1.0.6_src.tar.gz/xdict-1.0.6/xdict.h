/*
 * xdict 1.0 patchlevel 6
 * Copyright (C) 2001 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <gtk/gtk.h>

GtkWidget* create_MainWindow (void);
GtkWidget* create_AboutWindow (void);
GtkWidget* create_WrkWindow (void);

GtkWidget*
get_widget                             (GtkWidget       *widget,
                                        gchar           *widget_name);

void
set_notebook_tab                       (GtkWidget       *notebook,
                                        gint             page_num,
                                        GtkWidget       *widget);

void
add_pixmap_directory                   (gchar           *directory);

GtkWidget*
create_pixmap                          (GtkWidget       *widget,
                                        gchar           *filename);
					
void
on_Quit2_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_item17_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_Info2_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_translate_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data);
