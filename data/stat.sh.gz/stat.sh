#!/bin/sh
#
# training analysis & summary
# written by Marc O. Gloor <mgloor@fhzh.ch>
#
# $Id: stat.sh,v 1.2 2005/02/08 16:12:52 gloor Exp $
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

echo "you have to personalize this script before execute! (db password...)"
exit

TMPFILE=/tmp/.datenexport.db
TMPFILE2=/tmp/.datenexport2.db
TMPFILE3=/tmp/.datenexport3.db
rm $TMPFILE >/dev/null 2>&1
rm $TMPFILE2 >/dev/null 2>&1
rm $TMPFILE3 >/dev/null 2>&1

#header
clear
echo "LAUFTRAINING STATISTIK  MARC GLOOR"
echo "mySQL-Datenbankname: joglog"
echo -n "Report generiert: " ; date
echo "============================================================================"
echo ""

mysql -hlocalhost -uroot -p<password> joglog << EOF
SELECT COUNT(*) AS trainingseinheiten, ((TO_DAYS(CURDATE()) - TO_DAYS("2004-10-01"))+1) / COUNT(*) AS jeden_xten_tag_trainiert, SUM(HOUR(trainingsdaten.trainingsdauer)*60 + MINUTE(trainingsdaten.trainingsdauer))/60 AS sum_trainingsdauer,  SUM(streckendaten.lkm) AS sum_lkm, AVG(streckendaten.lkm * 60 / (HOUR(trainingsdaten.trainingsdauer) * 60 + MINUTE(trainingsdaten.trainingsdauer))) AS Vavg, AVG(streckendaten.lkm) AS avg_lkm, AVG(biodaten.gewicht) as avg_gewicht, AVG(biodaten.gewicht * 10000 / (biodaten.groesse * biodaten.groesse)) AS avg_bmi FROM trainingsdaten, streckendaten, biodaten WHERE trainingsdaten.strid = streckendaten.strid AND trainingsdaten.bioid = biodaten.bioid AND trainingsdaten.trainingsdatum >= "2004-10-01" AND trainingsdaten.trainingsdatum <= CURDATE() ORDER BY trainingsdatum INTO OUTFILE "/tmp/.datenexport.db" FIELDS TERMINATED BY ';';
EOF

TRAINEINHTOT=$(awk 'split($0, token, ";") { print token[1]}' $TMPFILE)
MITTELTRAINTOT=$(awk 'split($0, token, ";") { print token[2]}' $TMPFILE)
TOTTRAINTOT=$(awk 'split($0, token, ";") { print token[3]}' $TMPFILE)
TOTLEISTTOT=$(awk 'split($0, token, ";") { print token[4]}' $TMPFILE)
MITVTOT=$(awk 'split($0, token, ";") { print token[5]}' $TMPFILE)
MITNAZKMTOT=$(awk 'split($0, token, ";") { print token[6]}' $TMPFILE)
MITTGEWTOT=$(awk 'split($0, token, ";") { print token[7]}' $TMPFILE)
MITTBMITOT=$(awk 'split($0, token, ";") { print token[8]}' $TMPFILE)

rm $TMPFILE >/dev/null 2>&1


mysql -hlocalhost -uroot -p<password> joglog << EOF
SELECT COUNT(*) AS trainingseinheiten, ((TO_DAYS(CURDATE()) - TO_DAYS(DATE_SUB(CURDATE(), INTERVAL 30 DAY)))) / COUNT(*) AS jeden_xten_tag_trainiert, SUM(HOUR(trainingsdaten.trainingsdauer)*60 + MINUTE(trainingsdaten.trainingsdauer))/60 AS sum_trainingsdauer,  SUM(streckendaten.lkm) AS sum_lkm, AVG(streckendaten.lkm * 60 / (HOUR(trainingsdaten.trainingsdauer) * 60 + MINUTE(trainingsdaten.trainingsdauer))) AS Vavg, AVG(streckendaten.lkm) AS avg_lkm, AVG(biodaten.gewicht) as avg_gewicht, AVG(biodaten.gewicht * 10000 / (biodaten.groesse * biodaten.groesse)) AS avg_bmi FROM trainingsdaten, streckendaten, biodaten WHERE trainingsdaten.strid = streckendaten.strid AND trainingsdaten.bioid = biodaten.bioid AND trainingsdaten.trainingsdatum >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND trainingsdaten.trainingsdatum <= CURDATE() ORDER BY trainingsdatum INTO OUTFILE "/tmp/.datenexport3.db" FIELDS TERMINATED BY ';';
EOF
 
TRAINEINH30=$(awk 'split($0, token, ";") { print token[1]}' $TMPFILE3)
MITTELTRAIN30=$(awk 'split($0, token, ";") { print token[2]}' $TMPFILE3)
TOTTRAIN30=$(awk 'split($0, token, ";") { print token[3]}' $TMPFILE3)
TOTLEIST30=$(awk 'split($0, token, ";") { print token[4]}' $TMPFILE3)
MITV30=$(awk 'split($0, token, ";") { print token[5]}' $TMPFILE3)
MITNAZKM30=$(awk 'split($0, token, ";") { print token[6]}' $TMPFILE3)
MITTGEW30=$(awk 'split($0, token, ";") { print token[7]}' $TMPFILE3)
MITTBMI30=$(awk 'split($0, token, ";") { print token[8]}' $TMPFILE3)

rm $TMPFILE3 >/dev/null 2>&1

mysql -hlocalhost -uroot -p<password> joglog << EOF
SELECT COUNT(*) AS trainingseinheiten, ((TO_DAYS(CURDATE()) - TO_DAYS(DATE_SUB(CURDATE(), INTERVAL 7 DAY)))) / COUNT(*) AS jeden_xten_tag_trainiert, SUM(HOUR(trainingsdaten.trainingsdauer)*60 + MINUTE(trainingsdaten.trainingsdauer))/60 AS sum_trainingsdauer,  SUM(streckendaten.lkm) AS sum_lkm, AVG(streckendaten.lkm * 60 / (HOUR(trainingsdaten.trainingsdauer) * 60 + MINUTE(trainingsdaten.trainingsdauer))) AS Vavg, AVG(streckendaten.lkm) AS avg_lkm, AVG(biodaten.gewicht) as avg_gewicht, AVG(biodaten.gewicht * 10000 / (biodaten.groesse * biodaten.groesse)) AS avg_bmi FROM trainingsdaten, streckendaten, biodaten WHERE trainingsdaten.strid = streckendaten.strid AND trainingsdaten.bioid = biodaten.bioid AND trainingsdaten.trainingsdatum >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND trainingsdaten.trainingsdatum <= CURDATE() ORDER BY trainingsdatum INTO OUTFILE "/tmp/.datenexport2.db" FIELDS TERMINATED BY ';';
EOF
 

TRAINEINH7=$(awk 'split($0, token, ";") { print token[1]}' $TMPFILE2)
MITTELTRAIN7=$(awk 'split($0, token, ";") { print token[2]}' $TMPFILE2)
TOTTRAIN7=$(awk 'split($0, token, ";") { print token[3]}' $TMPFILE2)
TOTLEIST7=$(awk 'split($0, token, ";") { print token[4]}' $TMPFILE2)
MITV7=$(awk 'split($0, token, ";") { print token[5]}' $TMPFILE2)
MITNAZKM7=$(awk 'split($0, token, ";") { print token[6]}' $TMPFILE2)
MITTGEW7=$(awk 'split($0, token, ";") { print token[7]}' $TMPFILE2)
MITTBMI7=$(awk 'split($0, token, ";") { print token[8]}' $TMPFILE2)

rm $TMPFILE2 >/dev/null 2>&1

echo "                                  TOTAL		TOT-30-TAGE	TOT-7-TAGE"
echo "----------------------------------------------------------------------------"
echo -n "Total Trainingseinheiten        : " ; echo -n $TRAINEINHTOT ; echo -n "		" ; 
					       echo -n $TRAINEINH30 ; echo -n "		" ;
					       echo $TRAINEINH7
echo -n "Im Mittel alle x-Tage trainiert : " ; echo -n $MITTELTRAINTOT ; echo -n "		"
					       echo -n $MITTELTRAIN30 ; echo -n "		" ;
					       echo $MITTELTRAIN7
echo -n "Total Trainingsdauer [h]        : " ; echo -n $TOTTRAINTOT ; echo -n "		" ; 
					       echo -n $TOTTRAIN30 ; echo -n "		" ;
					       echo $TOTTRAIN7
echo -n "Total Leistungskilometer [km]   : " ; echo -n $TOTLEISTTOT ; echo -n "	" ; 
					       echo -n $TOTLEIST30 ; echo -n "		" ;
					       echo $TOTLEIST7
echo -n "Mittlere Geschwindigkeit [km/h] : " ; echo -n $MITVTOT ; echo -n "	" ; 
					       echo -n $MITV30 ; echo -n "	" ;
					       echo $MITV7
echo -n "Mittlere Anzahl Km/Training [km]: " ; echo -n $MITNAZKMTOT ; echo -n "	" ; 
					       echo -n $MITNAZKM30 ; echo -n "	" ;
					       echo $MITNAZKM7
echo -n "Mittleres Gewicht/Training [kg] : " ; echo -n $MITTGEWTOT ; echo -n "	" ; 
					       echo -n $MITTGEW30 ; echo -n "	" ;
					       echo $MITTGEW7
echo -n "Mittlerer BMI/Trainingseinheit  : " ; echo -n $MITTBMITOT ; echo -n "	" ; 
					       echo -n $MITTBMI30 ; echo -n "	" ;
					       echo $MITTBMI7

echo ""
