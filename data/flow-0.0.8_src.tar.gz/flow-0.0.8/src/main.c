/*
 * flow - floating point operations per second benchmark
 * Copyright (C) 02/04/2000 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * $Id$
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "main.h"

/* Prototype */
void func_cmd_hlp();
void func_cmd_version();
int standby_statbar();

int
main (int argc, char *argv[])
{
  GtkWidget *main_wnd;
  GtkWidget *about_wnd;

  gtk_set_locale ();
  gtk_init (&argc, &argv);

  if (argc==2 && ((strcmp(argv[1], "--v") == 0) || 
                  (strcmp(argv[1], "-v") == 0))) {
  
	func_cmd_version();
	exit(0);
	
  }
	
  else if (argc==2 && ((strcmp(argv[1], "--h") == 0) ||
                       (strcmp(argv[1], "-h") == 0))) {
  
	func_cmd_hlp();
	exit(0);
	
	}
  
  else if (argc > 2 && (strcmp(argv[1], "--c") == 0)) {
  
    /* overhead ratio parser: check if specified ratio is valid */ 
  
  int ovhd;
  ovhd = atoi(argv[2]);
  
    if( (ovhd < 0) || (ovhd > 100) ){
    
        printf("\n error: invalid overhead ratio specified\n\n");
       	exit(0); 
    }
           
    /* if valid, parse specified overhead ratio and export */
    
    OVHD_RATIO = ovhd;

	}
   
  else if (argc==1 ) {
  
  /* if no arguments specified use 15% overhead ratio */
	
  OVHD_RATIO = 0;
	
	}	
		  
  main_wnd = create_main_wnd ();
  about_wnd = create_about_wnd ();
  gtk_widget_show (main_wnd);
  
  standby_statbar();

  gtk_main ();
  
  return 0;
}

void func_cmd_version() {
	
	printf("\n flow release 0.0.8 (custom build)\n");
	printf(" written by Marc O. Gloor <mgloor@fhzh.ch>\n");
	printf(" visit: http://pubwww.fhzh.ch/~mgloor\n\n");
  
  exit(0);
	
}

void func_cmd_hlp() {

	printf("\n syntax:  flow [arg1] [arg2]\n");
	printf(" usage :  flow --h --v --c [int]\n\n");
	printf(" arguments are:\n");
	printf("  --h        show help\n");
	printf("  --v        show version\n");
	printf("  --c [int]  calibration (see manpage)\n\n");
	printf(" example: flow --c 25\n\n");
  
  exit(0);
 
}
