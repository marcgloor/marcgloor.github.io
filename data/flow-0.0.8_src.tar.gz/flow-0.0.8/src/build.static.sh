#!/bin/sh 
# statically compiler shellscript for flow 0.0.8 

gcc -static -s -O2 \
`gtk-config --cflags` main.c kernel.c support.c interface.c callbacks.c \
-o flow \
-L/usr/local/lib \
-L/usr/X11R6/lib \
-L/usr/lib \
/usr/local/lib/libgtk.a \
/usr/local/lib/libgdk.a \
/usr/local/lib/libglib.a \
/usr/local/lib/libgmodule.a \
/usr/lib/libm.a \
/usr/lib/libdl.a \
/usr/i486-linuxlibc1/lib/libXext.a \
/usr/i486-linuxlibc1/lib/libX11.a
