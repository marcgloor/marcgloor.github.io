/*
 * flow - floating point operations per second benchmark
 * Copyright (C) 02/04/2000 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * $Id$
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "main.h"

void unload_about_window( GtkWidget *widget, GdkEvent *event, gpointer *data )
{ 
     	gtk_widget_hide (about_wnd);
}

GtkWidget*
create_main_wnd (void)
{
  GtkWidget *main_wnd;
  GtkWidget *fixed1;
  GtkWidget *handlebox1;
  GtkWidget *menubar1;
  GtkWidget *file1;
  GtkWidget *file1_menu;
  GtkAccelGroup *file1_menu_accels;
  GtkWidget *quit1;
  GtkWidget *edit1;
  GtkWidget *edit1_menu;
  GtkAccelGroup *edit1_menu_accels;
  GtkWidget *run_benchmark1;
  GtkWidget *clear_table1;
  GtkWidget *summary1_menu;
  GtkAccelGroup *summary1_menu_accels;
  GSList *sumset_group = NULL;
  GtkWidget *about1;
  GtkWidget *about1_menu;
  GtkAccelGroup *about1_menu_accels;
  GtkWidget *info1;
  GtkWidget *viewport1;
  GtkWidget *fixed2;
  GtkWidget *frame1;
  GtkWidget *fixed3;
  GtkWidget *hseparator1;
  GtkWidget *fixed7;
  GtkWidget *hseparator3;
  GtkWidget *vseparator1; 
  GtkWidget *vseparator2;
  GtkWidget *vseparator3;
  GtkWidget *vseparator4;
  GtkWidget *frame2;
  GtkWidget *fixed4;
  GtkWidget *separator2;

  main_wnd = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (main_wnd), "main_wnd", main_wnd);
  gtk_widget_set_usize (main_wnd, 468, 378);
  gtk_window_set_title (GTK_WINDOW (main_wnd), "FLOW 0.0.8");
  gtk_window_set_policy (GTK_WINDOW (main_wnd), FALSE, FALSE, FALSE);
  
  gtk_signal_connect (GTK_OBJECT (main_wnd), "destroy",
			GTK_SIGNAL_FUNC (gtk_exit), NULL);

  gtk_signal_connect (GTK_OBJECT (main_wnd), "delete_event",
			GTK_SIGNAL_FUNC (gtk_exit), NULL);

  fixed1 = gtk_fixed_new ();
  gtk_widget_ref (fixed1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "fixed1", fixed1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed1);
  gtk_container_add (GTK_CONTAINER (main_wnd), fixed1);
  gtk_widget_set_usize (fixed1, 468, 384);

  handlebox1 = gtk_handle_box_new ();
  gtk_widget_ref (handlebox1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "handlebox1", handlebox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (handlebox1);
  gtk_fixed_put (GTK_FIXED (fixed1), handlebox1, 0, 0);
  gtk_widget_set_uposition (handlebox1, 0, 0);
  gtk_widget_set_usize (handlebox1, 468, 24);

  menubar1 = gtk_menu_bar_new ();
  gtk_widget_ref (menubar1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "menubar1", menubar1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (menubar1);
  gtk_container_add (GTK_CONTAINER (handlebox1), menubar1);

  file1 = gtk_menu_item_new_with_label ("File");
  gtk_widget_ref (file1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "file1", file1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (file1);
  gtk_container_add (GTK_CONTAINER (menubar1), file1);

  file1_menu = gtk_menu_new ();
  gtk_widget_ref (file1_menu);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "file1_menu", file1_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (file1), file1_menu);
  file1_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (file1_menu));

  quit1 = gtk_menu_item_new_with_label ("Quit");
  gtk_widget_ref (quit1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "quit1", quit1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (quit1);
  gtk_container_add (GTK_CONTAINER (file1_menu), quit1);

  edit1 = gtk_menu_item_new_with_label ("Edit");
  gtk_widget_ref (edit1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "edit1", edit1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (edit1);
  gtk_container_add (GTK_CONTAINER (menubar1), edit1);

  edit1_menu = gtk_menu_new ();
  gtk_widget_ref (edit1_menu);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "edit1_menu", edit1_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (edit1), edit1_menu);
  edit1_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (edit1_menu));

  run_benchmark1 = gtk_menu_item_new_with_label ("Run Benchmark");
  gtk_widget_ref (run_benchmark1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "run_benchmark1", run_benchmark1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (run_benchmark1);
  gtk_container_add (GTK_CONTAINER (edit1_menu), run_benchmark1);

  clear_table1 = gtk_menu_item_new_with_label ("Clear Table");
  gtk_widget_ref (clear_table1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "clear_table1", clear_table1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (clear_table1);
  gtk_container_add (GTK_CONTAINER (edit1_menu), clear_table1);

  separator2 = gtk_menu_item_new ();
  gtk_widget_ref (separator2);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "separator2", separator2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (separator2);
  gtk_container_add (GTK_CONTAINER (edit1_menu), separator2);
  gtk_widget_set_sensitive (separator2, FALSE);

  summary1 = gtk_menu_item_new_with_label ("Summary");
  gtk_widget_ref (summary1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "summary1", summary1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (summary1);
  gtk_container_add (GTK_CONTAINER (edit1_menu), summary1);

  summary1_menu = gtk_menu_new ();
  gtk_widget_ref (summary1_menu);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "summary1_menu", summary1_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (summary1), summary1_menu);
  summary1_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (summary1_menu));

  mflops1 = gtk_radio_menu_item_new_with_label (sumset_group, "MFLOPS");
  sumset_group = gtk_radio_menu_item_group (GTK_RADIO_MENU_ITEM (mflops1));
  gtk_widget_ref (mflops1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "mflops1", mflops1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (mflops1);
  gtk_container_add (GTK_CONTAINER (summary1_menu), mflops1);

  gflops1 = gtk_radio_menu_item_new_with_label (sumset_group, "GFLOPS");
  sumset_group = gtk_radio_menu_item_group (GTK_RADIO_MENU_ITEM (gflops1));
  gtk_widget_ref (gflops1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "gflops1", gflops1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (gflops1);
  gtk_container_add (GTK_CONTAINER (summary1_menu), gflops1);
  gtk_check_menu_item_set_active (GTK_CHECK_MENU_ITEM (mflops1), TRUE);

  about1 = gtk_menu_item_new_with_label ("About ");
  gtk_widget_ref (about1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "about1", about1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (about1);
  gtk_container_add (GTK_CONTAINER (menubar1), about1);
  gtk_menu_item_right_justify (GTK_MENU_ITEM (about1));

  about1_menu = gtk_menu_new ();
  gtk_widget_ref (about1_menu);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "about1_menu", about1_menu,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_menu_item_set_submenu (GTK_MENU_ITEM (about1), about1_menu);
  about1_menu_accels = gtk_menu_ensure_uline_accel_group (GTK_MENU (about1_menu));

  info1 = gtk_menu_item_new_with_label ("Info...");
  gtk_widget_ref (info1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "info1", info1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (info1);
  gtk_container_add (GTK_CONTAINER (about1_menu), info1);

  viewport1 = gtk_viewport_new (NULL, NULL);
  gtk_widget_ref (viewport1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "viewport1", viewport1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (viewport1);
  gtk_fixed_put (GTK_FIXED (fixed1), viewport1, 0, 24);
  gtk_widget_set_uposition (viewport1, 0, 24);
  gtk_widget_set_usize (viewport1, 468, 354);
  gtk_viewport_set_shadow_type (GTK_VIEWPORT (viewport1), GTK_SHADOW_OUT);

  fixed2 = gtk_fixed_new ();
  gtk_widget_ref (fixed2);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "fixed2", fixed2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed2);
  gtk_container_add (GTK_CONTAINER (viewport1), fixed2);

  frame1 = gtk_frame_new ("module view");
  gtk_widget_ref (frame1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "frame1", frame1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame1);
  gtk_fixed_put (GTK_FIXED (fixed2), frame1, 6, 6);
  gtk_widget_set_uposition (frame1, 6, 6);
  gtk_widget_set_usize (frame1, 450, 212);

  fixed3 = gtk_fixed_new ();
  gtk_widget_ref (fixed3);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "fixed3", fixed3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed3);
  gtk_container_add (GTK_CONTAINER (frame1), fixed3);

  label6 = gtk_label_new ("Module");
  gtk_widget_ref (label6);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label6", label6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label6);
  gtk_fixed_put (GTK_FIXED (fixed3), label6, 12, 42);
  gtk_widget_set_uposition (label6, 12, 42);
  gtk_widget_set_usize (label6, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label6), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label6), 0, 0.5);

  label11 = gtk_label_new ("Module");
  gtk_widget_ref (label11);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label11", label11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label11);
  gtk_fixed_put (GTK_FIXED (fixed3), label11, 12, 60);
  gtk_widget_set_uposition (label11, 12, 60);
  gtk_widget_set_usize (label11, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label11), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label11), 0, 0.5);

  label13 = gtk_label_new ("Module");
  gtk_widget_ref (label13);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label13", label13,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label13);
  gtk_fixed_put (GTK_FIXED (fixed3), label13, 12, 78);
  gtk_widget_set_uposition (label13, 12, 78);
  gtk_widget_set_usize (label13, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label13), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label13), 0, 0.5);

  label14 = gtk_label_new ("Module");
  gtk_widget_ref (label14);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label14", label14,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label14);
  gtk_fixed_put (GTK_FIXED (fixed3), label14, 12, 96);
  gtk_widget_set_uposition (label14, 12, 96);
  gtk_widget_set_usize (label14, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label14), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label14), 0, 0.5);

  label15 = gtk_label_new ("Module");
  gtk_widget_ref (label15);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label15", label15,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label15);
  gtk_fixed_put (GTK_FIXED (fixed3), label15, 12, 114);
  gtk_widget_set_uposition (label15, 12, 114);
  gtk_widget_set_usize (label15, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label15), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label15), 0, 0.5);

  label16 = gtk_label_new ("Module");
  gtk_widget_ref (label16);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label16", label16,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label16);
  gtk_fixed_put (GTK_FIXED (fixed3), label16, 12, 132);
  gtk_widget_set_uposition (label16, 12, 132);
  gtk_widget_set_usize (label16, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label16), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label16), 0, 0.5);

  label18 = gtk_label_new ("Module");
  gtk_widget_ref (label18);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label18", label18,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label18);
  gtk_fixed_put (GTK_FIXED (fixed3), label18, 12, 168);
  gtk_widget_set_uposition (label18, 12, 168);
  gtk_widget_set_usize (label18, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label18), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label18), 0, 0.5);

  label10 = gtk_label_new ("118.9587");
  gtk_widget_ref (label10);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label10", label10,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label10);
  gtk_fixed_put (GTK_FIXED (fixed3), label10, 366, 42);
  gtk_widget_set_uposition (label10, 366, 42);
  gtk_widget_set_usize (label10, 72, 18);
  gtk_label_set_justify (GTK_LABEL (label10), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label10), 0, 0.5);

  hseparator1 = gtk_hseparator_new ();
  gtk_widget_ref (hseparator1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "hseparator1", hseparator1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hseparator1);
  gtk_fixed_put (GTK_FIXED (fixed3), hseparator1, 6, 24);
  gtk_widget_set_uposition (hseparator1, 6, 24);
  gtk_widget_set_usize (hseparator1, 432, 16);

  label1 = gtk_label_new ("Module:");
  gtk_widget_ref (label1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label1", label1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label1);
  gtk_fixed_put (GTK_FIXED (fixed3), label1, 12, 6);
  gtk_widget_set_uposition (label1, 12, 6);
  gtk_widget_set_usize (label1, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label1), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label1), 0, 0.5);

  label2 = gtk_label_new ("FErr:");
  gtk_widget_ref (label2);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label2", label2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label2);
  gtk_fixed_put (GTK_FIXED (fixed3), label2, 72, 6);
  gtk_widget_set_uposition (label2, 72, 6);
  gtk_widget_set_usize (label2, 66, 18);
  gtk_label_set_justify (GTK_LABEL (label2), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label2), 0, 0.5);

  label5 = gtk_label_new ("status:");
  gtk_widget_ref (label5);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label5", label5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label5);
  gtk_fixed_put (GTK_FIXED (fixed3), label5, 264, 6);
  gtk_widget_set_uposition (label5, 264, 6);
  gtk_widget_set_usize (label5, 66, 18);
  gtk_label_set_justify (GTK_LABEL (label5), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label5), 0, 0.5);

  label4 = gtk_label_new ("MFLOPS:");
  gtk_widget_ref (label4);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label4", label4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label4);
  gtk_fixed_put (GTK_FIXED (fixed3), label4, 366, 6);
  gtk_widget_set_uposition (label4, 366, 6);
  gtk_widget_set_usize (label4, 66, 18);
  gtk_label_set_justify (GTK_LABEL (label4), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label4), 0, 0.5);

  label12 = gtk_label_new ("Module");
  gtk_widget_ref (label12);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label12", label12,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label12);
  gtk_fixed_put (GTK_FIXED (fixed3), label12, 12, 42);
  gtk_widget_set_uposition (label12, 12, 42);
  gtk_widget_set_usize (label12, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label12), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label12), 0, 0.5);

  label3 = gtk_label_new ("Runtime usec:");
  gtk_widget_ref (label3);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label3", label3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label3);
  gtk_fixed_put (GTK_FIXED (fixed3), label3, 162, 6);
  gtk_widget_set_uposition (label3, 162, 6);
  gtk_widget_set_usize (label3, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label3), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label3), 0, 0.5);

  label17 = gtk_label_new ("Module");
  gtk_widget_ref (label17);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label17", label17,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label17);
  gtk_fixed_put (GTK_FIXED (fixed3), label17, 12, 150);
  gtk_widget_set_uposition (label17, 12, 150);
  gtk_widget_set_usize (label17, 54, 18);
  gtk_label_set_justify (GTK_LABEL (label17), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label17), 0, 0.5);

  label7 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label7);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label7", label7,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label7);
  gtk_fixed_put (GTK_FIXED (fixed3), label7, 72, 42);
  gtk_widget_set_uposition (label7, 72, 42);
  gtk_widget_set_usize (label7, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label7), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label7), 0, 0.5);

  label34 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label34);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label34", label34,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label34);
  gtk_fixed_put (GTK_FIXED (fixed3), label34, 72, 60);
  gtk_widget_set_uposition (label34, 72, 60);
  gtk_widget_set_usize (label34, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label34), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label34), 0, 0.5);

  label35 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label35);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label35", label35,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label35);
  gtk_fixed_put (GTK_FIXED (fixed3), label35, 72, 78);
  gtk_widget_set_uposition (label35, 72, 78);
  gtk_widget_set_usize (label35, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label35), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label35), 0, 0.5);

  label36 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label36);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label36", label36,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label36);
  gtk_fixed_put (GTK_FIXED (fixed3), label36, 72, 96);
  gtk_widget_set_uposition (label36, 72, 96);
  gtk_widget_set_usize (label36, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label36), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label36), 0, 0.5);

  label37 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label37);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label37", label37,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label37);
  gtk_fixed_put (GTK_FIXED (fixed3), label37, 72, 114);
  gtk_widget_set_uposition (label37, 72, 114);
  gtk_widget_set_usize (label37, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label37), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label37), 0, 0.5);

  label38 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label38);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label38", label38,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label38);
  gtk_fixed_put (GTK_FIXED (fixed3), label38, 72, 132);
  gtk_widget_set_uposition (label38, 72, 132);
  gtk_widget_set_usize (label38, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label38), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label38), 0, 0.5);

  label39 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label39);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label39", label39,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label39);
  gtk_fixed_put (GTK_FIXED (fixed3), label39, 72, 150);
  gtk_widget_set_uposition (label39, 72, 150);
  gtk_widget_set_usize (label39, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label39), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label39), 0, 0.5);

  label40 = gtk_label_new ("-5.4001e-13");
  gtk_widget_ref (label40);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label40", label40,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label40);
  gtk_fixed_put (GTK_FIXED (fixed3), label40, 72, 168);
  gtk_widget_set_uposition (label40, 72, 168);
  gtk_widget_set_usize (label40, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label40), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label40), 0, 0.5);

  label8 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label8);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label8", label8,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label8);
  gtk_fixed_put (GTK_FIXED (fixed3), label8, 162, 42);
  gtk_widget_set_uposition (label8, 162, 42);
  gtk_widget_set_usize (label8, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label8), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label8), 0, 0.5);

  label41 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label41);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label41", label41,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label41);
  gtk_fixed_put (GTK_FIXED (fixed3), label41, 162, 60);
  gtk_widget_set_uposition (label41, 162, 60);
  gtk_widget_set_usize (label41, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label41), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label41), 0, 0.5);

  label42 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label42);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label42", label42,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label42);
  gtk_fixed_put (GTK_FIXED (fixed3), label42, 162, 78);
  gtk_widget_set_uposition (label42, 162, 78);
  gtk_widget_set_usize (label42, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label42), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label42), 0, 0.5);

  label43 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label43);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label43", label43,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label43);
  gtk_fixed_put (GTK_FIXED (fixed3), label43, 162, 96);
  gtk_widget_set_uposition (label43, 162, 96);
  gtk_widget_set_usize (label43, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label43), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label43), 0, 0.5);

  label44 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label44);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label44", label44,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label44);
  gtk_fixed_put (GTK_FIXED (fixed3), label44, 162, 114);
  gtk_widget_set_uposition (label44, 162, 114);
  gtk_widget_set_usize (label44, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label44), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label44), 0, 0.5);

  label45 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label45);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label45", label45,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label45);
  gtk_fixed_put (GTK_FIXED (fixed3), label45, 162, 132);
  gtk_widget_set_uposition (label45, 162, 132);
  gtk_widget_set_usize (label45, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label45), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label45), 0, 0.5);

  label46 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label46);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label46", label46,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label46);
  gtk_fixed_put (GTK_FIXED (fixed3), label46, 162, 150);
  gtk_widget_set_uposition (label46, 162, 150);
  gtk_widget_set_usize (label46, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label46), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label46), 0, 0.5);

  label47 = gtk_label_new ("0.1618 usec");
  gtk_widget_ref (label47);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label47", label47,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label47);
  gtk_fixed_put (GTK_FIXED (fixed3), label47, 162, 168);
  gtk_widget_set_uposition (label47, 162, 168);
  gtk_widget_set_usize (label47, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label47), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label47), 0, 0.5);

  label9 = gtk_label_new ("check/passed");
  gtk_widget_ref (label9);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label9", label9,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label9);
  gtk_fixed_put (GTK_FIXED (fixed3), label9, 264, 42);
  gtk_widget_set_uposition (label9, 264, 42);
  gtk_widget_set_usize (label9, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label9), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label9), 0, 0.5);

  label48 = gtk_label_new ("check/passed");
  gtk_widget_ref (label48);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label48", label48,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label48);
  gtk_fixed_put (GTK_FIXED (fixed3), label48, 264, 60);
  gtk_widget_set_uposition (label48, 264, 60);
  gtk_widget_set_usize (label48, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label48), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label48), 0, 0.5);

  label49 = gtk_label_new ("check/passed");
  gtk_widget_ref (label49);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label49", label49,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label49);
  gtk_fixed_put (GTK_FIXED (fixed3), label49, 264, 78);
  gtk_widget_set_uposition (label49, 264, 78);
  gtk_widget_set_usize (label49, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label49), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label49), 0, 0.5);

  label50 = gtk_label_new ("check/passed");
  gtk_widget_ref (label50);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label50", label50,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label50);
  gtk_fixed_put (GTK_FIXED (fixed3), label50, 264, 96);
  gtk_widget_set_uposition (label50, 264, 96);
  gtk_widget_set_usize (label50, 90, 18);
  gtk_label_set_justify (GTK_LABEL (label50), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label50), 0, 0.5);

  fixed7 = gtk_fixed_new ();
  gtk_widget_ref (fixed7);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "fixed7", fixed7,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed7);
  gtk_fixed_put (GTK_FIXED (fixed3), fixed7, 0, 0);
  gtk_widget_set_uposition (fixed7, 0, 0);
  gtk_widget_set_usize (fixed7, 0, 0);

  hseparator3 = gtk_hseparator_new ();
  gtk_widget_ref (hseparator3);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "hseparator3", hseparator3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hseparator3);
  gtk_fixed_put (GTK_FIXED (fixed7), hseparator3, 6, 24);
  gtk_widget_set_uposition (hseparator3, 6, 24);
  gtk_widget_set_usize (hseparator3, 432, 16);

  vseparator4 = gtk_vseparator_new ();
  gtk_widget_ref (vseparator4);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "vseparator4", vseparator4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vseparator4);
  gtk_fixed_put (GTK_FIXED (fixed7), vseparator4, 54, 0);
  gtk_widget_set_uposition (vseparator4, 54, 0);
  gtk_widget_set_usize (vseparator4, 16, 186);

  vseparator3 = gtk_vseparator_new ();
  gtk_widget_ref (vseparator3);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "vseparator3", vseparator3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vseparator3);
  gtk_fixed_put (GTK_FIXED (fixed7), vseparator3, 348, 0);
  gtk_widget_set_uposition (vseparator3, 348, 0);
  gtk_widget_set_usize (vseparator3, 16, 186);

  vseparator2 = gtk_vseparator_new ();
  gtk_widget_ref (vseparator2);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "vseparator2", vseparator2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vseparator2);
  gtk_fixed_put (GTK_FIXED (fixed7), vseparator2, 252, 0);
  gtk_widget_set_uposition (vseparator2, 252, 0);
  gtk_widget_set_usize (vseparator2, 16, 186);

  vseparator1 = gtk_vseparator_new ();
  gtk_widget_ref (vseparator1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "vseparator1", vseparator1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vseparator1);
  gtk_fixed_put (GTK_FIXED (fixed7), vseparator1, 156, 0);
  gtk_widget_set_uposition (vseparator1, 156, 0);
  gtk_widget_set_usize (vseparator1, 16, 186);

  label60 = gtk_label_new ("FErr:");
  gtk_widget_ref (label60);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label60", label60,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label60);
  gtk_fixed_put (GTK_FIXED (fixed7), label60, 66, 6);
  gtk_widget_set_uposition (label60, 66, 6);
  gtk_widget_set_usize (label60, 96, 18);

  label64 = gtk_label_new ("Runtime usec:");
  gtk_widget_ref (label64);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label64", label64,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label64);
  gtk_fixed_put (GTK_FIXED (fixed7), label64, 168, 6);
  gtk_widget_set_uposition (label64, 168, 6);
  gtk_widget_set_usize (label64, 90, 18);

  label61 = gtk_label_new ("Status:");
  gtk_widget_ref (label61);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label61", label61,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label61);
  gtk_fixed_put (GTK_FIXED (fixed7), label61, 264, 6);
  gtk_widget_set_uposition (label61, 264, 6);
  gtk_widget_set_usize (label61, 90, 18);

  label62 = gtk_label_new ("MFLOPS:");
  gtk_widget_ref (label62);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label62", label62,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label62);
  gtk_fixed_put (GTK_FIXED (fixed7), label62, 360, 6);
  gtk_widget_set_uposition (label62, 360, 6);
  gtk_widget_set_usize (label62, 78, 18);

  label59 = gtk_label_new ("Module:");
  gtk_widget_ref (label59);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label59", label59,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label59);
  gtk_fixed_put (GTK_FIXED (fixed7), label59, 0, 6);
  gtk_widget_set_uposition (label59, 0, 6);
  gtk_widget_set_usize (label59, 60, 18);

  label63 = gtk_label_new ("1");
  gtk_widget_ref (label63);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label63", label63,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label63);
  gtk_fixed_put (GTK_FIXED (fixed7), label63, 6, 42);
  gtk_widget_set_uposition (label63, 6, 42);
  gtk_widget_set_usize (label63, 54, 18);

  label75 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label75);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label75", label75,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label75);
  gtk_fixed_put (GTK_FIXED (fixed7), label75, 168, 60);
  gtk_widget_set_uposition (label75, 168, 60);
  gtk_widget_set_usize (label75, 90, 18);

  label76 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label76);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label76", label76,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label76);
  gtk_fixed_put (GTK_FIXED (fixed7), label76, 168, 78);
  gtk_widget_set_uposition (label76, 168, 78);
  gtk_widget_set_usize (label76, 90, 18);

  label77 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label77);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label77", label77,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label77);
  gtk_fixed_put (GTK_FIXED (fixed7), label77, 168, 96);
  gtk_widget_set_uposition (label77, 168, 96);
  gtk_widget_set_usize (label77, 90, 18);

  label79 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label79);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label79", label79,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label79);
  gtk_fixed_put (GTK_FIXED (fixed7), label79, 168, 132);
  gtk_widget_set_uposition (label79, 168, 132);
  gtk_widget_set_usize (label79, 90, 18);

  label80 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label80);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label80", label80,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label80);
  gtk_fixed_put (GTK_FIXED (fixed7), label80, 168, 150);
  gtk_widget_set_uposition (label80, 168, 150);
  gtk_widget_set_usize (label80, 90, 18);

  label81 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label81);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label81", label81,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label81);
  gtk_fixed_put (GTK_FIXED (fixed7), label81, 168, 168);
  gtk_widget_set_uposition (label81, 168, 168);
  gtk_widget_set_usize (label81, 90, 18);

  label82 = gtk_label_new ("waiting...");
  gtk_widget_ref (label82);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label82", label82,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label82);
  gtk_fixed_put (GTK_FIXED (fixed7), label82, 264, 42);
  gtk_widget_set_uposition (label82, 264, 42);
  gtk_widget_set_usize (label82, 90, 18);

  label83 = gtk_label_new ("waiting...");
  gtk_widget_ref (label83);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label83", label83,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label83);
  gtk_fixed_put (GTK_FIXED (fixed7), label83, 264, 60);
  gtk_widget_set_uposition (label83, 264, 60);
  gtk_widget_set_usize (label83, 90, 18);

  label84 = gtk_label_new ("waiting...");
  gtk_widget_ref (label84);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label84", label84,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label84);
  gtk_fixed_put (GTK_FIXED (fixed7), label84, 264, 78);
  gtk_widget_set_uposition (label84, 264, 78);
  gtk_widget_set_usize (label84, 90, 18);

  label86 = gtk_label_new ("waiting...");
  gtk_widget_ref (label86);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label86", label86,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label86);
  gtk_fixed_put (GTK_FIXED (fixed7), label86, 264, 96);
  gtk_widget_set_uposition (label86, 264, 96);
  gtk_widget_set_usize (label86, 90, 18);

  label85 = gtk_label_new ("waiting...");
  gtk_widget_ref (label85);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label85", label85,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label85);
  gtk_fixed_put (GTK_FIXED (fixed7), label85, 264, 114);
  gtk_widget_set_uposition (label85, 264, 114);
  gtk_widget_set_usize (label85, 90, 18);

  label87 = gtk_label_new ("waiting...");
  gtk_widget_ref (label87);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label87", label87,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label87);
  gtk_fixed_put (GTK_FIXED (fixed7), label87, 264, 132);
  gtk_widget_set_uposition (label87, 264, 132);
  gtk_widget_set_usize (label87, 90, 18);

  label88 = gtk_label_new ("waiting...");
  gtk_widget_ref (label88);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label88", label88,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label88);
  gtk_fixed_put (GTK_FIXED (fixed7), label88, 264, 150);
  gtk_widget_set_uposition (label88, 264, 150);
  gtk_widget_set_usize (label88, 90, 18);

  label89 = gtk_label_new ("waiting...");
  gtk_widget_ref (label89);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label89", label89,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label89);
  gtk_fixed_put (GTK_FIXED (fixed7), label89, 264, 168);
  gtk_widget_set_uposition (label89, 264, 168);
  gtk_widget_set_usize (label89, 90, 18);

  label52 = gtk_label_new ("2");
  gtk_widget_ref (label52);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label52", label52,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label52);
  gtk_fixed_put (GTK_FIXED (fixed7), label52, 6, 60);
  gtk_widget_set_uposition (label52, 6, 60);
  gtk_widget_set_usize (label52, 54, 18);

  label53 = gtk_label_new ("3");
  gtk_widget_ref (label53);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label53", label53,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label53);
  gtk_fixed_put (GTK_FIXED (fixed7), label53, 6, 78);
  gtk_widget_set_uposition (label53, 6, 78);
  gtk_widget_set_usize (label53, 54, 18);

  label54 = gtk_label_new ("4");
  gtk_widget_ref (label54);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label54", label54,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label54);
  gtk_fixed_put (GTK_FIXED (fixed7), label54, 6, 96);
  gtk_widget_set_uposition (label54, 6, 96);
  gtk_widget_set_usize (label54, 54, 18);

  label55 = gtk_label_new ("5");
  gtk_widget_ref (label55);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label55", label55,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label55);
  gtk_fixed_put (GTK_FIXED (fixed7), label55, 6, 114);
  gtk_widget_set_uposition (label55, 6, 114);
  gtk_widget_set_usize (label55, 54, 18);

  label56 = gtk_label_new ("6");
  gtk_widget_ref (label56);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label56", label56,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label56);
  gtk_fixed_put (GTK_FIXED (fixed7), label56, 6, 132);
  gtk_widget_set_uposition (label56, 6, 132);
  gtk_widget_set_usize (label56, 54, 18);

  label65 = gtk_label_new ("7");
  gtk_widget_ref (label65);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label65", label65,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label65);
  gtk_fixed_put (GTK_FIXED (fixed7), label65, 6, 150);
  gtk_widget_set_uposition (label65, 6, 150);
  gtk_widget_set_usize (label65, 54, 18);

  label57 = gtk_label_new ("8");
  gtk_widget_ref (label57);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label57", label57,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label57);
  gtk_fixed_put (GTK_FIXED (fixed7), label57, 6, 168);
  gtk_widget_set_uposition (label57, 6, 168);
  gtk_widget_set_usize (label57, 54, 18);

  label66 = gtk_label_new ("stack idle");
  gtk_widget_ref (label66);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label66", label66,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label66);
  gtk_fixed_put (GTK_FIXED (fixed7), label66, 66, 42);
  gtk_widget_set_uposition (label66, 66, 42);
  gtk_widget_set_usize (label66, 96, 18);

  label67 = gtk_label_new ("stack idle");
  gtk_widget_ref (label67);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label67", label67,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label67);
  gtk_fixed_put (GTK_FIXED (fixed7), label67, 66, 60);
  gtk_widget_set_uposition (label67, 66, 60);
  gtk_widget_set_usize (label67, 96, 18);

  label68 = gtk_label_new ("stack idle");
  gtk_widget_ref (label68);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label68", label68,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label68);
  gtk_fixed_put (GTK_FIXED (fixed7), label68, 66, 78);
  gtk_widget_set_uposition (label68, 66, 78);
  gtk_widget_set_usize (label68, 96, 18);

  label69 = gtk_label_new ("stack idle");
  gtk_widget_ref (label69);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label69", label69,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label69);
  gtk_fixed_put (GTK_FIXED (fixed7), label69, 66, 96);
  gtk_widget_set_uposition (label69, 66, 96);
  gtk_widget_set_usize (label69, 96, 18);

  label70 = gtk_label_new ("stack idle");
  gtk_widget_ref (label70);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label70", label70,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label70);
  gtk_fixed_put (GTK_FIXED (fixed7), label70, 66, 114);
  gtk_widget_set_uposition (label70, 66, 114);
  gtk_widget_set_usize (label70, 96, 18);

  label71 = gtk_label_new ("stack idle");
  gtk_widget_ref (label71);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label71", label71,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label71);
  gtk_fixed_put (GTK_FIXED (fixed7), label71, 66, 132);
  gtk_widget_set_uposition (label71, 66, 132);
  gtk_widget_set_usize (label71, 96, 18);

  label72 = gtk_label_new ("stack idle");
  gtk_widget_ref (label72);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label72", label72,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label72);
  gtk_fixed_put (GTK_FIXED (fixed7), label72, 66, 150);
  gtk_widget_set_uposition (label72, 66, 150);
  gtk_widget_set_usize (label72, 96, 18);

  label73 = gtk_label_new ("stack idle");
  gtk_widget_ref (label73);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label73", label73,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label73);
  gtk_fixed_put (GTK_FIXED (fixed7), label73, 66, 168);
  gtk_widget_set_uposition (label73, 66, 168);
  gtk_widget_set_usize (label73, 96, 18);

  label74 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label74);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label74", label74,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label74);
  gtk_fixed_put (GTK_FIXED (fixed7), label74, 168, 42);
  gtk_widget_set_uposition (label74, 168, 42);
  gtk_widget_set_usize (label74, 90, 18);

  label58 = gtk_label_new ("   NULL");
  gtk_widget_ref (label58);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label58", label58,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label58);
  gtk_fixed_put (GTK_FIXED (fixed7), label58, 366, 42);
  gtk_widget_set_uposition (label58, 366, 42);
  gtk_widget_set_usize (label58, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label58), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label58), 0, 0.5);

  label90 = gtk_label_new ("   NULL");
  gtk_widget_ref (label90);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label90", label90,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label90);
  gtk_fixed_put (GTK_FIXED (fixed7), label90, 366, 60);
  gtk_widget_set_uposition (label90, 366, 60);
  gtk_widget_set_usize (label90, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label90), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label90), 0, 0.5);

  label91 = gtk_label_new ("   NULL");
  gtk_widget_ref (label91);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label91", label91,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label91);
  gtk_fixed_put (GTK_FIXED (fixed7), label91, 366, 78);
  gtk_widget_set_uposition (label91, 366, 78);
  gtk_widget_set_usize (label91, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label91), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label91), 0, 0.5);

  label92 = gtk_label_new ("   NULL");
  gtk_widget_ref (label92);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label92", label92,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label92);
  gtk_fixed_put (GTK_FIXED (fixed7), label92, 366, 96);
  gtk_widget_set_uposition (label92, 366, 96);
  gtk_widget_set_usize (label92, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label92), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label92), 0, 0.5);

  label93 = gtk_label_new ("   NULL");
  gtk_widget_ref (label93);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label93", label93,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label93);
  gtk_fixed_put (GTK_FIXED (fixed7), label93, 366, 114);
  gtk_widget_set_uposition (label93, 366, 114);
  gtk_widget_set_usize (label93, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label93), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label93), 0, 0.5);

  label94 = gtk_label_new ("   NULL");
  gtk_widget_ref (label94);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label94", label94,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label94);
  gtk_fixed_put (GTK_FIXED (fixed7), label94, 366, 132);
  gtk_widget_set_uposition (label94, 366, 132);
  gtk_widget_set_usize (label94, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label94), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label94), 0, 0.5);

  label96 = gtk_label_new ("   NULL");
  gtk_widget_ref (label96);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label96", label96,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label96);
  gtk_fixed_put (GTK_FIXED (fixed7), label96, 366, 150);
  gtk_widget_set_uposition (label96, 366, 150);
  gtk_widget_set_usize (label96, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label96), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label96), 0, 0.5);

  label95 = gtk_label_new ("   NULL");
  gtk_widget_ref (label95);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label95", label95,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label95);
  gtk_fixed_put (GTK_FIXED (fixed7), label95, 366, 168);
  gtk_widget_set_uposition (label95, 366, 168);
  gtk_widget_set_usize (label95, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label95), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label95), 0, 0.5);

  label78 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label78);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label78", label78,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label78);
  gtk_fixed_put (GTK_FIXED (fixed7), label78, 168, 114);
  gtk_widget_set_uposition (label78, 168, 114);
  gtk_widget_set_usize (label78, 90, 18);

  statusbar1 = gtk_statusbar_new ();
  gtk_widget_ref (statusbar1);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "statusbar1", statusbar1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (statusbar1);
  gtk_fixed_put (GTK_FIXED (fixed2), statusbar1, 6, 324);
  gtk_widget_set_uposition (statusbar1, 6, 324);
  gtk_widget_set_usize (statusbar1, 330, 19);

  statusbar2 = gtk_statusbar_new ();
  gtk_widget_ref (statusbar2);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "statusbar2", statusbar2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (statusbar2);
  gtk_fixed_put (GTK_FIXED (fixed2), statusbar2, 336, 324);
  gtk_widget_set_uposition (statusbar2, 336, 324);
  gtk_widget_set_usize (statusbar2, 120, 19);

  frame2 = gtk_frame_new ("summary");
  gtk_widget_ref (frame2);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "frame2", frame2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame2);
  gtk_fixed_put (GTK_FIXED (fixed2), frame2, 6, 228);
  gtk_widget_set_uposition (frame2, 6, 228);
  gtk_widget_set_usize (frame2, 450, 86);

  fixed4 = gtk_fixed_new ();
  gtk_widget_ref (fixed4);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "fixed4", fixed4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed4);
  gtk_container_add (GTK_CONTAINER (frame2), fixed4);

  label21 = gtk_label_new ("MFLOPS 1:");
  gtk_widget_ref (label21);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label21", label21,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label21);
  gtk_fixed_put (GTK_FIXED (fixed4), label21, 12, 24);
  gtk_widget_set_uposition (label21, 12, 24);
  gtk_widget_set_usize (label21, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label21), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label21), 0, 0.5);

  label22 = gtk_label_new ("MFLOPS 2:");
  gtk_widget_ref (label22);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label22", label22,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label22);
  gtk_fixed_put (GTK_FIXED (fixed4), label22, 12, 42);
  gtk_widget_set_uposition (label22, 12, 42);
  gtk_widget_set_usize (label22, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label22), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label22), 0, 0.5);

  label24 = gtk_label_new ("MFLOPS 4:");
  gtk_widget_ref (label24);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label24", label24,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label24);
  gtk_fixed_put (GTK_FIXED (fixed4), label24, 228, 42);
  gtk_widget_set_uposition (label24, 228, 42);
  gtk_widget_set_usize (label24, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label24), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label24), 0, 0.5);

  label20 = gtk_label_new ("Null Time usec:");
  gtk_widget_ref (label20);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label20", label20,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label20);
  gtk_fixed_put (GTK_FIXED (fixed4), label20, 228, 6);
  gtk_widget_set_uposition (label20, 228, 6);
  gtk_widget_set_usize (label20, 96, 18);
  gtk_label_set_justify (GTK_LABEL (label20), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label20), 0, 0.5);

  label23 = gtk_label_new ("MFLOPS 3:");
  gtk_widget_ref (label23);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label23", label23,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label23);
  gtk_fixed_put (GTK_FIXED (fixed4), label23, 228, 24);
  gtk_widget_set_uposition (label23, 228, 24);
  gtk_widget_set_usize (label23, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label23), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label23), 0, 0.5);

  label25 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label25);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label25", label25,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label25);
  gtk_fixed_put (GTK_FIXED (fixed4), label25, 90, 24);
  gtk_widget_set_uposition (label25, 90, 24);
  gtk_widget_set_usize (label25, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label25), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label25), 0, 0.5);

  label26 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label26);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label26", label26,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label26);
  gtk_fixed_put (GTK_FIXED (fixed4), label26, 90, 42);
  gtk_widget_set_uposition (label26, 90, 42);
  gtk_widget_set_usize (label26, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label26), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label26), 0, 0.5);

  label19 = gtk_label_new ("Iterations (loops):");
  gtk_widget_ref (label19);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label19", label19,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label19);
  gtk_fixed_put (GTK_FIXED (fixed4), label19, 12, 6);
  gtk_widget_set_uposition (label19, 12, 6);
  gtk_widget_set_usize (label19, 102, 18);
  gtk_label_set_justify (GTK_LABEL (label19), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label19), 0, 0.5);

  label98 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label98);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label98", label98,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label98);
  gtk_fixed_put (GTK_FIXED (fixed4), label98, 324, 6);
  gtk_widget_set_uposition (label98, 324, 6);
  gtk_widget_set_usize (label98, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label98), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label98), 0, 0.5);

  label27 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label27);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label27", label27,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label27);
  gtk_fixed_put (GTK_FIXED (fixed4), label27, 306, 24);
  gtk_widget_set_uposition (label27, 306, 24);
  gtk_widget_set_usize (label27, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label27), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label27), 0, 0.5);

  label28 = gtk_label_new ("buffer empty");
  gtk_widget_ref (label28);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label28", label28,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label28);
  gtk_fixed_put (GTK_FIXED (fixed4), label28, 306, 42);
  gtk_widget_set_uposition (label28, 306, 42);
  gtk_widget_set_usize (label28, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label28), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label28), 0, 0.5);

  label97 = gtk_label_new ("NULL");
  gtk_widget_ref (label97);
  gtk_object_set_data_full (GTK_OBJECT (main_wnd), "label97", label97,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label97);
  gtk_fixed_put (GTK_FIXED (fixed4), label97, 120, 6);
  gtk_widget_set_uposition (label97, 120, 6);
  gtk_widget_set_usize (label97, 78, 18);
  gtk_label_set_justify (GTK_LABEL (label97), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label97), 0, 0.5);

  gtk_signal_connect (GTK_OBJECT (quit1), "activate",
                      GTK_SIGNAL_FUNC (on_quit1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (run_benchmark1), "activate",
                      GTK_SIGNAL_FUNC (on_run_benchmark1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (clear_table1), "activate",
                      GTK_SIGNAL_FUNC (on_clear_table1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (mflops1), "activate",
                      GTK_SIGNAL_FUNC (on_mflops1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (gflops1), "activate",
                      GTK_SIGNAL_FUNC (on_gflops1_activate),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (info1), "activate",
                      GTK_SIGNAL_FUNC (on_info1_activate),
                      NULL);
  return main_wnd;
}

GtkWidget*
create_about_wnd (void)
{
  GtkWidget *fixed5;
  GtkWidget *frame3;
  GtkWidget *fixed6;
  GtkWidget *button1;
  GtkWidget *hseparator2;
  GtkWidget *label32;
  GtkWidget *label33;
  GtkWidget *label31;
  GtkWidget *label29;
  GtkWidget *label30;

  about_wnd = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (about_wnd), "about_wnd", about_wnd);
  gtk_widget_set_usize (about_wnd, 360, 252);
  gtk_window_set_title (GTK_WINDOW (about_wnd), "About");
  gtk_window_set_position (GTK_WINDOW (about_wnd), GTK_WIN_POS_CENTER);
  gtk_window_set_policy (GTK_WINDOW (about_wnd), FALSE, FALSE, FALSE);
  
  gtk_signal_connect (GTK_OBJECT (about_wnd), "destroy",
			GTK_SIGNAL_FUNC (unload_about_window), NULL);

  gtk_signal_connect (GTK_OBJECT (about_wnd), "delete_event",
			GTK_SIGNAL_FUNC (unload_about_window), NULL);

  fixed5 = gtk_fixed_new ();
  gtk_widget_ref (fixed5);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "fixed5", fixed5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed5);
  gtk_container_add (GTK_CONTAINER (about_wnd), fixed5);

  frame3 = gtk_frame_new (NULL);
  gtk_widget_ref (frame3);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "frame3", frame3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame3);
  gtk_fixed_put (GTK_FIXED (fixed5), frame3, 6, 6);
  gtk_widget_set_uposition (frame3, 6, 6);
  gtk_widget_set_usize (frame3, 348, 240);

  fixed6 = gtk_fixed_new ();
  gtk_widget_ref (fixed6);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "fixed6", fixed6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (fixed6);
  gtk_container_add (GTK_CONTAINER (frame3), fixed6);

  button1 = gtk_button_new_with_label ("OK");
  gtk_widget_ref (button1);
  
  gtk_signal_connect (GTK_OBJECT(button1), "button_release_event",
	          GTK_SIGNAL_FUNC (unload_about_window), NULL);  
  
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "button1", button1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button1);
  gtk_fixed_put (GTK_FIXED (fixed6), button1, 252, 198);
  gtk_widget_set_uposition (button1, 252, 198);
  gtk_widget_set_usize (button1, 77, 24);

  hseparator2 = gtk_hseparator_new ();
  gtk_widget_ref (hseparator2);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "hseparator2", hseparator2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hseparator2);
  gtk_fixed_put (GTK_FIXED (fixed6), hseparator2, 12, 30);
  gtk_widget_set_uposition (hseparator2, 12, 30);
  gtk_widget_set_usize (hseparator2, 318, 16);

  label32 = gtk_label_new ("Distributed under the terms of the GNU\nGeneral Public License, Version 2");
  gtk_widget_ref (label32);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "label32", label32,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label32);
  gtk_fixed_put (GTK_FIXED (fixed6), label32, 12, 138);
  gtk_widget_set_uposition (label32, 12, 138);
  gtk_widget_set_usize (label32, 234, 36);
  gtk_label_set_justify (GTK_LABEL (label32), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label32), 0, 0.5);

  label33 = gtk_label_new ("(c) 2000 - All rights reserved");
  gtk_widget_ref (label33);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "label33", label33,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label33);
  gtk_fixed_put (GTK_FIXED (fixed6), label33, 12, 204);
  gtk_widget_set_uposition (label33, 12, 204);
  gtk_widget_set_usize (label33, 234, 18);
  gtk_label_set_justify (GTK_LABEL (label33), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label33), 0, 0.5);

  label31 = gtk_label_new ("written by Marc O. Gloor <mgloor@fhzh.ch>\nhttp://pubwww.fhzh.ch/~mgloor");
  gtk_widget_ref (label31);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "label31", label31,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label31);
  gtk_fixed_put (GTK_FIXED (fixed6), label31, 12, 90);
  gtk_widget_set_uposition (label31, 12, 90);
  gtk_widget_set_usize (label31, 300, 48);
  gtk_label_set_justify (GTK_LABEL (label31), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label31), 0, 0.5);

  label29 = gtk_label_new ("FLOW 0.0.8 double precision (custom build)");
  gtk_widget_ref (label29);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "label29", label29,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label29);
  gtk_fixed_put (GTK_FIXED (fixed6), label29, 12, 12);
  gtk_widget_set_uposition (label29, 12, 12);
  gtk_widget_set_usize (label29, 270, 18);
  gtk_label_set_justify (GTK_LABEL (label29), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label29), 0, 0.5);

  label30 = gtk_label_new ("Highend FPU/CPU speed detection for Unix\n(floating point operations per second)");
  gtk_widget_ref (label30);
  gtk_object_set_data_full (GTK_OBJECT (about_wnd), "label30", label30,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label30);
  gtk_fixed_put (GTK_FIXED (fixed6), label30, 12, 54);
  gtk_widget_set_uposition (label30, 12, 54);
  gtk_widget_set_usize (label30, 300, 36);
  gtk_label_set_justify (GTK_LABEL (label30), GTK_JUSTIFY_LEFT);
  gtk_misc_set_alignment (GTK_MISC (label30), 0, 0.5);

  return about_wnd;
}

