/*
 * flow - floating point operations per second benchmark
 * Copyright (C) 02/04/2000 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * $Id$
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <unistd.h>

#include "main.h"

/* Prototypes */
void clear_table();
void kernel();
int tabclear_statbar();
int standby_statbar();
int ovhd_ratio2_statbar();

void
on_quit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    gtk_main_quit();   
}

void
on_run_benchmark1_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
    clear_table();
    ovhd_ratio2_statbar();
    while (gtk_events_pending()) gtk_main_iteration();
    kernel();
}

void
on_clear_table1_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
   clear_table();
   tabclear_statbar();
   while (gtk_events_pending()) gtk_main_iteration();
   usleep(400000);
   standby_statbar();
   
}

void
on_mflops1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
   gchar *buffer;
       
   gtk_label_set (GTK_LABEL(label21), "MFLOPS 1:");
   gtk_widget_show (label21);
   
   gtk_label_set (GTK_LABEL(label22), "MFLOPS 2:");
   gtk_widget_show (label22);  
   
   gtk_label_set (GTK_LABEL(label23), "MFLOPS 3:");
   gtk_widget_show (label23);  
   
   gtk_label_set (GTK_LABEL(label24), "MFLOPS 4:");
   gtk_widget_show (label24);   

   gtk_label_get (GTK_LABEL(label25), &buffer);
    
   if (strcmp(buffer, "buffer empty") != 0) {
   
      gtk_label_set (GTK_LABEL(label25), glob_mflp1);    
      gtk_widget_show (label25);   
       
      gtk_label_set (GTK_LABEL(label26), glob_mflp2);    
      gtk_widget_show (label26);  
      
      gtk_label_set (GTK_LABEL(label27), glob_mflp3);    
      gtk_widget_show (label27);  
      
      gtk_label_set (GTK_LABEL(label28), glob_mflp4);    
      gtk_widget_show (label28);        
          
   }
          
}

void
on_gflops1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
   gchar *buffer;

   gtk_label_set (GTK_LABEL(label21), "GFLOPS 1:");
   gtk_widget_show (label21);
   
   gtk_label_set (GTK_LABEL(label22), "GFLOPS 2:");
   gtk_widget_show (label22);  
   
   gtk_label_set (GTK_LABEL(label23), "GFLOPS 3:");
   gtk_widget_show (label23);  
   
   gtk_label_set (GTK_LABEL(label24), "GFLOPS 4:");
   gtk_widget_show (label24);   
   
   gtk_label_get (GTK_LABEL(label25), &buffer);
   
   if (strcmp(buffer, "buffer empty") != 0) {
   
      gtk_label_set (GTK_LABEL(label25), glob_gflp1);    
      gtk_widget_show (label25);   
       
      gtk_label_set (GTK_LABEL(label26), glob_gflp2);    
      gtk_widget_show (label26);  
      
      gtk_label_set (GTK_LABEL(label27), glob_gflp3);    
      gtk_widget_show (label27);  
      
      gtk_label_set (GTK_LABEL(label28), glob_gflp4);    
      gtk_widget_show (label28);        
          
   }
       
}

void
on_info1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
   gtk_widget_show (about_wnd);
}
