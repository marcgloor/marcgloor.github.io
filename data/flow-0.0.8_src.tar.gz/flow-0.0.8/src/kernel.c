/*
 * flow - floating point operations per second benchmark
 * Copyright (C) 02/04/2000 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * $Id$
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */
 
#include <stdio.h>
#include <math.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <gtk/gtk.h>
#include "main.h"

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

/* Prototypes */
void clear_table();
void kernel();
int runmod1_statbar();
int runmod2_statbar();
int runmod3_statbar();
int runmod4_statbar();
int runmod5_statbar();
int runmod6_statbar();
int runmod7_statbar();
int runmod8_statbar();
int done_statbar();
int erase2_statbar();
int standby_statbar();
int tabclear_statbar();
int ovhd_ratio2_statbar();

/* Timer options for Unix */
struct rusage rusage;

dtime(p)
double p[];
{
 double q;

 q = p[2];

 getrusage(RUSAGE_SELF,&rusage);

 p[2] = (double)(rusage.ru_utime.tv_sec);
 p[2] = p[2] + (double)(rusage.ru_utime.tv_usec) * 1.0e-06;
 p[1] = p[2] - q;
	
 return 0;
}

char buff[32];
/* Variables needed for 'dtime()' */
/* Threshold to determine Number of Loops to run. Fixed at 15.0 seconds. */
double nulltime, TimeArray[3];
double TLimit;
/* Global Array used to hold timing results and other information. */
double T[36];                    

double sa,sb,sc,sd,one,two,three;
double four,five,piref,piprg;
double scale,pierr;

double A0 = 1.0;
double A1 = -0.1666666666671334;
double A2 = 0.833333333809067E-2;
double A3 = 0.198412715551283E-3;
double A4 = 0.27557589750762E-5;
double A5 = 0.2507059876207E-7;
double A6 = 0.164105986683E-9;

double B0 = 1.0;
double B1 = -0.4999999999982;
double B2 = 0.4166666664651E-1;
double B3 = -0.1388888805755E-2;
double B4 = 0.24801428034E-4;
double B5 = -0.2754213324E-6;
double B6 = 0.20189405E-8;

double C0 = 1.0;
double C1 = 0.99999999668;
double C2 = 0.49999995173;
double C3 = 0.16666704243;
double C4 = 0.4166685027E-1;
double C5 = 0.832672635E-2;
double C6 = 0.140836136E-2;
double C7 = 0.17358267E-3;
double C8 = 0.3931683E-4;

double D1 = 0.3999999946405E-1;
double D2 = 0.96E-3;
double D3 = 0.1233153E-5;

double E2 = 0.48E-3;
double E3 = 0.411051E-6;

/* 'flow' kernel routine */
void kernel() {

   double s,u,v,w,x;

   long loops, NLimit;
   register long i, m, n;

   /* Initial number of loops. Don't change */
   loops = 15625;

   /* execute from 31250 to 512000000 loops based
   on a runtime of at least TLimit = 15seconds.
   512000000 loops are allowed */

   T[1] = 1.0E+06/(double)loops;

   TLimit = 15.0;
   NLimit = 512000000;

   piref = 3.14159265358979324;
   one   = 1.0;
   two   = 2.0;
   three = 3.0;
   four  = 4.0;
   five  = 5.0;
   scale = one;

   /* Initialize the timer. */
   dtime(TimeArray);
   dtime(TimeArray);
   
   /* INDEPENDENT MODULE 1 BEGIN */

   runmod1_statbar();

   /* Module 1 set status to 'check' */
   gtk_label_set (GTK_LABEL(label82), "check...");  
   gtk_widget_show (label82);    
   
   /* display Module 1 */
   gtk_label_set (GTK_LABEL(label63), "1");
   gtk_widget_show (label63);
   
   /* display update - check gtk_main and return immediately */
   while (gtk_events_pending()) gtk_main_iteration(); 

   n = loops;
   sa = 0.0;

   while ( sa < TLimit )
   {
   n = 2 * n;
   x = one / (double)n;
   s = 0.0;
   v = 0.0;
   w = one;
   
       /* Loop 1 */
       dtime(TimeArray);
       for( i = 1 ; i <= n-1 ; i++ )
       {
       v = v + w;
       u = v * x;
       s = s + (D1+u*(D2+u*D3))/(w+u*(D1+u*(E2+u*E3)));
       }
       dtime(TimeArray);
       sa = TimeArray[1];

   if ( n == NLimit ) break;

   }

   scale = 1.0E+06 / (double)n;
   T[1]  = scale;

   /* Estimate nulltime ('for' loop time) */
   dtime(TimeArray);
   for( i = 1 ; i <= n-1 ; i++ )
   {
   }
   dtime(TimeArray);
   nulltime = T[1] * TimeArray[1];
   if ( nulltime < 0.0 ) nulltime = 0.0;

   T[2] = T[1] * sa - nulltime;

   sa = (D1+D2+D3)/(one+D1+E2+E3);
   sb = D1;

   /* Module 1 Results */
   T[3] = T[2] / 14.0;
   sa = x * ( sa + sb + two * s ) / two;
   sb = one / sa;
   n  = (long)( (double)( 40000 * (long)sb ) / scale );
   sc = sb - 25.2;
   T[4] = one / T[3];

	 /* display results */
   sprintf(buff, "%.4e", sc);
   gtk_label_set (GTK_LABEL(label66), buff);
   gtk_widget_show (label66);
   
   sprintf(buff, "%.4f usec", T[2]);
   gtk_label_set (GTK_LABEL(label74), buff);
   gtk_widget_show (label74);   
   
   sprintf(buff, "%10.4f", T[4]);
   gtk_label_set (GTK_LABEL(label58), buff);
   gtk_widget_show (label58);  
     
   /* Module 1 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label82), "passed");  
   gtk_widget_show (label82);    
   while (gtk_events_pending()) gtk_main_iteration();
   
   m = n;

   /* INDEPENDENT MODULE 2 BEGIN */
   
   runmod2_statbar();

   /* Module 2 set status to 'check' */
   gtk_label_set (GTK_LABEL(label83), "check...");  
   gtk_widget_show (label83);    
   
   /* display Module 2 */
   gtk_label_set (GTK_LABEL(label52), "2");
   gtk_widget_show (label52);
   
   /* display update - check gtk_main and return immediately */
   while (gtk_events_pending()) gtk_main_iteration(); 
   
   s  = -five;
   sa = -one;
	 /* Loop 2 */
   dtime(TimeArray);
   for ( i = 1 ; i <= m ; i++ )
   {
   s  = -s;
   sa = sa + s;
   }
   dtime(TimeArray);
   T[5] = T[1] * TimeArray[1];
   if ( T[5] < 0.0 ) T[5] = 0.0;

   sc   = (double)m;

   u = sa;
   v = 0.0;
   w = 0.0;
   x = 0.0;
   
   /* Loop 3 */
   dtime(TimeArray);
   for ( i = 1 ; i <= m ; i++)
   {
   s  = -s;
   sa = sa + s;
   u  = u + two;
   x  = x +(s - u);
   v  = v - s * u;
   w  = w + s / u;
   }
   dtime(TimeArray);
   T[6] = T[1] * TimeArray[1];

   T[7] = ( T[6] - T[5] ) / 7.0;
   m  = (long)( sa * x  / sc );
   sa = four * w / five;
   sb = sa + five / v;
   sc = 31.25;
   /* PI Results */
   piprg = sb - sc / (v * v * v);
   pierr = piprg - piref;
   T[8]  = one  / T[7];

	 /* display results */ 
   sprintf(buff, "%.4e", pierr);
   gtk_label_set (GTK_LABEL(label67), buff);
   gtk_widget_show (label67);
   
   sprintf(buff, "%.4f usec", T[6]-T[5]);
   gtk_label_set (GTK_LABEL(label75), buff);
   gtk_widget_show (label75);   
   
   sprintf(buff, "%10.4f", T[8]);
   gtk_label_set (GTK_LABEL(label90), buff);
   gtk_widget_show (label90);  
     
   /* Module 2 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label83), "passed");  
   gtk_widget_show (label83);    
   while (gtk_events_pending()) gtk_main_iteration();
   
   /* INDEPENDENT MODULE 3 BEGIN */

   runmod3_statbar();
   
   /* Module 3 set status to 'check' */
   gtk_label_set (GTK_LABEL(label84), "check...");  
   gtk_widget_show (label84);    
   
   /* display Module 3 */
   gtk_label_set (GTK_LABEL(label53), "3");
   gtk_widget_show (label53);
   
   /* display update - check gtk_main and return immediately */
   while (gtk_events_pending()) gtk_main_iteration(); 
   
   x = piref / ( three * (double)m );
   s = 0.0;
   v = 0.0;
   /* Loop 4 */
   dtime(TimeArray);
   for( i = 1 ; i <= m-1 ; i++ )
   {
   v = v + one;
   u = v * x;
   w = u * u;
   s = s + u * ((((((A6*w-A5)*w+A4)*w-A3)*w+A2)*w+A1)*w+one);
   }
   dtime(TimeArray);
   T[9]  = T[1] * TimeArray[1] - nulltime;

   u  = piref / three;
   w  = u * u;
   sa = u * ((((((A6*w-A5)*w+A4)*w-A3)*w+A2)*w+A1)*w+one);

   T[10] = T[9] / 17.0;
   sa = x * ( sa + two * s ) / two;
   sb = 0.5;
   sc = sa - sb;
   
   /* sin(x) Results */
   T[11] = one / T[10];
	
   /* display results */ 
   sprintf(buff, "%.4e", sc);
   gtk_label_set (GTK_LABEL(label68), buff);
   gtk_widget_show (label68);
   
   sprintf(buff, "%.4f usec", T[9]);
   gtk_label_set (GTK_LABEL(label76), buff);
   gtk_widget_show (label76);   
   
   sprintf(buff, "%10.4f", T[11]);
   gtk_label_set (GTK_LABEL(label91), buff);
   gtk_widget_show (label91);  
     
   /* Module 3 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label84), "passed");  
   gtk_widget_show (label84);    
   while (gtk_events_pending()) gtk_main_iteration();   

   /* INDEPENDENT MODULE 4 BEGIN */

   runmod4_statbar();

   /* Module 4 set status to 'check' */
   gtk_label_set (GTK_LABEL(label86), "check...");  
   gtk_widget_show (label86);    
   
   /* display Module 4 */
   gtk_label_set (GTK_LABEL(label54), "4");
   gtk_widget_show (label54);
   
   /* display update - check gtk_main and return immediately */
   while (gtk_events_pending()) gtk_main_iteration(); 
   
   A3 = -A3;
   A5 = -A5;
   x = piref / ( three * (double)m );
   s = 0.0;
   v = 0.0;
   
   /* Loop 5 */
   dtime(TimeArray);
   for( i = 1 ; i <= m-1 ; i++ )
   {
   u = (double)i * x;
   w = u * u;
   s = s + w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one;
   }
   dtime(TimeArray);
   T[12]  = T[1] * TimeArray[1] - nulltime;

   u  = piref / three;
   w  = u * u;
   sa = w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one;

   T[13] = T[12] / 15.0;
   sa = x * ( sa + one + two * s ) / two;
   u  = piref / three;
   w  = u * u;
   /* Module 4 Result */
   sb = u * ((((((A6*w+A5)*w+A4)*w+A3)*w+A2)*w+A1)*w+A0);
   sc = sa - sb;
   T[14] = one / T[13];

   /* display results */ 
   sprintf(buff, "%.4e", sc);
   gtk_label_set (GTK_LABEL(label69), buff);
   gtk_widget_show (label69);
   
   sprintf(buff, "%.4f usec", T[12]);
   gtk_label_set (GTK_LABEL(label77), buff);
   gtk_widget_show (label77);   
   
   sprintf(buff, "%10.4f", T[14]);
   gtk_label_set (GTK_LABEL(label92), buff);
   gtk_widget_show (label92);  
     
   /* Module 4 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label86), "passed");  
   gtk_widget_show (label86);    
   while (gtk_events_pending()) gtk_main_iteration();     

   /* INDEPENDENT MODULE 5 BEGIN */

   runmod5_statbar();

   /* Module 5 set status to 'check' */
   gtk_label_set (GTK_LABEL(label85), "check...");  
   gtk_widget_show (label85);    
   
   /* display Module 5 */
   gtk_label_set (GTK_LABEL(label55), "5");
   gtk_widget_show (label55);
   
   /* display update - check gtk_main and return immediately */
   while (gtk_events_pending()) gtk_main_iteration(); 
   
   x = piref / ( three * (double)m );
   s = 0.0;
   v = 0.0;
   
   /* Loop 6 */
   dtime(TimeArray);
   for( i = 1 ; i <= m-1 ; i++ )
   {
   u = (double)i * x;
   w = u * u;
   v = u * ((((((A6*w+A5)*w+A4)*w+A3)*w+A2)*w+A1)*w+one);
   s = s + v / (w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one);
   }
   dtime(TimeArray);
   T[15]  = T[1] * TimeArray[1] - nulltime;

   u  = piref / three;
   w  = u * u;
   sa = u*((((((A6*w+A5)*w+A4)*w+A3)*w+A2)*w+A1)*w+one);
   sb = w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one;
   sa = sa / sb;

   T[16] = T[15] / 29.0;
   sa = x * ( sa + two * s ) / two;
   sb = 0.6931471805599453;
   sc = sa - sb;
   
   /* Module 5 Result */
   T[17] = one / T[16];
   
   /* display results */ 
   sprintf(buff, "%.4e", sc);
   gtk_label_set (GTK_LABEL(label70), buff);
   gtk_widget_show (label70);
   
   sprintf(buff, "%.4f usec", T[15]);
   gtk_label_set (GTK_LABEL(label78), buff);
   gtk_widget_show (label78);   
   
   sprintf(buff, "%10.4f", T[17]);
   gtk_label_set (GTK_LABEL(label93), buff);
   gtk_widget_show (label93);  
     
   /* Module 5 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label85), "passed");  
   gtk_widget_show (label85);    
   while (gtk_events_pending()) gtk_main_iteration();     
   
   /* INDEPENDENT MODULE 6 BEGIN */

   runmod6_statbar();

   /* Module 6 set status to 'check' */
   gtk_label_set (GTK_LABEL(label87), "check...");  
   gtk_widget_show (label87);    
   
   /* display Module 6 */
   gtk_label_set (GTK_LABEL(label56), "6");
   gtk_widget_show (label56);
   
   /* display update - check gtk_main and return immediately */
   while (gtk_events_pending()) gtk_main_iteration(); 

   x = piref / ( four * (double)m );
   s = 0.0;
   v = 0.0;
   
   /* Loop 7 */
   dtime(TimeArray);
   for( i = 1 ; i <= m-1 ; i++ )
   {
   u = (double)i * x;
   w = u * u;
   v = u * ((((((A6*w+A5)*w+A4)*w+A3)*w+A2)*w+A1)*w+one);
   s = s + v*(w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one);
   }
   dtime(TimeArray);
   T[18]  = T[1] * TimeArray[1] - nulltime;

   u  = piref / four;
   w  = u * u;
   sa = u*((((((A6*w+A5)*w+A4)*w+A3)*w+A2)*w+A1)*w+one);
   sb = w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one;
   sa = sa * sb;

   T[19] = T[18] / 29.0;
   sa = x * ( sa + two * s ) / two;
   sb = 0.25;
   sc = sa - sb;
   
   /* Module 6 Result */
   T[20] = one / T[19];
   
   /* display results */ 
   sprintf(buff, "%.4e", sc);
   gtk_label_set (GTK_LABEL(label71), buff);
   gtk_widget_show (label71);
   
   sprintf(buff, "%.4f usec", T[18]);
   gtk_label_set (GTK_LABEL(label79), buff);
   gtk_widget_show (label79);   
   
   sprintf(buff, "%10.4f", T[20]);
   gtk_label_set (GTK_LABEL(label94), buff);
   gtk_widget_show (label94);  
     
   /* Module 6 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label87), "passed");  
   gtk_widget_show (label87);    
   while (gtk_events_pending()) gtk_main_iteration();  
      
   /* INDEPENDENT MODULE 7 BEGIN */

   runmod7_statbar();

   /* Module 7 set status to 'check' */
   gtk_label_set (GTK_LABEL(label88), "check...");  
   gtk_widget_show (label88);    
   
   /* display Module 7 */
   gtk_label_set (GTK_LABEL(label65), "7");
   gtk_widget_show (label65);
   
   /* display update - check gtk_main and return immediately */
   while (gtk_events_pending()) gtk_main_iteration(); 
   
   s = 0.0;
   w = one;
   sa = 102.3321513995275;
   v = sa / (double)m;
   
   /* Loop 8 */
   dtime(TimeArray);
   for ( i = 1 ; i <= m-1 ; i++)
   {
   x = (double)i * v;
   u = x * x;
   s = s - w / ( x + w ) - x / ( u + w ) - u / ( x * u + w );
   }
   dtime(TimeArray);
   T[21] = T[1] * TimeArray[1] - nulltime;
   
	 /* Module 7 Results */
   T[22] = T[21] / 12.0;                                  
   x  = sa;                                      
   u  = x * x;
   sa = -w - w / ( x + w ) - x / ( u + w ) - u / ( x * u + w );
   sa = 18.0 * v * (sa + two * s );

   m  = -2000 * (long)sa;
   m = (long)( (double)m / scale );

   sc = sa + 500.2;
   T[23] = one / T[22];

   /* display results */
   sprintf(buff, "%.4e", sc);
   gtk_label_set (GTK_LABEL(label72), buff);
   gtk_widget_show (label72);
   
   sprintf(buff, "%.4f usec", T[21]);
   gtk_label_set (GTK_LABEL(label80), buff);
   gtk_widget_show (label80);   
   
   sprintf(buff, "%10.4f", T[23]);
   gtk_label_set (GTK_LABEL(label96), buff);
   gtk_widget_show (label96);  
     
   /* Module 7 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label88), "passed");  
   gtk_widget_show (label88);    
   while (gtk_events_pending()) gtk_main_iteration();     
   
   /* INDEPENDENT MODULE 8 BEGIN */

   runmod8_statbar();

   /* Module 8 set status to 'check' */
   gtk_label_set (GTK_LABEL(label89), "check...");  
   gtk_widget_show (label89);    
   
   /* display Module 8 */
   gtk_label_set (GTK_LABEL(label57), "8");
   gtk_widget_show (label57);
   
   /* display update - check gtk_main and return immediately */   
   while (gtk_events_pending()) gtk_main_iteration(); 

   x = piref / ( three * (double)m );
   s = 0.0;
   v = 0.0;
   /*  Loop 9 */
   dtime(TimeArray);
   for( i = 1 ; i <= m-1 ; i++ )
   {
   u = (double)i * x;
   w = u * u;
   v = w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one;
   s = s + v*v*u*((((((A6*w+A5)*w+A4)*w+A3)*w+A2)*w+A1)*w+one);
   }
   dtime(TimeArray);
   T[24]  = T[1] * TimeArray[1] - nulltime;

   u  = piref / three;
   w  = u * u;
   sa = u*((((((A6*w+A5)*w+A4)*w+A3)*w+A2)*w+A1)*w+one);
   sb = w*(w*(w*(w*(w*(B6*w+B5)+B4)+B3)+B2)+B1)+one;
   sa = sa * sb * sb;
   
   /* Module 8 Result */
   T[25] = T[24] / 30.0;
   sa = x * ( sa + two * s ) / two;
   sb = 0.29166666666666667;
   sc = sa - sb;
   T[26] = one / T[25];

   /* display results */ 
   sprintf(buff, "%.4e", sc);
   gtk_label_set (GTK_LABEL(label73), buff);
   gtk_widget_show (label73);
   
   sprintf(buff, "%.4f usec", T[24]);
   gtk_label_set (GTK_LABEL(label81), buff);
   gtk_widget_show (label81);   
   
   sprintf(buff, "%10.4f", T[26]);
   gtk_label_set (GTK_LABEL(label95), buff);
   gtk_widget_show (label95);  
     
   /* Module 8 set status to 'passed' */
   gtk_label_set (GTK_LABEL(label89), "passed");  
   gtk_widget_show (label89);    
   while (gtk_events_pending()) gtk_main_iteration();      

   /* allocate mflops results */
   T[27] = ( five * (T[6] - T[5]) + T[9] ) / 52.0;
   T[28] = one  / T[27];

   T[29] = T[2] + T[9] + T[12] + T[15] + T[18];
   T[29] = (T[29] + four * T[21]) / 152.0;
   T[30] = one / T[29];

   T[31] = T[2] + T[9] + T[12] + T[15] + T[18];
   T[31] = (T[31] + T[21] + T[24]) / 146.0;
   T[32] = one / T[31];

   T[33] = (T[9] + T[12] + T[18] + T[24]) / 91.0;
   T[34] = one / T[33];
   
   /* display summary */   
   if (GTK_CHECK_MENU_ITEM(mflops1)->active) {

        /* iterations summary */
        sprintf(buff, "%ld", m);
        gtk_label_set (GTK_LABEL(label97), buff);
        gtk_widget_show (label97);
   
        /* oneloop nulltime summary */
        sprintf(buff, "%.4f", nulltime);
        gtk_label_set (GTK_LABEL(label98), buff);
        gtk_widget_show (label98);   
   
        /* MFLOPS 1 summary */
        sprintf(buff, "%10.4f", T[28]+(T[28]*OVHD_RATIO/100));
        gtk_label_set (GTK_LABEL(label25), buff);
        gtk_widget_show (label25);  
     
        /* MFLOPS 2 summary */
        sprintf(buff, "%10.4f", T[30]+(T[30]*OVHD_RATIO/100));
        gtk_label_set (GTK_LABEL(label26), buff);
        gtk_widget_show (label26);  
   
        /* MFLOPS 3 summary */
        sprintf(buff, "%10.4f", T[32]+(T[32]*OVHD_RATIO/100));
        gtk_label_set (GTK_LABEL(label27), buff);
        gtk_widget_show (label27);  
   
        /* MFLOPS 4 summary */
        sprintf(buff, "%10.4f", T[34]+(T[34]*OVHD_RATIO/100));
        gtk_label_set (GTK_LABEL(label28), buff);
        gtk_widget_show (label28);
        /*
        gtk_widget_hide(summary1);
        gtk_widget_hide(separator2);
        */
        standby_statbar();
        done_statbar();

        while (gtk_events_pending()) gtk_main_iteration(); 
        
    }
 
    else {
                    
        /* iterations summary */
        sprintf(buff, "%10ld", m);
        gtk_label_set (GTK_LABEL(label97), buff);
        gtk_widget_show (label97);
   
        /* oneloop nulltime summary */
        sprintf(buff, "%10.4f", nulltime);
        gtk_label_set (GTK_LABEL(label98), buff);
        gtk_widget_show (label98);   
   
        /* GFLOPS 1 summary */
        sprintf(buff, "%10.4f", (T[28]+(T[28]*OVHD_RATIO/100))/1000);
        gtk_label_set (GTK_LABEL(label25), buff);
        gtk_widget_show (label25);  
     
        /* GFLOPS 2 summary */
        sprintf(buff, "%10.4f", (T[30]+(T[30]*OVHD_RATIO/100))/1000);
        gtk_label_set (GTK_LABEL(label26), buff);
        gtk_widget_show (label26);  
   
        /* GFLOPS 3 summary */
        sprintf(buff, "%10.4f", (T[32]+(T[32]*OVHD_RATIO/100))/1000);
        gtk_label_set (GTK_LABEL(label27), buff);
        gtk_widget_show (label27);  
   
        /* GFLOPS 4 summary */
        sprintf(buff, "%10.4f", (T[34]+(T[34]*OVHD_RATIO/100))/1000);
        gtk_label_set (GTK_LABEL(label28), buff);
        
        gtk_widget_show (label28);

        standby_statbar();
        done_statbar();

        while (gtk_events_pending()) gtk_main_iteration(); 
        
    }
    
    /* assign results to glob_[vars] */
    sprintf(glob_mflp1, "%10.4f", T[28]+(T[28]*OVHD_RATIO/100));
    sprintf(glob_mflp2, "%10.4f", T[30]+(T[30]*OVHD_RATIO/100));
    sprintf(glob_mflp3, "%10.4f", T[32]+(T[32]*OVHD_RATIO/100));
    sprintf(glob_mflp4, "%10.4f", T[34]+(T[34]*OVHD_RATIO/100));
    
    sprintf(glob_gflp1, "%10.4f", (T[28]+(T[28]*OVHD_RATIO/100))/1000);
    sprintf(glob_gflp2, "%10.4f", (T[30]+(T[30]*OVHD_RATIO/100))/1000);
    sprintf(glob_gflp3, "%10.4f", (T[32]+(T[32]*OVHD_RATIO/100))/1000);
    sprintf(glob_gflp4, "%10.4f", (T[34]+(T[34]*OVHD_RATIO/100))/1000);    
    
    return;    

}

/* clear view function */
void clear_table() {

    /* reset module view */
    gtk_widget_hide (label66);
    gtk_widget_hide (label68);
    gtk_widget_hide (label69);
    gtk_widget_hide (label70);
    gtk_widget_hide (label71);
    gtk_widget_hide (label72);
    gtk_widget_hide (label73);
    gtk_widget_hide (label75);
    gtk_widget_hide (label76);
    gtk_widget_hide (label77);
    gtk_widget_hide (label78);
    gtk_widget_hide (label79);
    gtk_widget_hide (label80);
    gtk_widget_hide (label81);
    gtk_widget_hide (label83);
    gtk_widget_hide (label84);
    gtk_widget_hide (label86);
    gtk_widget_hide (label1);
    gtk_widget_hide (label2);
    gtk_widget_hide (label5);
    gtk_widget_hide (label4);
    gtk_widget_hide (label12);
    gtk_widget_hide (label3);
    gtk_widget_hide (label17);
    gtk_widget_hide (label7);
    gtk_widget_hide (label34);
    gtk_widget_hide (label85);
    gtk_widget_hide (label35);
    gtk_widget_hide (label36);
    gtk_widget_hide (label37);
    gtk_widget_hide (label6);
    gtk_widget_hide (label11);
    gtk_widget_hide (label13);
    gtk_widget_hide (label14);
    gtk_widget_hide (label15);
    gtk_widget_hide (label16);
    gtk_widget_hide (label18);
    gtk_widget_hide (label10);
    gtk_widget_hide (label38);
    gtk_widget_hide (label39);
    gtk_widget_hide (label40);
    gtk_widget_hide (label8);
    gtk_widget_hide (label41);
    gtk_widget_hide (label42);
    gtk_widget_hide (label43);
    gtk_widget_hide (label44);
    gtk_widget_hide (label45);
    gtk_widget_hide (label46);
    gtk_widget_hide (label47);
    gtk_widget_hide (label9);
    gtk_widget_hide (label48);
    gtk_widget_hide (label49);
    gtk_widget_hide (label50);
    gtk_widget_hide (label88);
    gtk_widget_hide (label89);
    gtk_widget_hide (label96);
    gtk_widget_hide (label94);
    gtk_widget_hide (label92);
    gtk_widget_hide (label91);
    gtk_widget_hide (label90);
    gtk_widget_hide (label93);
    gtk_widget_hide (label95);
    gtk_widget_hide (label87);
    gtk_widget_hide (label74);
    gtk_widget_hide (label82);
    gtk_widget_hide (label58);
    gtk_widget_hide (label63);
    gtk_widget_hide (label52);
    gtk_widget_hide (label53);
    gtk_widget_hide (label54);
    gtk_widget_hide (label55);
    gtk_widget_hide (label56);
    gtk_widget_hide (label65);
    gtk_widget_hide (label57);
    gtk_widget_hide (label67);  

    /* reset summary view */
    gtk_widget_hide (label97);
    gtk_widget_hide (label25);
    gtk_widget_hide (label26);  
    gtk_widget_hide (label98);
    gtk_widget_hide (label27);
    gtk_widget_hide (label28);

    /* hide summary view */
    gtk_label_set (GTK_LABEL(label97), "");
    gtk_label_set (GTK_LABEL(label25), "");
    gtk_label_set (GTK_LABEL(label26), "");
    gtk_label_set (GTK_LABEL(label98), "");
    gtk_label_set (GTK_LABEL(label27), "");
    gtk_label_set (GTK_LABEL(label28), "");

    /* flush output buffers */
    strcpy(glob_mflp1,"");
    strcpy(glob_mflp2,"");
    strcpy(glob_mflp3,"");
    strcpy(glob_mflp4,"");
    strcpy(glob_gflp1,"");
    strcpy(glob_gflp2,"");
    strcpy(glob_gflp3,"");
    strcpy(glob_gflp4,"");

    /* flush 2nd statusbar buffer */
    erase2_statbar();

}

/* some statbar functions below */
int ovhd_ratio2_statbar()
{
  sprintf(buff, " ovhd ratio %d%%", OVHD_RATIO);
  gtk_statusbar_push( GTK_STATUSBAR(statusbar2), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar2), "statbar1"), buff);
  return 0;
}

int standby_statbar()
{
  gchar buffz[] = " ready";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);
  return 0;
}

int tabclear_statbar()
{
  gchar buffz[] = " resetting table";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                       GTK_STATUSBAR(statusbar1), "statbar1"), buffz);

  return 0;
}

int done_statbar()
{
  gchar buffz[] = " all done.";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar2), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar2), "statbar2"), buffz);

  return 0;
}

int erase2_statbar()
{
  gchar buffz[] = " ";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar2), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar2), "statbar2"), buffz);

  return 0;
}


int runmod1_statbar()
{
  gchar buffz[] = " processing module 1, please wait..."; 
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);
                          
  return 0;
}

int runmod2_statbar()
{
  gchar buffz[] = " processing module 2, please wait...";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);
  return 0;
}

int runmod3_statbar()
{
  gchar buffz[] = " processing module 3, please wait...";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);

  return 0;
}

int runmod4_statbar()
{
  gchar buffz[] = " processing module 4, please wait...";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);

  return 0;
}

int runmod5_statbar()
{
  gchar buffz[] = " processing module 5, please wait...";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);

  return 0;
}

int runmod6_statbar()
{
  gchar buffz[] = " processing module 6, please wait...";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);

  return 0;
}

int runmod7_statbar()
{
  gchar buffz[] = " processing module 7, please wait...";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);

  return 0;
}

int runmod8_statbar()
{
  gchar buffz[] = " processing module 8, please wait...";
  gtk_statusbar_push( GTK_STATUSBAR(statusbar1), gtk_statusbar_get_context_id(
                         GTK_STATUSBAR(statusbar1), "statbar1"), buffz);

  return 0;
}
