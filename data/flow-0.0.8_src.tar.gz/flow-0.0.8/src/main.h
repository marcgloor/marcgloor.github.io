/*
 * flow - floating point operations per second benchmark
 * Copyright (C) 02/04/2000 by Marc O. Gloor <mgloor@fhzh.ch>
 *
 * $Id$
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

/* Globale Variables */
int OVHD_RATIO;
char glob_mflp1[36];
char glob_mflp2[36];
char glob_mflp3[36];
char glob_mflp4[36];
char glob_gflp1[36];
char glob_gflp2[36];
char glob_gflp3[36];
char glob_gflp4[36];
GtkWidget* create_main_wnd (void);
GtkWidget* create_about_wnd (void);
GtkWidget *about_wnd;
GtkWidget *label66;
GtkWidget *label22;
GtkWidget *label21;
GtkWidget *label26;
GtkWidget *label19;
GtkWidget *label20;
GtkWidget *label24;
GtkWidget *label23;
GtkWidget *label28;
GtkWidget *label25;
GtkWidget *label27;
GtkWidget *label97;
GtkWidget *label98;
GtkWidget *label59;
GtkWidget *label64;
GtkWidget *label68;
GtkWidget *label69;
GtkWidget *label70;
GtkWidget *label71;
GtkWidget *label72;
GtkWidget *label73;
GtkWidget *label75;
GtkWidget *label76;
GtkWidget *label77;
GtkWidget *label78;
GtkWidget *label79;
GtkWidget *label80;
GtkWidget *label81;
GtkWidget *label61;
GtkWidget *label83;
GtkWidget *label84;
GtkWidget *label86;
GtkWidget *label1;
GtkWidget *label2;
GtkWidget *label5;
GtkWidget *label4;
GtkWidget *label12;
GtkWidget *label3;
GtkWidget *label17;
GtkWidget *label7;
GtkWidget *label34;
GtkWidget *label85;
GtkWidget *label35;
GtkWidget *label36;
GtkWidget *label37;
GtkWidget *label51;
GtkWidget *label6;
GtkWidget *label11;
GtkWidget *label13;
GtkWidget *label14;
GtkWidget *label15;
GtkWidget *label16;
GtkWidget *label18;
GtkWidget *label10;
GtkWidget *label38;
GtkWidget *label39;
GtkWidget *label40;
GtkWidget *label8;
GtkWidget *label41;
GtkWidget *label42;
GtkWidget *label43;
GtkWidget *label44;
GtkWidget *label45;
GtkWidget *label46;
GtkWidget *label47;
GtkWidget *label9;
GtkWidget *label48;
GtkWidget *label49;
GtkWidget *label50;
GtkWidget *label88;
GtkWidget *label89;
GtkWidget *label62;
GtkWidget *label96;
GtkWidget *label94;
GtkWidget *label92;
GtkWidget *label91;
GtkWidget *label90;
GtkWidget *label60;
GtkWidget *label93;
GtkWidget *label95;
GtkWidget *label87;
GtkWidget *label74;
GtkWidget *label82;
GtkWidget *label58;
GtkWidget *label63;
GtkWidget *label52;
GtkWidget *label53;
GtkWidget *label54;
GtkWidget *label55;
GtkWidget *label56;
GtkWidget *label65;
GtkWidget *label57;
GtkWidget *label67;
GtkWidget *statusbar1;
GtkWidget *statusbar2;
GtkWidget *mflops1;
GtkWidget *gflops1;
GtkWidget *summary1;

void
on_quit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cpu_information1_activate           (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_os_information1_activate            (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_run_benchmark1_activate             (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_stop_benchmark1_activate            (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_clear_table1_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_mflops1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_gflops1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_info1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

/* Public Functions */

GtkWidget*  lookup_widget              (GtkWidget       *widget,
                                        const gchar     *widget_name);

#define get_widget lookup_widget

void        add_pixmap_directory       (const gchar     *directory);

/* Private Functions */

GtkWidget*  create_pixmap              (GtkWidget       *widget,
                                        const gchar     *filename);
