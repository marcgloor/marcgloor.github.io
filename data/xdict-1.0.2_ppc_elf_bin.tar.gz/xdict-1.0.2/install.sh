#/bin/sh 
# Installation shellscript for xdict 1.0.2
# run as root! 

mkdir /usr/local/xdict
mv xdict.bin /usr/local/bin/
mv xdict.dat /usr/local/xdict/
mv COPYING README xdict.ps /usr/local/xdict/
mv xdict.1 /usr/man/man1/
echo
echo XDICT 1.0.2 successfully installed
echo
echo - logout from rooti / login as normal user
echo - run with: xdict.bin -d /usr/local/xdict/xdict.dat
echo - manpage:  man xdict
echo
