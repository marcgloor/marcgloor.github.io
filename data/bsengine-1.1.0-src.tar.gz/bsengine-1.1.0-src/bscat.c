/*
 * $Id: bscat.c,v 1.5 2026/03/12 19:14:19 gloor Exp $
 * 
 * bscat - Black/Scholes Option pricing viewer
 * written by Marc O. Gloor <marc.gloor@u.nus.edu>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

#define REL "1.1.0"    /* define release output */
#define SEP ";"        /* define output separator */

/* function prototyping - Fixed: removed conflicting main() prototype */
void show_prog_header(void);
void sub_hlp(void);
void sub_release(void);
void sub_display_results(void);

/* Global buffers for data fields - Fixed: increased size for safety */
char get_01[32], get_02[32], get_03[32], get_04[32], get_05[32], get_06[32],
     get_07[32], get_08[32], get_09[32], get_10[32], get_11[32], get_12[32],
     get_13[32], get_14[32], get_15[32], get_16[32], get_17[32], get_18[32],
     get_19[32], get_20[32], get_21[32], get_22[32], get_23[32], get_24[32],
     get_25[32];

int main(int argc, char *argv[]) {
    int cnt = 0;
    char input[1024];
    char *pe;

    if ((argc == 2) && (strcmp(argv[1], "-h") == 0)) {
        show_prog_header();       
        sub_hlp();
    } else if ((argc == 2) && (strcmp(argv[1], "-r") == 0)) {
        show_prog_header();
        sub_release();
    }

    /* Fixed: Use fgets instead of scanf to read the whole line including spaces */
    if (fgets(input, sizeof(input), stdin) == NULL) {
        return 0;
    }

    /* Strip newline if present */
    input[strcspn(input, "\n")] = 0;

    pe = strtok(input, SEP);
    while (pe != NULL) {
        cnt++;
        switch (cnt) {
            case 1:  strncpy(get_01, pe, 31); break;
            case 2:  strncpy(get_02, pe, 31); break;
            case 3:  strncpy(get_03, pe, 31); break;
            case 4:  strncpy(get_04, pe, 31); break;
            case 5:  strncpy(get_05, pe, 31); break;
            case 6:  strncpy(get_06, pe, 31); break;
            case 7:  strncpy(get_07, pe, 31); break;
            case 8:  strncpy(get_08, pe, 31); break;
            case 9:  strncpy(get_09, pe, 31); break;
            case 10: strncpy(get_10, pe, 31); break;
            case 11: strncpy(get_11, pe, 31); break;
            case 12: strncpy(get_12, pe, 31); break;
            case 13: strncpy(get_13, pe, 31); break;
            case 14: strncpy(get_14, pe, 31); break;
            case 15: strncpy(get_15, pe, 31); break;
            case 16: strncpy(get_16, pe, 31); break;
            case 17: strncpy(get_17, pe, 31); break;
            case 18: strncpy(get_18, pe, 31); break;
            case 19: strncpy(get_19, pe, 31); break;
            case 20: strncpy(get_20, pe, 31); break;
            case 21: strncpy(get_21, pe, 31); break;
            case 22: strncpy(get_22, pe, 31); break;
            case 23: strncpy(get_23, pe, 31); break;
            case 24: strncpy(get_24, pe, 31); break;
            case 25: strncpy(get_25, pe, 31); break;
        }
        pe = strtok(NULL, SEP);
    }

    if (cnt > 0) {
        sub_display_results();
    }

    return 0;
} 

void sub_display_results(void) {
    printf(" +---------------------------------------------------------------------------+\n");
    printf(" | Date: %-11s| Time: %-11s| Rate: %-11s| TTM: %-12s|\n", get_01, get_02, get_08, get_07);
    printf(" |------------------+------------------+------------------+------------------|\n");
    printf(" | Share: %-10s| Strk: %-11s| Ratio: %-10s| Type: %-11s|\n", get_04, get_05, get_06, get_03);
    printf(" |------------------+------------------+------------------+------------------|\n");
    printf(" | Price: %-10s| Vola: %-11s| InOut: %-10s| Delta: %-10s|\n", get_09, get_10, get_11, get_14);
    printf(" |------------------+------------------+------------------+------------------|\n");
    printf(" | Prem: %-11s| Pre/Y: %-10s| Sprd: %-11s| SprdM: %-10s|\n", get_19, get_20, get_21, get_22);
    printf(" |------------------+------------------+------------------+------------------|\n");
    printf(" | Gear: %-11s| Omega: %-10s| Gamma: %-10s| Theta: %-10s|\n", get_12, get_13, get_15, get_16);
    printf(" |------------------+------------------+------------------+------------------|\n");
    printf(" | Vega: %-11s| Rho: %-12s| B/E: %-12s|                  |\n", get_17, get_18, get_25);
    printf(" +---------------------------------------------------------------------------+\n");
}

void sub_hlp(void) {
    printf(" usage  : bscat [options]\n");
    printf(" example: bsengine [args] | bscat\n\n");
    printf(" options are:\n");
    printf("  -h  show help\n");
    printf("  -r  show release\n\n");
    exit(0);
}

void show_prog_header(void) {
    printf("bscat " REL " - Black/Scholes Option pricing viewer (UNIX)\n");
}

void sub_release(void) {
    printf(" release: " REL "\n");
    printf(" built: %s at %s\n", __DATE__, __TIME__);	
    printf(" compiler: %s\n\n", __VERSION__);
    exit(0);
}
