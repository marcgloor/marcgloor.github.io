/*
 * $Id: bsengine.c,v 1.7 2026/03/12 19:13:45 gloor Exp $
 * 
 * bsengine - Black Scholes Option pricing and related calculations
 * written by Marc O. Gloor <marc.gloor@u.nus.edu>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

#define REL "1.1.0"
#define SEP ";"

#ifndef PI 
#define PI 3.14159265358979323846
#endif 

typedef struct {
    double delta;
    double gamma;
    double theta;
    double vega;
    double rho;
} Greeks;

/* Function Prototyping */
double opt_pricing(char f, double S, double X, double r, double time, double sigma);
double N(double z);
double n(double z);
double calculate_implied_vola(char f, double S, double X, double r, double time, double option_price);
double gearing(double S, double ratio, double price);
double omega(double gear, double delta);
double premium(char f, double price, double ratio, double S, double X);
double premium_pa(char f, double price, double time_days, double ratio, double S, double X);
double breakeven(char f, double price, double X, double ratio);
double calculate_spread(double bid, double ask);
double calculate_spread_move(double bid, double ask, double ratio, double delta);
Greeks calculate_greeks(char f, double S, double X, double r, double time, double sigma);
double comp_mat(const char *date_maturity);
void get_date_time_strings(char *d_out, char *t_out);
void show_prog_header(void);
void sub_hlp(void);
void sub_release(void);

int find_vola(char *f, double S, double X, double r, char *time_str, double ratio, double bid, double ask);
int find_price(char *f, double S, double X, double r, char *time_str, double ratio, double sigma);

int main(int argc, char *argv[]) {
    if (argc == 1) {
        show_prog_header();
        printf("  Error: No arguments provided. Use -h for help.\n\n");
        return 1;
    }

    if (strcmp(argv[1], "-h") == 0) {
        show_prog_header();
        sub_hlp();
    } else if (strcmp(argv[1], "-r") == 0) {
        show_prog_header();
        sub_release();
    } else if (argc == 10 && strcmp(argv[1], "-v") == 0) {
        find_vola(argv[2], atof(argv[3]), atof(argv[4]), atof(argv[5]),
                  argv[6], atof(argv[7]), atof(argv[8]), atof(argv[9]));
    } else if (argc == 9 && strcmp(argv[1], "-p") == 0) {
        find_price(argv[2], atof(argv[3]), atof(argv[4]), atof(argv[5]),
                   argv[6], atof(argv[7]), atof(argv[8]));
    } else {
        show_prog_header();
        printf("  Invalid arguments. Use -h for help.\n\n");
        return 1;
    }
    return 0;
}

int find_vola(char *f, double S, double X, double r, char *time_str, double ratio, double bid, double ask) {
    double t_days = comp_mat(time_str);
    if (t_days <= 0) {
        fprintf(stderr, "Error: Maturity date must be in the future.\n");
        return 1;
    }

    double t_years = t_days / 365.25;
    double r_dec = r / 100.0;
    char type = (char)tolower(f[0]);

    double vol = calculate_implied_vola(type, S, X, r_dec, t_years, ask * ratio);
    Greeks g = calculate_greeks(type, S, X, r_dec, t_years, vol);
    double gear = gearing(S, ratio, ask);
    double om = omega(gear, g.delta);
    double prem = premium(type, ask, ratio, S, X);
    double p_pa = premium_pa(type, ask, t_days, ratio, S, X);
    double be = breakeven(type, ask, X, ratio);
    double sprd = calculate_spread(bid, ask);
    double sprd_mv = calculate_spread_move(bid, ask, ratio, g.delta);

    char d_str[12], t_str[12];
    get_date_time_strings(d_str, t_str);

    printf("%s" SEP "%s" SEP "%c" SEP "%.2f" SEP "%.2f" SEP "%.0f" SEP "%.0f" SEP "%.1f%%" SEP 
           "%.2f" SEP "%.2f" SEP "%.2f%%" SEP "%.2f" SEP "%.2f%%" SEP "%.2f" SEP "%.2f" SEP 
           "%.4f" SEP "%.4f" SEP "%.4f" SEP "%.4f" SEP "%.2f%%" SEP "%.2f%%" SEP "%.2f\n",
           d_str, t_str, toupper(type), S, X, ratio, t_days, r, bid, ask, sprd, sprd_mv, vol * 100.0, 
           gear, om, g.delta, g.gamma, g.theta, g.vega, prem, p_pa, be);

    return 0;
}

int find_price(char *f, double S, double X, double r, char *time_str, double ratio, double sigma) {
    double t_days = comp_mat(time_str);
    if (t_days <= 0) return 1;

    double t_years = t_days / 365.25;
    double r_dec = r / 100.0;
    double vol_dec = sigma / 100.0;
    char type = (char)tolower(f[0]);

    double price = opt_pricing(type, S, X, r_dec, t_years, vol_dec) / ratio;
    Greeks g = calculate_greeks(type, S, X, r_dec, t_years, vol_dec);
    
    char d_str[12], t_str[12];
    get_date_time_strings(d_str, t_str);

    printf("%s" SEP "%s" SEP "%c" SEP "Price: %.4f" SEP "Delta: %.4f" SEP "Vega: %.4f\n", 
           d_str, t_str, toupper(type), price, g.delta, g.vega);
    
    return 0;
}

/* --- Financial Functions --- */

double opt_pricing(char f, double S, double X, double r, double time, double sigma) {
    if (time <= 0) return (f == 'c') ? fmax(0.0, S - X) : fmax(0.0, X - S);
    double d1 = (log(S / X) + (r + 0.5 * sigma * sigma) * time) / (sigma * sqrt(time));
    double d2 = d1 - sigma * sqrt(time);
    if (f == 'c') return S * N(d1) - X * exp(-r * time) * N(d2);
    else return X * exp(-r * time) * N(-d2) - S * N(-d1);
}

Greeks calculate_greeks(char f, double S, double X, double r, double time, double sigma) {
    Greeks g = {0};
    if (time <= 0 || sigma <= 1e-9) return g;
    double d1 = (log(S / X) + (r + 0.5 * sigma * sigma) * time) / (sigma * sqrt(time));
    double d2 = d1 - sigma * sqrt(time);
    g.delta = (f == 'c') ? N(d1) : N(d1) - 1.0;
    g.gamma = n(d1) / (S * sigma * sqrt(time));
    g.vega = (S * sqrt(time) * n(d1)) / 100.0;
    double theta_part1 = -(S * sigma * n(d1)) / (2.0 * sqrt(time));
    if (f == 'c') {
        g.theta = (theta_part1 - r * X * exp(-r * time) * N(d2)) / 365.0;
        g.rho = (X * time * exp(-r * time) * N(d2)) / 100.0;
    } else {
        g.theta = (theta_part1 + r * X * exp(-r * time) * N(-d2)) / 365.0;
        g.rho = (-X * time * exp(-r * time) * N(-d2)) / 100.0;
    }
    return g;
}

double calculate_implied_vola(char f, double S, double X, double r, double time, double market_price) {
    double sigma = 0.5; 
    const double ACCURACY = 1.0e-6;
    for (int i = 0; i < 100; i++) {
        double price = opt_pricing(f, S, X, r, time, sigma);
        double d1 = (log(S / X) + (r + 0.5 * sigma * sigma) * time) / (sigma * sqrt(time));
        double vega = S * sqrt(time) * n(d1);
        if (vega < 1e-8) break; 
        double diff = market_price - price;
        if (fabs(diff) < ACCURACY) return sigma;
        sigma += diff / vega;
        if (sigma <= 0) sigma = 0.0001; 
    }
    return sigma;
}

/* --- Helpers --- */

double N(double z) {
    double L = fabs(z);
    double k = 1.0 / (1.0 + 0.2316419 * L);
    double a1 = 0.319381530, a2 = -0.356563782, a3 = 1.781477937, a4 = -1.821255978, a5 = 1.330274429;
    double result = 1.0 - (1.0 / sqrt(2.0 * PI)) * exp(-L * L / 2.0) * (a1 * k + a2 * k * k + a3 * pow(k, 3) + a4 * pow(k, 4) + a5 * pow(k, 5));
    return (z >= 0) ? result : 1.0 - result;
}

double n(double z) { return (1.0 / sqrt(2.0 * PI)) * exp(-0.5 * z * z); }

double comp_mat(const char *date_maturity) {
    struct tm tm_mat = {0};
    int d, m, y;
    if (sscanf(date_maturity, "%d.%d.%d", &d, &m, &y) != 3) return -1;
    tm_mat.tm_mday = d; tm_mat.tm_mon = m - 1; tm_mat.tm_year = y - 1900; tm_mat.tm_isdst = -1;
    time_t t_now = time(NULL);
    time_t t_mat = mktime(&tm_mat);
    if (t_mat == -1) return -1;
    return difftime(t_mat, t_now) / (24.0 * 3600.0);
}

double calculate_spread(double bid, double ask) {
    return (ask > 0) ? ((ask - bid) / ask) * 100.0 : 0;
}

double calculate_spread_move(double bid, double ask, double ratio, double delta) {
    return (fabs(delta) > 1e-7) ? ((ask - bid) * ratio) / fabs(delta) : 0;
}

double gearing(double S, double ratio, double price) {
    return (price > 0 && ratio > 0) ? (S / ratio) / price : 0;
}

double omega(double gear, double delta) { return fabs(gear * delta); }

double premium(char f, double price, double ratio, double S, double X) {
    if (S <= 0) return 0;
    return (f == 'c') ? 100.0 * ((X + (price * ratio) - S) / S) : 100.0 * ((S - (X - price * ratio)) / S);
}

double premium_pa(char f, double price, double time_days, double ratio, double S, double X) {
    return (time_days > 0) ? (premium(f, price, ratio, S, X) * (365.25 / time_days)) : 0;
}

double breakeven(char f, double price, double X, double ratio) {
    return (f == 'c') ? (price * ratio) + X : X - (price * ratio);
}

void get_date_time_strings(char *d_out, char *t_out) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    strftime(d_out, 12, "%d-%m-%Y", t);
    strftime(t_out, 12, "%H:%M:%S", t);
}

void show_prog_header(void) { printf("bsengine " REL " - Black/Scholes Option Engine\n"); }

void sub_hlp(void) {
    printf(" usage  : bsengine [options] [arguments]\n");
    printf(" synopsis: bsengine -v c 6024.2 8000 4.0 20.10.2045 500 0.02 0.03\n\n");
    printf(" options are:\n");
    printf("  -h  show help                  -v  compute priced volatility\n");
    printf("  -r  show release               -p  compute fair price\n\n");
    printf(" -v arguments are (in correct order):   -p arguments are (in correct order):\n");
    printf("  -1st  Call/Put flag [c/p]               -1st  Call/Put flag [c/p]\n");
    printf("  -2nd  Underlying price [dec]            -2nd  Underlying price [dec]\n");
    printf("  -3rd  Strike price [dec]                -3rd  Strike price [dec]\n");
    printf("  -4th  Interest Rate in %% [dec]          -4th  Interest Rate in %% [dec]\n");
    printf("  -5th  T.t. Maturity [dd.mm.yyyy]        -5th  T.t. Maturity [dd.mm.yyyy]\n");
    printf("  -6th  Options ratio [dec]               -6th  Options ratio [dec]\n");
    printf("  -7th  Bid price [dec]                   -7th  Given volatility in %% [dec]\n");
    printf("  -8th  Ask price [dec]\n\n");
    exit(0);
}

void sub_release(void) { 
    printf("Release: " REL "\nBuilt: %s %s\n", __DATE__, __TIME__); 
    exit(0);
}
