/*
 * xmon (beta 0.0.3b), performance monitor for linux (load, mem, cpu)
 * Copyright (C) 1998-2026 by Marc Gloor <marc.gloor@u.nus.edu>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <assert.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h> 

#define WIN_W 300
#define WIN_H 107

/* Prototypes */
long mem_used(void);
long mem_avl(void);
long cpu_usage(void);
int loadavg(void);
int draw_graphics(void);

/* Globals for CPU calculation */
unsigned long cpu_jiffie_tot_old = 0;
unsigned long cpu_jiffie_usrnice_old = 0;

int main() {
    printf("\n  xmon 0.0.3b, written by Marc Gloor <marc.gloor@u.nus.edu>\n\n");
    draw_graphics();
    return 0;
}

int draw_graphics() {
    Window w;
    XGCValues gr_values; 
    XSizeHints *hints;
    char hostname[30];
    char softname[] = "xmon@";
    char WindowName[100];
    GC kc, gc, ec, hc, bc;      
    int blackColor, i, h, k, z, y, stackInit;

    int cpu[22], mem[22], stack[22];
    long init_mem_avl;
    Pixmap pix;  
    Colormap screen_colormap;
    XColor red, cyan, yellow, DarkGreen;

    Display *dpy = XOpenDisplay(NULL);
    if (dpy == NULL) {
        fprintf(stderr, "error: can't connect to X server!\n");
        exit(1);
    }

    blackColor = BlackPixel(dpy, DefaultScreen(dpy));
    
    w = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), 0, 0, 
                             WIN_W, WIN_H, 0, blackColor, blackColor);

    hints = XAllocSizeHints();
    if (hints) {
        hints->flags = PMinSize | PMaxSize;
        hints->min_width = hints->max_width = WIN_W;
        hints->min_height = hints->max_height = WIN_H;
        XSetWMNormalHints(dpy, w, hints);
        XFree(hints);
    }

    pix = XCreatePixmap(dpy, w, WIN_W, WIN_H, DefaultDepth(dpy, DefaultScreen(dpy))); 
    screen_colormap = DefaultColormap(dpy, DefaultScreen(dpy));

    if (gethostname(hostname, 30) != 0) strcpy(hostname, "unknown");
    snprintf(WindowName, sizeof(WindowName), "%s%s", softname, hostname);
    XStoreName(dpy, w, WindowName);

    XAllocNamedColor(dpy, screen_colormap, "red", &red, &red);
    XAllocNamedColor(dpy, screen_colormap, "cyan", &cyan, &cyan);
    XAllocNamedColor(dpy, screen_colormap, "yellow", &yellow, &yellow);
    XAllocNamedColor(dpy, screen_colormap, "DarkGreen", &DarkGreen, &DarkGreen);

    XFontStruct *font = XLoadQueryFont(dpy, "6x10");
    if (!font) font = XLoadQueryFont(dpy, "fixed");
    gr_values.font = font->fid;

    kc = XCreateGC(dpy, w, GCFont, &gr_values); 
    gc = XCreateGC(dpy, w, GCFont, &gr_values);
    ec = XCreateGC(dpy, w, GCFont, &gr_values);
    hc = XCreateGC(dpy, w, GCFont, &gr_values);
    bc = XCreateGC(dpy, w, GCFont, &gr_values);

    XSetForeground(dpy, kc, yellow.pixel);
    XSetForeground(dpy, gc, DarkGreen.pixel);
    XSetForeground(dpy, ec, cyan.pixel);   
    XSetForeground(dpy, hc, red.pixel);
    XSetForeground(dpy, bc, blackColor);

    XSelectInput(dpy, w, StructureNotifyMask | ExposureMask);  
    XMapWindow(dpy, w);

    for(;;) {
        XEvent e;
        XNextEvent(dpy, &e);
        if (e.type == MapNotify) break;
    }

    init_mem_avl = mem_avl();
    if (init_mem_avl <= 0) init_mem_avl = 1; 
    z = -1;

    for (;;) {
        if (z > 1000) z = -1;
        z += 1;

        for (stackInit = 21; stackInit >= 1; stackInit--) {
            cpu[stackInit] = cpu[stackInit-1];
            mem[stackInit] = mem[stackInit-1];
            stack[stackInit] = stack[stackInit-1];
        }

        cpu[0] = (105 - ((105 * cpu_usage()) / 100));
        mem[0] = 105 - ((mem_used() * 105) / init_mem_avl);
        stack[0] = 105 - (loadavg() / 10); 

        for (i = 0; i < 15; i++) { 
            XFillRectangle(dpy, pix, bc, 0, 0, WIN_W, WIN_H);

            /* Blink logic: 50ms * 5 frames = 250ms toggle (2Hz) */
            int blink_visible = ((i / 5) % 2 == 0);

            for (h = 0; h < 22; h++) { 
                XDrawLine(dpy, pix, gc, ((WIN_W-(h*15))-i), 0, ((WIN_W-(h*15))-i), 105);
            }
            for (k = 0; k < 8; k++) { 
                XDrawLine(dpy, pix, gc, 0, k*15, WIN_W, k*15);
            }

            for (y = 0; y < 22; y++) { 
                if (z > y-1) {
                    int x1 = WIN_W-i-((y-1)*15);
                    int x2 = 315-i-((y-1)*15);
                    int py = (y == 0) ? 0 : y-1;

                    XDrawLine(dpy, pix, ec, x1, stack[y], x2, stack[py]);
                    XDrawLine(dpy, pix, hc, x1, mem[y], x2, mem[py]);
                    XDrawLine(dpy, pix, kc, x1, cpu[y], x2, cpu[py]);
                }
            }

            /* --- Label Positioning & Staggering --- */
            int ly = (stack[0] > 90) ? stack[0] + 15 : stack[0] - 4;
            int my = (mem[0] > 90) ? mem[0] + 15 : mem[0] - 4;
            int cy = (cpu[0] > 90) ? cpu[0] + 15 : cpu[0] - 4;

            if (stack[0] < 12) ly = 12;
            if (mem[0] < 12)   my = 12;
            if (cpu[0] < 12)   cy = 12;

            int lx = 265, mx = 265, cx = 265;
            int step = 36; /* Dynamic shift: 4 chars * 6px + 12px buffer */

            if (abs(ly - my) < 11) mx -= step;
            if (abs(ly - cy) < 11) cx -= step;
            if (abs(my - cy) < 11) {
                if (cx >= mx) cx = mx - step;
            }

            /* Render LOAD (Blink if overflown) */
            if (stack[0] < 12) {
                if (blink_visible) XDrawString(dpy, pix, ec, lx - 15, ly, "^^ LOAD ^^", 10);
            } else XDrawString(dpy, pix, ec, lx, ly, "LOAD", 4);

            /* Render MEM (Blink if overflown) */
            if (mem[0] < 12) {
                if (blink_visible) XDrawString(dpy, pix, hc, mx - 15, my, "^^ MEM ^^", 9);
            } else XDrawString(dpy, pix, hc, mx, my, "MEM", 3);

            /* Render CPU (Blink if overflown) */
            if (cpu[0] < 12) {
                if (blink_visible) XDrawString(dpy, pix, kc, cx - 15, cy, "^^ CPU ^^", 9);
            } else XDrawString(dpy, pix, kc, cx, cy, "CPU", 3);

            XCopyArea(dpy, pix, w, kc, 0, 0, WIN_W, WIN_H, 0, 0);
            XFlush(dpy); 
            usleep(50000);
        }
    } 
    return 0;
}

long cpu_usage(void) {
    FILE *fp = fopen("/proc/stat", "r");
    if (!fp) return 0;
    unsigned long u, n, s, id, iow, irq, soft;
    if (fscanf(fp, "cpu %lu %lu %lu %lu %lu %lu %lu", &u, &n, &s, &id, &iow, &irq, &soft) < 4) {
        fclose(fp); return 0;
    }
    fclose(fp);
    unsigned long tot = u + n + s + id + iow + irq + soft;
    unsigned long work = u + n + s;
    long load = 0;
    if (cpu_jiffie_tot_old > 0 && tot > cpu_jiffie_tot_old) {
        load = ((work - cpu_jiffie_usrnice_old) * 100) / (tot - cpu_jiffie_tot_old);
    }
    cpu_jiffie_tot_old = tot;
    cpu_jiffie_usrnice_old = work;
    return (load > 100) ? 100 : (load < 0 ? 0 : load);
}

int loadavg(void) {
    double l;
    FILE *fp = fopen("/proc/loadavg", "r");
    if (!fp) return 0;
    if (fscanf(fp, "%lf", &l) < 1) l = 0;
    fclose(fp);
    return (int)(l * 100);
}

long mem_avl(void) {
    long val = 0;
    char label[64];
    FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) return 1;
    while (fscanf(fp, "%63s %ld", label, &val) != EOF) {
        if (strcmp(label, "MemTotal:") == 0) break;
    }
    fclose(fp);
    return val;
}

long mem_used(void) {
    long total = 0, available = 0;
    char label[64];
    long val;
    FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) return 0;
    while (fscanf(fp, "%63s %ld", label, &val) != EOF) {
        if (strcmp(label, "MemTotal:") == 0) total = val;
        if (strcmp(label, "MemAvailable:") == 0) available = val;
    }
    fclose(fp);
    return (total - available > 0) ? (total - available) : 0;
}
