#!/bin/sh
# @(#) MyLang library importer
# 23/10/2005 - written by Marc O. Gloor <mgloor@fhzh.ch>
#
# $Id: MyLang_libimport.sh,v 1.8 2005/10/23 16:24:28 gloor Exp $
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

# $Log: MyLang_libimport.sh,v $
# Revision 1.8  2005/10/23 16:24:28  gloor
# buggy version checkin fixed
# now ready for productional use
#
# Revision 1.7  2005/10/23 16:22:14  gloor
# comment bug eliminated
#
# Revision 1.6  2005/10/23 16:16:26  gloor
# parser bug fixed
#
# Revision 1.5  2005/10/23 13:42:39  gloor
# gpl added
#
# Revision 1.4  2005/10/23 13:32:57  gloor
# ready for use version
#
# Revision 1.3  2005/10/23 11:49:22  gloor
# extensions...
#
# Revision 1.2  2005/10/23 11:47:17  gloor
# initial checkin into RCS
#
# Revision 1.1  2005/10/23 11:22:18  gloor
# Initial revision
#
#

# global definitions
EXIT=0 ; CMD=$0 ; PID=$$ ; HOST=`hostname` ; TMP=/tmp/
LOGTIME () { TIME="`date '+%d-%m-%Y %H:%M:%S'`" ; }
LOG=MyLang_libimport.log ; exec 2>>$LOG
ACTION1="start"
ACTION2="end"
ACTION3="parsing csv"
ACTION4="writing xml"

# begin script
# start logging
LOGTIME; echo "$TIME $HOST $CMD $ACTION1" >> $LOG

echo -n "MyLang dictionary library importer " && echo \$Revision: 1.8 $ | tr -d "$"
echo "23/10/2005 - written by Marc O. Gloor <mgloor@fhzh.ch>"
echo 
echo -n "csv-library to import [file]    : " && read imp_file
echo -n "export to MyLang library [file] : " && read exp_file
echo -n "library description [text]      : " && read description
echo -n "1st language name [name]        : " && read lang0_name
echo -n "2nd language name [name]        : " && read lang1_name
echo "please wait..."
exp_file=$(echo $exp_file | tr " " "_")

# std xml header
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $exp_file
echo -n "<!-- created with MyLang_libimport.sh, " >> $exp_file
echo -n \$Revision: 1.8 $ | tr -d "$" >> $exp_file 
echo "-->" >> $exp_file 
echo >> $exp_file
echo "<dictionary languageName0=\"$lang0_name\" languageName1=\"$lang1_name\" description=\"$description\">" >> $exp_file
echo "  <words>" >> $exp_file

# data part
LOGTIME; echo "$TIME $HOST $CMD $ACTION3 (exit=$EXIT)" >> $LOG
LOGTIME; echo "$TIME $HOST $CMD $ACTION4 (exit=$EXIT)" >> $LOG
cat $imp_file | 
(
 while read string
 do
  lang0=$(echo $string | awk 'split($string, token, ";") { print token[1]}')
  lang1=$(echo $string | awk 'split($string, token, ";") { print token[2]}')
  echo "    <word rev=\"2\">" >> $exp_file
  echo "      <language0>$lang0</language0>" >> $exp_file
  echo "      <language1>$lang1</language1>" >> $exp_file
  echo "    </word>" >> $exp_file
 done
)

# footer
echo "  </words>" >> $exp_file
echo "  <stats/>" >> $exp_file
echo "</dictionary>" >> $exp_file

# stop logging
LOGTIME; echo "$TIME $HOST $CMD $ACTION2 (exit=$EXIT)" >> $LOG
exit $EXIT
