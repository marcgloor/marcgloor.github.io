/*
 * xdict 1.0.7
 * Copyright (c) 2001-2026 by Marc Gloor <marc.gloor@u.nus.edu>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define MaxParLen 10000

typedef struct {
    GtkWidget *main_window;
    GtkWidget *entry_ger;
    GtkWidget *entry_eng;
    GtkWidget *spin_match;
    GtkTextBuffer *text_buffer;
    char *dict_path;
    char label_top[256];    
    char label_bottom[256]; 
} XDictApp;

/* --- Core Logic --- */
long PrepareTheString(char* ConvStr, char* OriginStr) {
    unsigned char* s = (unsigned char*)OriginStr;
    char* d = ConvStr;
    while (*s) {
        if (*s == 196 || *s == 228) { *d++ = 228; }      
        else if (*s == 214 || *s == 246) { *d++ = 246; } 
        else if (*s == 220 || *s == 252) { *d++ = 252; } 
        else if (*s == 223) { *d++ = 's'; *d++ = 's'; }  
        else if (isalnum(*s)) { *d++ = tolower(*s); }
        else { *d++ = ' '; }
        s++;
    }
    *d = '\0';
    return (d - ConvStr);
}

int NGramMatch(char* TextPara, char* SearchStr, int SearchStrLen, int NGramLen, int* MaxMatch) {
    char NGram[8];
    int Count = 0;
    *MaxMatch = 0;
    if (SearchStrLen < NGramLen) return 0;
    int NGramCount = SearchStrLen - NGramLen + 1;
    for(int i = 0; i < NGramCount; i++) {
        memcpy(NGram, &SearchStr[i], NGramLen);
        NGram[NGramLen] = '\0';
        *MaxMatch += NGramLen;
        if(strstr(TextPara, NGram)) Count++;
    }
    return Count * NGramLen;
}

void start_search(GtkButton *btn, gpointer user_data) {
    XDictApp *app = (XDictApp*)user_data;
    const char *ger_text = gtk_editable_get_text(GTK_EDITABLE(app->entry_ger));
    const char *eng_text = gtk_editable_get_text(GTK_EDITABLE(app->entry_eng));
    const char *input = (strlen(ger_text) > 0) ? ger_text : eng_text;
    if (strlen(input) == 0) return;

    int threshold = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(app->spin_match));
    gtk_text_buffer_set_text(app->text_buffer, "", -1);

    FILE *f = fopen(app->dict_path, "r");
    if (!f) {
        gtk_text_buffer_set_text(app->text_buffer, "Error: xdict.dat not in binary path found...", -1);
        return;
    }

    char buffer[MaxParLen];
    fgets(buffer, MaxParLen, f); 

    char clean_search[512], text_para[MaxParLen];
    int s_len = PrepareTheString(clean_search, (char*)input);
    float best_sim = 0.0; int found = 0;

    while(fgets(buffer, MaxParLen - 1, f)) {
        buffer[strcspn(buffer, "\r\n")] = 0;
        if (strlen(buffer) < 3) continue;
        char original_line[MaxParLen];
        strcpy(original_line, buffer);
        PrepareTheString(text_para, buffer);
        int m1, m2;
        int c1 = NGramMatch(text_para, clean_search, s_len, 3, &m1);
        int c2 = NGramMatch(text_para, clean_search, s_len, (s_len < 7 ? 2 : 5), &m2);
        float sim = (m1 + m2 > 0) ? 100.0 * (float)(c1 + c2) / (float)(m1 + m2) : 0;
        if (sim > best_sim) best_sim = sim;
        if (sim >= threshold) {
            char *sep = strchr(original_line, '#');
            if (sep) {
                *sep = '\0';
                char *part_b = sep + 1;
                while(isspace((unsigned char)*part_b)) part_b++;
                char *formatted = g_strdup_printf("%s = %s\n", original_line, part_b);
                GtkTextIter end;
                gtk_text_buffer_get_end_iter(app->text_buffer, &end);
                gtk_text_buffer_insert(app->text_buffer, &end, formatted, -1);
                g_free(formatted);
                found = 1;
            }
        }
    }
    if (!found) {
        char *no_hit = g_strdup_printf("--> No hits found. (Best match: %.1f%%)\n", best_sim);
        gtk_text_buffer_insert_at_cursor(app->text_buffer, no_hit, -1);
        g_free(no_hit);
    }
    fclose(f);
}

void on_clear_clicked(GtkWidget *widget, gpointer user_data) {
    XDictApp *app = (XDictApp*)user_data;
    gtk_editable_set_text(GTK_EDITABLE(app->entry_ger), "");
    gtk_editable_set_text(GTK_EDITABLE(app->entry_eng), "");
    gtk_text_buffer_set_text(app->text_buffer, "", -1);
}

static void on_quit_action(GSimpleAction *action, GVariant *parameter, gpointer user_data) {
    g_application_quit(G_APPLICATION(g_application_get_default()));
}

static void on_about_action(GSimpleAction *action, GVariant *parameter, gpointer user_data) {
    GtkWidget *window = gtk_window_new();
    gtk_window_set_title(GTK_WINDOW(window), "About xdict");
    gtk_window_set_transient_for(GTK_WINDOW(window), GTK_WINDOW(user_data));
    gtk_window_set_modal(GTK_WINDOW(window), TRUE);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(window), 450, 250);

    GtkWidget *info_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    // Fixed: Manual margins for GTK4
    gtk_widget_set_margin_top(info_vbox, 25);
    gtk_widget_set_margin_bottom(info_vbox, 25);
    gtk_widget_set_margin_start(info_vbox, 25);
    gtk_widget_set_margin_end(info_vbox, 25);
    gtk_widget_set_valign(info_vbox, GTK_ALIGN_CENTER);
    gtk_window_set_child(GTK_WINDOW(window), info_vbox);

    GtkWidget *lbl_title = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(lbl_title), "<span size='30000' weight='heavy'>xdict 1.0.7</span>");
    gtk_box_append(GTK_BOX(info_vbox), lbl_title);

    GtkWidget *lbl_desc = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(lbl_desc), "<span size='x-large' weight='bold' foreground='#1a5fb4'>Universal Fuzzy Logic Lookup</span>");
    gtk_box_append(GTK_BOX(info_vbox), lbl_desc);

    GtkWidget *lbl_copy = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(lbl_copy), 
        "<span size='medium'>Copyright © 2001-2026 Marc Gloor\n"
        "<span foreground='#666666'>marc.gloor@u.nus.edu</span>\n\n"
        "<span size='small' foreground='#2e3436'>Software is licensed under the GNU GPL v3.</span></span>");
    gtk_box_append(GTK_BOX(info_vbox), lbl_copy);

    GtkWidget *btn_close = gtk_button_new_with_label("Close");
    gtk_widget_set_halign(btn_close, GTK_ALIGN_CENTER);
    g_signal_connect_swapped(btn_close, "clicked", G_CALLBACK(gtk_window_destroy), window);
    gtk_box_append(GTK_BOX(info_vbox), btn_close);

    gtk_window_present(GTK_WINDOW(window));
}

static void activate(GtkApplication *application, gpointer user_data) {
    XDictApp *app = (XDictApp*)user_data;

    g_strlcpy(app->label_top, "Top Field...", sizeof(app->label_top));
    g_strlcpy(app->label_bottom, "Bottom Field...", sizeof(app->label_bottom));

    FILE *f = fopen(app->dict_path, "r");
    if (f) {
        char header[512];
        if (fgets(header, sizeof(header), f)) {
            char *sep = strchr(header, '#');
            if (sep) {
                *sep = '\0';
                header[strcspn(header, "\r\n")] = 0;
                char *term_b = sep + 1;
                term_b[strcspn(term_b, "\r\n")] = 0;
                g_strlcpy(app->label_top, header, sizeof(app->label_top));
                g_strlcpy(app->label_bottom, term_b, sizeof(app->label_bottom));
            }
        }
        fclose(f);
    }

    app->main_window = gtk_application_window_new(application);
    gtk_window_set_title(GTK_WINDOW(app->main_window), "xdict 1.0.7");
    gtk_window_set_default_size(GTK_WINDOW(app->main_window), 450, 550);

    GSimpleAction *act_quit = g_simple_action_new("quit", NULL);
    g_signal_connect(act_quit, "activate", G_CALLBACK(on_quit_action), NULL);
    g_action_map_add_action(G_ACTION_MAP(application), G_ACTION(act_quit));

    GSimpleAction *act_about = g_simple_action_new("about", NULL);
    g_signal_connect(act_about, "activate", G_CALLBACK(on_about_action), app->main_window);
    g_action_map_add_action(G_ACTION_MAP(application), G_ACTION(act_about));

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_window_set_child(GTK_WINDOW(app->main_window), vbox);

    GMenu *menu = g_menu_new();
    GMenu *file_m = g_menu_new(); g_menu_append(file_m, "Quit", "app.quit"); g_menu_append_submenu(menu, "File", G_MENU_MODEL(file_m));
    GMenu *help_m = g_menu_new(); g_menu_append(help_m, "About", "app.about"); g_menu_append_submenu(menu, "Help", G_MENU_MODEL(help_m));
    GtkWidget *menubar = gtk_popover_menu_bar_new_from_model(G_MENU_MODEL(menu));
    gtk_box_append(GTK_BOX(vbox), menubar);

    GtkWidget *content = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_set_margin_top(content, 15);
    gtk_widget_set_margin_bottom(content, 15);
    gtk_widget_set_margin_start(content, 15);
    gtk_widget_set_margin_end(content, 15);
    gtk_box_append(GTK_BOX(vbox), content);

    app->entry_ger = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(app->entry_ger), app->label_top);
    g_signal_connect(app->entry_ger, "activate", G_CALLBACK(start_search), app);
    gtk_box_append(GTK_BOX(content), app->entry_ger);

    app->entry_eng = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(app->entry_eng), app->label_bottom);
    g_signal_connect(app->entry_eng, "activate", G_CALLBACK(start_search), app);
    gtk_box_append(GTK_BOX(content), app->entry_eng);

    GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_append(GTK_BOX(hbox), gtk_label_new("Match %:"));
    app->spin_match = gtk_spin_button_new_with_range(0, 100, 5);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(app->spin_match), 90);
    gtk_box_append(GTK_BOX(hbox), app->spin_match);
    
    GtkWidget *btn_search = gtk_button_new_with_label("Translate");
    gtk_widget_set_hexpand(btn_search, TRUE);
    g_signal_connect(btn_search, "clicked", G_CALLBACK(start_search), app);
    gtk_box_append(GTK_BOX(hbox), btn_search);

    GtkWidget *btn_clear = gtk_button_new_with_label("Clear");
    g_signal_connect(btn_clear, "clicked", G_CALLBACK(on_clear_clicked), app);
    gtk_box_append(GTK_BOX(hbox), btn_clear);

    gtk_box_append(GTK_BOX(content), hbox);

    GtkWidget *scrolled = gtk_scrolled_window_new();
    gtk_widget_set_vexpand(scrolled, TRUE);
    GtkWidget *tv = gtk_text_view_new();
    app->text_buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(tv));
    gtk_text_view_set_editable(GTK_TEXT_VIEW(tv), FALSE);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(scrolled), tv);
    gtk_box_append(GTK_BOX(content), scrolled);

    gtk_window_present(GTK_WINDOW(app->main_window));
}

int main(int argc, char *argv[]) {
    static XDictApp app_data;
    app_data.dict_path = "xdict.dat";
    GtkApplication *app = gtk_application_new("org.xdict.app", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(activate), &app_data);
    int status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    return status;
}
