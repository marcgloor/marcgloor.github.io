#!/bin/sh
# @(#) MyLang library importer
# $Id: MyLang_libimport.sh,v 1.9 2026/03/25 06:30:36 gloor Exp $
# 23/10/2005 - written by Marc O. Gloor <mgloor@fhzh.ch>
# 25/03/2026 - modernized by Marc O. Gloor <marc.gloor@u.nus.edu>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA

# global definitions
EXIT=0 ; CMD=$0 ; PID=$$ ; HOST=`hostname` ; TMP=/tmp/
LOGTIME () { TIME="`date '+%d-%m-%Y %H:%M:%S'`" ; }
LOG=MyLang_libimport.log ; exec 2>>$LOG
ACTION1="start"
ACTION2="end"
ACTION3="parsing csv"
ACTION4="writing xml"

# begin script
# start logging
LOGTIME; echo "$TIME $HOST $CMD $ACTION1" >> $LOG

echo -n "MyLang dictionary library importer " && echo \$Revision: 1.9 $ | tr -d "$"
echo "23/10/2005 - written by Marc O. Gloor <mgloor@fhzh.ch>"
echo 
echo -n "csv-library to import [file]    : " && read imp_file
echo -n "export to MyLang library [file] : " && read exp_file
echo -n "library description [text]      : " && read description
echo -n "1st language name [name]        : " && read lang0_name
echo -n "2nd language name [name]        : " && read lang1_name
echo "please wait..."
exp_file=$(echo $exp_file | tr " " "_")

# std xml header
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $exp_file
echo -n "<!-- created with MyLang_libimport.sh, " >> $exp_file
echo -n \$Revision: 1.9 $ | tr -d "$" >> $exp_file 
echo "-->" >> $exp_file 
echo >> $exp_file
echo "<dictionary languageName0=\"$lang0_name\" languageName1=\"$lang1_name\" description=\"$description\">" >> $exp_file
echo "  <words>" >> $exp_file

# data part
LOGTIME; echo "$TIME $HOST $CMD $ACTION3 (exit=$EXIT)" >> $LOG
LOGTIME; echo "$TIME $HOST $CMD $ACTION4 (exit=$EXIT)" >> $LOG
cat $imp_file | 
(
 while read string
 do
  lang0=$(echo $string | awk 'split($string, token, ";") { print token[1]}')
  lang1=$(echo $string | awk 'split($string, token, ";") { print token[2]}')
  echo "    <word rev=\"2\">" >> $exp_file
  echo "      <language0>$lang0</language0>" >> $exp_file
  echo "      <language1>$lang1</language1>" >> $exp_file
  echo "    </word>" >> $exp_file
 done
)

# footer
echo "  </words>" >> $exp_file
echo "  <stats/>" >> $exp_file
echo "</dictionary>" >> $exp_file

# stop logging
LOGTIME; echo "$TIME $HOST $CMD $ACTION2 (exit=$EXIT)" >> $LOG
exit $EXIT
